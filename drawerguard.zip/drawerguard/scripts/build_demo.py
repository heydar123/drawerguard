"""Build a single-file, offline demo of the dashboard (dist/drawerguard_demo.html).

Loads the 2-store sample data into a temporary database, sets up cameras, users,
a case and a report, captures the real API responses, and embeds them with a
small in-browser mock API.   Usage:  python scripts/build_demo.py
"""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
tmp = Path(tempfile.mkdtemp())
os.environ.update(DRAWERGUARD_DB=str(tmp / "demo.db"), DRAWERGUARD_DATA=str(tmp / "data"), DRAWERGUARD_PASSWORD="demo-owner-pw",
                  REPORTS_ENABLED="0", PASSWORD_MIN_LENGTH="12", IDLE_TIMEOUT_MINUTES="15", HOST="127.0.0.1")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

c = TestClient(app)
tok = c.post("/api/login", json={"username": "owner", "password": "demo-owner-pw"}).json()["token"]
H = {"Authorization": f"Bearer {tok}"}
c.post("/api/users", headers=H, json={"username": "sam", "full_name": "Sam (Manager)", "password": "demo-pass-1234", "role": "manager", "stores": ["main"]})
c.post("/api/users", headers=H, json={"username": "rita", "full_name": "Rita (Manager)", "password": "demo-pass-1234", "role": "manager", "stores": ["harbor"]})
c.post("/api/users", headers=H, json={"username": "accountant", "full_name": "Outside accountant", "password": "demo-pass-1234", "role": "auditor", "stores": ["*"]})
c.post("/api/automations", headers=H, json={"name": "Refund fraud → Sam + case", "rules": ["cash_refund_on_card_sale", "refund_exceeds_original"],
                                            "min_severity": 4, "stores": ["main"], "assign_to": "sam", "add_to_case": True, "tag": "refund-fraud"})
c.post("/api/automations", headers=H, json={"name": "Collusion / multi-indicator → owner + push", "rules": ["approver_concentration", "correlated_shift"],
                                            "min_severity": 4, "assign_to": "owner", "set_status": "investigating", "notify": True, "tag": "priority"})
for f, store in (("splitpos_transactions.csv", "main"), ("splitpos_cashup.csv", "main"),
                 ("harbor_transactions.csv", "harbor"), ("harbor_cashup.csv", "harbor"),
                 ("splitpos_timeclock.csv", "main"), ("harbor_timeclock.csv", "harbor")):
    with open(ROOT / "sample_data" / f, "rb") as fh:
        if c.post("/api/import", headers=H, files={"file": (f, fh)}, data={"store": store}).status_code != 200:
            raise SystemExit(f"import of {f} failed")
c.patch("/api/stores/main", headers=H, json={"name": "Downtown Cafe", "open_hour": 6, "close_hour": 23})
c.patch("/api/stores/harbor", headers=H, json={"name": "Harbor Street", "open_hour": 6, "close_hour": 23})
HIK = "http://192.168.1.64/doc/page/playback.asp?starttime={start_compact}&endtime={end_compact}"
for st, reg, name, off in (("main", "Till 1", "Cam 1 – front counter", -12), ("main", "Till 2", "Cam 2 – side counter", -12),
                           ("harbor", "Till 1", "Cam A – register", 35), ("harbor", "Till 2", "Cam B – register 2", 35)):
    c.post("/api/cameras", headers=H, json={"store": st, "register": reg, "name": name, "url_template": HIK, "offset_seconds": off})
c.post("/api/custom-rules", headers=H, json={"name": "Large cash refunds in the evening", "severity": 4, "description": "Evening refunds are rarely checked by a manager.",
     "definition": {"match": [{"field": "txn_type", "op": "==", "value": "refund"}, {"field": "payment_method", "op": "==", "value": "cash"},
                              {"field": "amount", "op": ">=", "value": 20}, {"field": "hour", "op": ">=", "value": 18}]}})
c.post("/api/custom-rules", headers=H, json={"name": "3+ voids by one cashier in a day", "severity": 3,
     "definition": {"match": [{"field": "txn_type", "op": "==", "value": "void"}], "aggregate": {"by": ["cashier", "day"], "count_gte": 3}}})
c.post("/api/suppressions", headers=H, json={"rule": "paid_out", "cashier": "Maria S.", "store": "main", "apply_existing": True,
                                             "reason": "Maria buys milk from petty cash, approved by Sam"})
INGEST_KEY = c.post("/api/apikeys", headers=H, json={"name": "POS bridge (nightly export script)", "scopes": ["ingest"], "stores": ["*"]}).json()["key"]
# ---- v5: 2FA for the owner, canaries planted before anyone uses them
from app.auth import totp_now as _totp  # noqa: E402
_sec2 = c.post("/api/me/2fa/setup", headers=H).json()["secret"]
c.post("/api/me/2fa/enable", headers=H, json={"secret": _sec2, "code": _totp(_sec2)})
c.post("/api/canaries", headers=H, json={"kind": "approver", "value": "Morgan (Manager)", "note": "Override code on a sticky note under Till 1 (both stores)"})
c.post("/api/canaries", headers=H, json={"store": "main", "kind": "till", "value": "Till 3", "note": "Old till in the back office, unplugged in October"})
c.post("/api/canaries", headers=H, json={"kind": "note", "value": "VIP-COMP-7", "note": "Reason code printed on a fake 'manager cheat sheet'"})
c.post("/api/apikeys", headers=H, json={"name": "SOAR pull (Tines)", "scopes": ["read"], "stores": ["*"]})
UA_PC, UA_IPHONE = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/131.0", "Mozilla/5.0 (iPhone; CPU iPhone OS 18_1) Safari/604.1"
c.post("/api/login", json={"username": "sam", "password": "demo-pass-1234"}, headers={"User-Agent": UA_PC})
c.post("/api/login", json={"username": "sam", "password": "demo-pass-1234"}, headers={"User-Agent": UA_IPHONE})
for u in ("admin", "manager", "root", "rita", "test"):
    c.post("/api/login", json={"username": u, "password": "Summer2026!"}, headers={"User-Agent": "python-requests/2.32"})
from app import security as _sec  # noqa: E402
_sec._ip_fails.clear()
# Jake finds the planted override code and tries it (arrives through the real-time ingest API)
c.post("/api/v1/transactions?store=main", headers={"X-API-Key": INGEST_KEY}, json={"transactions": [
    {"id": "R-CANARY-1", "ts": "2026-11-07T19:42:10", "cashier": "Jake M.", "register": "Till 1", "type": "refund", "amount": 38.50,
     "payment_method": "cash", "approved_by": "Morgan (Manager)", "note": "Customer complaint"}]})

# ---- simulate a few weeks of analyst work, so SOC metrics have realistic numbers
import random  # noqa: E402
from datetime import datetime as _dt, timedelta as _td  # noqa: E402
from app.deps import conn as dconn  # noqa: E402
from app.soc import sla_hours  # noqa: E402
rnd = random.Random(42)
THIEF_START = {"Jake M.": "2026-09-25", "Tina R.": "2026-09-25", "Leo K.": "2026-10-16", "Nina R.": "2026-10-18", "Sofia V.": "2026-09-25"}
PAYROLL_TRUTH = {"Kevin D.": "ghost_employee", "Chris W.": "timecard_edit", "Ben T.": "clocked_out_activity", "Grace L.": "clock_padding",
                 "Aisha K.": "buddy_punch", "Daniel P.": "buddy_punch"}
latest = _dt.fromisoformat(dconn.execute("SELECT MAX(ts) m FROM transactions").fetchone()["m"])
FMT = "%Y-%m-%d %H:%M:%S"
for a in dconn.execute("SELECT * FROM alerts").fetchall():
    ts = _dt.fromisoformat(a["ts"])
    created = ts + _td(minutes=rnd.randint(20, 540))
    due = created + _td(hours=sla_hours().get(a["severity"], 168))
    upd = {"created_at": created.strftime(FMT), "due_at": due.strftime(FMT)}
    age = (latest - ts).days
    thief = (a["cashier"] in THIEF_START and a["ts"][:10] >= THIEF_START[a["cashier"]]) or PAYROLL_TRUTH.get(a["cashier"]) == a["rule"]
    who = a["assigned_to"] or ("sam" if a["store"] == "main" else "rita") if rnd.random() < .8 else "owner"
    if a["suppressed_by"]:
        upd.update(acked_at=upd["created_at"], resolved_at=upd["created_at"])
    elif age >= 3 and rnd.random() < 0.85:
        acked = created + _td(hours=rnd.uniform(0.2, 1.0) * (6 if a["severity"] >= 4 else 30))
        status = ("confirmed" if rnd.random() < 0.8 else "investigating") if thief else ("dismissed" if rnd.random() < 0.88 else "investigating")
        upd.update(status=status, assigned_to=who, acked_at=acked.strftime(FMT))
        if status in ("confirmed", "dismissed"):
            upd["resolved_at"] = (acked + _td(hours=rnd.uniform(1, 30))).strftime(FMT)
        dconn.execute("INSERT INTO alert_history(alert_id, actor, field, old, new, created_at) VALUES(?,?,?,?,?,?)",
                      (a["id"], who, "status", "open", status, upd.get("resolved_at") or upd["acked_at"]))
    elif age < 3 and rnd.random() < 0.3:
        upd["assigned_to"] = who
    dconn.execute(f"UPDATE alerts SET {', '.join(k + '=?' for k in upd)} WHERE id=?", [*upd.values(), a["id"]])
dconn.commit()
ja = c.get("/api/alerts?store=main&cashier=Jake M.&rule=no_sale_after_cash&status=open&limit=6", headers=H).json()["items"]
cid = c.post("/api/cases", headers=H, json={"store": "main", "cashier": "Jake M.", "title": "Jake M.: No-Sale skimming at Till 1",
                                            "alert_ids": [a["id"] for a in ja]}).json()["id"]
c.post(f"/api/cases/{cid}/notes", headers=H, json={"body": "Reviewed Cam 1 for Nov 7: cash goes to apron pocket after No-Sale at 14:22 and 16:05."})
c.post(f"/api/cases/{cid}/notes", headers=H, json={"body": "Surprise drawer count Nov 8, 11:00: $38 short."})
na = c.get("/api/alerts?store=harbor&cashier=Nina R.&min_severity=4&status=open&limit=4", headers=H).json()["items"]
cid2 = c.post("/api/cases", headers=H, json={"store": "harbor", "cashier": "Nina R.", "title": "Nina R.: short drawers since late October",
                                             "alert_ids": [a["id"] for a in na]}).json()["id"]
c.patch(f"/api/cases/{cid2}", headers=H, json={"status": "closed_theft", "loss_amount": 717.6, "recovered": 300, "outcome": "Admitted taking cash; repayment agreed, employment ended."})
rep = c.post("/api/reports", headers=H, json={"days": 7, "kind": "weekly"}).json()
# ---- v4: incident response on both cases
for chk in ("detection.verify_cctv", "detection.timeline", "detection.evidence", "detection.estimate", "containment.watchlist"):
    c.patch(f"/api/cases/{cid}/ir", headers=H, json={"check": chk})
c.patch(f"/api/cases/{cid}/ir", headers=H, json={"phase": "containment", "check": "containment.remove_cash",
                                                 "root_cause": "No Sale is open to every cashier and nobody reviews No-Sale counts; cash sales "
                                                               "are re-opened seconds later and the cash is pocketed."})
c.patch(f"/api/cases/{cid}/ir", headers=H, json={"check": "containment.reset_pins", "controls": [
    "Disable No Sale for cashiers; give change from the open drawer during the sale only."]})
for ph in ("detection", "containment", "eradication", "recovery", "post_incident"):
    from app.ir import CHECKLIST as _CL  # noqa: E402
    for k, _t in _CL[ph]:
        c.patch(f"/api/cases/{cid2}/ir", headers=H, json={"check": f"{ph}.{k}"})
    c.patch(f"/api/cases/{cid2}/ir", headers=H, json={"phase": ph})
c.patch(f"/api/cases/{cid2}/ir", headers=H, json={
    "root_cause": "Blind cash counts were not enforced at Harbor Street, so a late-shift cashier could take cash and close the shift short "
                  "without anyone counting with her.",
    "lessons": "Two-person blind counts at every handover; review shortages weekly; AI behaviour-change alerts go straight to the owner.",
    "controls": ["Blind cash counts by two people; drop excess cash into the safe during the shift.",
                 "Point a camera at each drawer; restrict No Sale to managers."]})

DAYS, STORES = [7, 30, 90, 0], ["", "main", "harbor"]
D = {"summary": {}, "detail": {}, "since": {}}
for st in STORES:
    for d in DAYS:
        s = c.get(f"/api/summary?days={d}&store={st}", headers=H).json()
        D["summary"][f"{st}|{d}"] = s
        D["since"][f"{st}|{d}"] = s["range"]["since"]
for d in DAYS:
    for x in D["summary"][f"|{d}"]["cashiers"]:
        det = c.get(f"/api/cashiers/{x['cashier']}?days={d}", headers=H).json()
        det["alert_ids"] = [a["id"] for a in det.pop("alerts")]
        D["detail"][f"{d}|{x['cashier']}"] = det
al = c.get("/api/alerts?status=&limit=5000", headers=H).json()
D["alerts"], D["rule_labels"] = al["items"], al["rule_labels"]
me = c.get("/api/me", headers=H).json()
me.update(default_password=False, lan_url="http://192.168.1.20:8000 (example)")
D["me"] = me
D["rules"] = c.get("/api/settings/rules", headers=H).json()
D["imports"] = c.get("/api/imports", headers=H).json()
D["stores"] = c.get("/api/stores", headers=H).json()
D["cameras"] = c.get("/api/cameras", headers=H).json()
D["users"] = c.get("/api/users", headers=H).json()
D["audit"] = c.get("/api/audit", headers=H).json()
D["audit_verify"] = c.get("/api/audit/verify", headers=H).json()
D["detections"] = c.get("/api/detections", headers=H).json()
D["cases"] = c.get("/api/cases", headers=H).json()
D["case"] = {str(k["id"]): c.get(f"/api/cases/{k['id']}", headers=H).json() for k in D["cases"]}
D["reports"] = c.get("/api/reports", headers=H).json()
D["docs"] = {f"/api/reports/{rep['id']}/view": c.get(f"/api/reports/{rep['id']}/view?token={tok}").text}
for k in D["cases"]:
    D["docs"][f"/api/cases/{k['id']}/file"] = c.get(f"/api/cases/{k['id']}/file?token={tok}").text
# ---- v3 data
D["soc"] = {f"{st}|{d}": c.get(f"/api/soc/metrics?days={d}&store={st}", headers=H).json() for st in STORES for d in DAYS}
D["heatmap"] = {f"{st}|{d}": c.get(f"/api/forensics/heatmap?days={d}&store={st}", headers=H).json() for st in STORES for d in DAYS}
FTYPES = ["refund", "void", "paid_out", "discount", "sale", "cancel"]
D["benford"] = {f"{st}|{t}": c.get(f"/api/forensics/benford?type={t}&days=0&store={st}", headers=H).json() for st in STORES for t in FTYPES}
D["rounding"] = {f"{st}|{t}": c.get(f"/api/forensics/rounding?type={t}&days=0&store={st}", headers=H).json() for st in STORES for t in FTYPES}
D["approvals"] = {st: c.get(f"/api/forensics/approvals?days=0&store={st}", headers=H).json() for st in STORES}
D["hours"] = {st: c.get(f"/api/forensics/hours?days=0&store={st}", headers=H).json() for st in STORES}
lib = c.get("/api/hunt/library", headers=H).json()
D["hunt_lib"] = lib
D["hunt_results"] = {h["sql"]: c.post("/api/hunt/run", headers=H, json={"sql": h["sql"]}).json() for h in lib["library"]}
D["health"] = c.get("/api/health/data", headers=H).json()
D["custom"] = c.get("/api/custom-rules", headers=H).json()
D["custom_schema"] = c.get("/api/custom-rules/schema", headers=H).json()
D["custom_tests"] = {str(r["id"]): c.post("/api/custom-rules/test", headers=H, json={k: r[k] for k in ("name", "severity", "definition")}).json() for r in D["custom"]}
D["suppressions"] = c.get("/api/suppressions", headers=H).json()
D["automations"] = c.get("/api/automations", headers=H).json()
D["security"] = c.get("/api/security/overview", headers=H).json()
D["apikeys"] = c.get("/api/apikeys", headers=H).json()
c.post("/api/admin/backup", headers=H)
D["backups"] = c.get("/api/admin/backups", headers=H).json()
D["assignees"] = c.get("/api/assignees", headers=H).json()
D["history"] = {}
for r in dconn.execute("SELECT * FROM alert_history ORDER BY id DESC"):
    D["history"].setdefault(str(r["alert_id"]), []).append(dict(r))
sig = c.get("/api/detections/sigma", headers=H).text
D["docs"]["/api/detections/sigma"] = "<!DOCTYPE html><meta charset=utf-8><title>DrawerGuard Sigma rules</title><pre style='font:13px/1.5 monospace;padding:20px'>" + \
    sig.replace("&", "&amp;").replace("<", "&lt;") + "</pre>"
cols = ["store", "id", "ts", "cashier", "register", "txn_type", "amount", "payment_method", "order_id", "original_txn_id",
        "discount_amount", "approved_by", "sent_to_kitchen", "note"]
allt, off = [], 0
while True:
    page = c.get(f"/api/transactions?limit=5000&offset={off}", headers=H).json()["items"]
    if not page:
        break
    allt += page
    off += len(page)
D["txn_cols"], D["txns"] = cols, [[t[k] for k in cols] for t in allt]
D["now"] = __import__("app.soc", fromlist=["now_utc"]).now_utc()

# ---- v4 data
D["payroll"] = {f"{st}|{d}": c.get(f"/api/payroll/overview?days={d}&store={st}", headers=H).json() for st in STORES for d in DAYS}
D["ml"] = {st: c.get(f"/api/ml/health?store={st}", headers=H).json() for st in STORES}
D["purple_sc"] = c.get("/api/purple/scenarios", headers=H).json()
D["purple_run"], D["purple_by_store"], D["sweeps"] = {}, {}, {}
for st in ("main", "harbor"):
    r = c.post("/api/purple/run", headers=H, json={"store": st, "days": 14, "intensity": 1}).json()
    D["purple_run"][str(r["id"])] = r
    D["purple_by_store"][st] = r["id"]
    for sc in D["purple_sc"]:
        D["sweeps"][f"{st}|{sc['id']}"] = c.post("/api/purple/sweep", headers=H, json={"store": st, "scenario": sc["id"], "days": 14}).json()
D["purple_runs"] = c.get("/api/purple/runs", headers=H).json()
D["dac"] = c.get("/api/detections/tests", headers=H).json()
D["dac_src"] = {x["id"]: c.get(f"/api/detections/{x['id']}/source", headers=H).text for x in D["detections"]}
D["case"] = {str(k["id"]): c.get(f"/api/cases/{k['id']}", headers=H).json() for k in D["cases"]}
D["ir"] = {str(k["id"]): c.get(f"/api/cases/{k['id']}/ir", headers=H).json() for k in D["cases"]}
# ---- v5 data
D["incidents"] = {f"{st}|{d}": c.get(f"/api/incidents?days={d}&store={st}", headers=H).json() for st in STORES for d in DAYS}
D["graph"] = {f"{st}|{d}": c.get(f"/api/graph?days={d}&store={st}", headers=H).json() for st in STORES for d in DAYS}
D["canaries"] = c.get("/api/canaries", headers=H).json()
D["watchlist"] = c.get("/api/watchlist", headers=H).json()
D["compliance"] = c.get("/api/compliance", headers=H).json()
D["integrations"] = c.get("/api/integrations", headers=H).json()
D["docs"]["/api/compliance/report"] = c.get(f"/api/compliance/report?token={tok}").text
for k in D["cases"]:
    D["docs"][f"/api/cases/{k['id']}/ir-report"] = c.get(f"/api/cases/{k['id']}/ir-report?token={tok}").text

MOCK = r"""
function demoOpen(path) {
  const key = path.split('?')[0], html = window.DEMO_DATA.docs[key];
  if (!html) return toast('Available in the installed version');
  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); }
  else { const b = new Blob([html], { type: 'text/html' }); location.href = URL.createObjectURL(b); }
}
function demoApi(method, path, body) {
  const D = window.DEMO_DATA;
  const [p, qs] = path.split('?'); const q = new URLSearchParams(qs || '');
  const days = +(q.get('days') || 0), st = q.get('store') || '';
  const ro = () => { throw new Error('This is the demo: changes like this work in the installed version.'); };
  if (!D._tx) { D._tx = D.txns.map(r => Object.fromEntries(D.txn_cols.map((k, i) => [k, r[i]]))); D._byId = Object.fromEntries(D.alerts.map(a => [a.id, a])); }
  const iso = ms => { const d = new Date(ms); return new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 19); };
  const res = (() => {
    if (p === '/api/me') return D.me;
    if (p === '/api/summary') return refreshSummary(D, st, days);
    if (p === '/api/cashiers') return (D.summary[`${st}|${days}`] || D.summary[`|${days}`]).cashiers;
    if (p.startsWith('/api/cashiers/') && p.endsWith('/ai-summary')) return ro();
    if (p.startsWith('/api/cashiers/')) { const n = decodeURIComponent(p.split('/')[3]); const det = D.detail[`${days}|${n}`] || D.detail[`30|${n}`];
      return { ...det, alerts: det.alert_ids.map(i => D._byId[i]) }; }
    if (p === '/api/alerts' && method === 'GET') {
      const sts = q.get('status') ? q.get('status').split(',') : null, since = D.since[`${st}|${days}`] || D.since[`|${days}`];
      let items = D.alerts.filter(a => (!st || a.store === st) && (!sts || sts.includes(a.status)) && a.severity >= +(q.get('min_severity') || 1)
        && (!q.get('cashier') || a.cashier === q.get('cashier')) && (!q.get('rule') || a.rule === q.get('rule'))
        && (!+q.get('id') || a.id === +q.get('id')) && (!+q.get('case_id') || a.case_id === +q.get('case_id'))
        && (!q.get('assigned') || (q.get('assigned') === 'me' ? a.assigned_to === 'owner' : q.get('assigned') === 'unassigned' ? !a.assigned_to : a.assigned_to === q.get('assigned')))
        && (!q.get('overdue') || (a.due_at && a.due_at < D.now && ['open', 'investigating'].includes(a.status)))
        && (!q.get('q') || (a.title + a.notes + (a.txn_id || '')).toLowerCase().includes(q.get('q').toLowerCase()))
        && (!since || a.ts >= since || (['peer_outlier', 'low_cash_ratio'].includes(a.rule) && a.ts >= since.slice(0, 7) + '-01')));
      items.sort((a, b) => (b.ts || '').localeCompare(a.ts || '') || b.severity - a.severity);
      return { total: items.length, items: items.slice(0, +(q.get('limit') || 200)), rule_labels: D.rule_labels };
    }
    if (p.startsWith('/api/alerts/') && method === 'PATCH') { const a = D._byId[+p.split('/')[3]]; if (body.status) a.status = body.status; if (body.notes != null) a.notes = body.notes;
      if (body.assigned_to != null) a.assigned_to = body.assigned_to || null; return a; }
    if (p === '/api/alerts/bulk') { body.ids.forEach(i => { if (body.status) D._byId[i].status = body.status; if (body.assigned_to != null) D._byId[i].assigned_to = body.assigned_to || null; }); return { updated: body.ids.length }; }
    if (p === '/api/transactions') {
      const f = D._tx.filter(t => (!st || t.store === st) && (!q.get('cashier') || t.cashier === q.get('cashier')) && (!q.get('type') || t.txn_type === q.get('type'))
        && (!q.get('start') || t.ts >= q.get('start')) && (!q.get('end') || t.ts <= q.get('end'))
        && (!q.get('q') || (t.id + t.note + t.order_id).toLowerCase().includes(q.get('q').toLowerCase())));
      f.sort((a, b) => b.ts.localeCompare(a.ts));
      return { total: f.length, items: f.slice(0, +(q.get('limit') || 200)) };
    }
    if (p === '/api/context') {
      const s = q.get('store'), id = q.get('id'), t = D._tx.find(x => x.store === s && x.id === id), dt = new Date(t.ts).getTime();
      const a = iso(dt - 6e5), b = iso(dt + 6e5);
      const cams = D.cameras.cameras.filter(c => c.store === s && (c.register === t.register || !c.register)).map(c => {
        const dv = dt + c.offset_seconds * 1000, f = iso(dv - 6e4), to = iso(dv + 12e4), cmp = x => x.replace(/[-:]/g, '');
        return { camera: c.name, register: c.register || 'whole store', dvr_time: iso(dv), from: f, to, url: c.url_template.replace('{start_compact}', cmp(f)).replace('{end_compact}', cmp(to)) }; });
      return { txn: t, cctv: cams, timeline: D._tx.filter(x => x.store === s && (t.register ? x.register === t.register : x.cashier === t.cashier) && x.ts >= a && x.ts <= b).sort((x, y) => x.ts.localeCompare(y.ts)),
        order: t.order_id ? D._tx.filter(x => x.store === s && x.order_id === t.order_id) : [], linked: D._tx.filter(x => x.store === s && (x.id === (t.original_txn_id || '-') || x.original_txn_id === id)) };
    }
    if (p === '/api/cases' && method === 'GET') return D.cases.filter(c => (!st || c.store === st) && (!q.get('status') || c.status === q.get('status')));
    if (/^\/api\/cases\/\d+$/.test(p) && method === 'GET') { const k = D.case[p.split('/')[3]]; return { ...k, alerts: k.alerts.map(a => D._byId[a.id] || a) }; }
    if (p === '/api/evidence' && method === 'GET') return [];
    if (p === '/api/settings/rules' && method === 'GET') return D.rules;
    if (p === '/api/stores' && method === 'GET') return D.stores;
    if (p === '/api/cameras' && method === 'GET') return D.cameras;
    if (p === '/api/users' && method === 'GET') return D.users;
    if (p === '/api/imports') return D.imports;
    if (p === '/api/assignees') return D.assignees;
    if (p.startsWith('/api/alerts/') && p.endsWith('/history')) return D.history[p.split('/')[3]] || [];
    if (p === '/api/soc/metrics') return D.soc[`${st}|${days}`] || D.soc[`|${days}`];
    if (p === '/api/forensics/heatmap') return D.heatmap[`${st}|${days}`] || D.heatmap[`|${days}`];
    if (p === '/api/forensics/benford') return D.benford[`${st}|${q.get('type')}`];
    if (p === '/api/forensics/rounding') return D.rounding[`${st}|${q.get('type')}`];
    if (p === '/api/forensics/approvals') return D.approvals[st];
    if (p === '/api/forensics/hours') return D.hours[st];
    if (p === '/api/hunt/library') return D.hunt_lib;
    if (p === '/api/hunt/run') { const r = D.hunt_results[body.sql]; if (r) return r; throw new Error('Demo: library hunts run here; your own SQL runs in the installed version.'); }
    if (p === '/api/hunt/pivot') return demoPivot(D, q, st);
    if (p === '/api/health/data') return D.health;
    if (p === '/api/custom-rules' && method === 'GET') return D.custom;
    if (p === '/api/custom-rules/schema') return D.custom_schema;
    if (p === '/api/custom-rules/test') { const m = D.custom.find(r => r.name === body.name); if (m) return D.custom_tests[String(m.id)]; return ro(); }
    if (p === '/api/suppressions' && method === 'GET') return D.suppressions;
    if (p === '/api/automations' && method === 'GET') return D.automations;
    if (p === '/api/security/overview') return D.security;
    if (p === '/api/apikeys' && method === 'GET') return D.apikeys;
    if (p === '/api/admin/backups') return D.backups;
    if (p === '/api/search') { const s = (q.get('q') || '').toLowerCase();
      return { cashiers: [...new Set(D._tx.map(t => t.cashier))].filter(n => n.toLowerCase().includes(s)).slice(0, 6),
        alerts: D.alerts.filter(a => String(a.id) === s.replace('#', '') || a.title.toLowerCase().includes(s)).slice(0, 6),
        cases: D.cases.filter(k => k.title.toLowerCase().includes(s) || String(k.id) === s.replace('#', '')).slice(0, 6),
        receipts: D._tx.filter(t => t.id.toLowerCase() === s || t.id.toLowerCase().startsWith(s)).slice(0, 6) }; }
    if (p === '/api/audit') return D.audit;
    if (p === '/api/audit/verify') return D.audit_verify;
    if (p === '/api/detections') return D.detections;
    if (p === '/api/reports' && method === 'GET') return D.reports;
    if (p === '/api/payroll/overview') return D.payroll[`${st}|${days}`] || D.payroll[`|${days}`];
    if (p === '/api/ml/health') return D.ml[st] || D.ml[''];
    if (p === '/api/purple/scenarios') return D.purple_sc;
    if (p === '/api/purple/runs') return D.purple_runs.filter(r => !st || r.store === st);
    if (p.startsWith('/api/purple/runs/')) return D.purple_run[p.split('/')[4]];
    if (p === '/api/purple/run') {
      const base = D.purple_run[String(D.purple_by_store[body.store])], ids = new Set(body.scenarios || []);
      const r = JSON.parse(JSON.stringify(base)), ran = (r.results = r.results.filter(x => !ids.size || ids.has(x.id))).filter(x => x.status !== 'skipped');
      const det = ran.filter(x => x.status === 'detected'), exp = ran.reduce((n, x) => n + x.expected.length, 0), hit = ran.reduce((n, x) => n + x.expected.length - x.missing_expected.length, 0);
      const ttd = ran.map(x => x.days_to_detect).filter(x => x != null).sort((a, b) => a - b);
      r.summary = { scenarios: ran.length, detected: det.length, weak: ran.filter(x => x.status === 'weak').length, missed: ran.filter(x => x.status === 'missed').length,
        coverage: ran.length ? det.length / ran.length : 0, expected_coverage: exp ? hit / exp : 0, median_days_to_detect: ttd.length ? ttd[Math.floor(ttd.length / 2)] : null,
        loss_simulated: ran.reduce((n, x) => n + x.simulated_loss, 0), loss_in_detected: det.reduce((n, x) => n + x.simulated_loss, 0) };
      if (+body.intensity !== r.intensity || +body.days !== r.days) toast('Demo: showing the pre-computed run at 1× over 14 days. Other settings run in the installed version.');
      return r;
    }
    if (p === '/api/purple/sweep') return D.sweeps[`${body.store}|${body.scenario}`] || ro();
    if (/^\/api\/cases\/\d+\/ir$/.test(p)) {
      const v = D.ir[p.split('/')[3]];
      if (method === 'PATCH') {
        if (body.check) v.phases.forEach(ph => ph.items.forEach(it => { if (it.key === body.check) Object.assign(it, { done: body.done !== false, by: 'owner', at: D.now }); }));
        if (body.phase) { v.phase = body.phase; v.phases.forEach(ph => { ph.current = ph.phase === body.phase; if (ph.current && !ph.entered) ph.entered = D.now; }); }
        v.phases.forEach(ph => ph.done = ph.items.filter(i => i.done).length);
        if (body.root_cause != null) v.root_cause = body.root_cause;
        if (body.lessons != null) v.lessons = body.lessons;
        if (body.controls) v.controls_chosen = body.controls;
      }
      return v;
    }
    if (p === '/api/detections/tests') return D.dac;
    if (p === '/api/incidents') return D.incidents[`${st}|${days}`] || D.incidents[`|${days}`];
    if (p === '/api/graph') return D.graph[`${st}|${days}`] || D.graph[`|${days}`];
    if (p === '/api/canaries' && method === 'GET') return D.canaries;
    if (p === '/api/watchlist' && method === 'GET') return D.watchlist.filter(w => !st || w.store === st);
    if (p === '/api/watchlist' && method === 'POST') { D.watchlist.unshift({ id: Date.now(), store: body.store, cashier: body.cashier, reason: body.reason,
      until: null, created_by: 'owner', created_at: D.now, active: true, alerts_since: 0 }); return { ok: true }; }
    if (p === '/api/compliance') return D.compliance;
    if (p === '/api/integrations') return D.integrations;
    if (/^\/api\/cases\/\d+\/push$/.test(p)) throw new Error('Demo: connect TheHive or Jira in .env in the installed version.');
    return ro();
  })();
  return Promise.resolve(JSON.parse(JSON.stringify(res)));
}
function demoPivot(D, q, st) {
  const K = { cashier: t => t.cashier, register: t => t.register, store: t => t.store, type: t => t.txn_type, payment: t => t.payment_method,
    approver: t => t.approved_by, hour: t => +t.ts.slice(11, 13), weekday: t => new Date(t.ts).getDay(), day: t => t.ts.slice(0, 10) };
  const g1 = K[q.get('group_by')] || K.cashier, g2 = K[q.get('group_by2') || ''], m = q.get('metric') || 'count', since = D.since[`${st}|${+(q.get('days') || 0)}`];
  const acc = {};
  D._tx.forEach(t => { if ((st && t.store !== st) || (q.get('type') && t.txn_type !== q.get('type')) || (q.get('payment') && t.payment_method !== q.get('payment'))
    || (+q.get('min_amount') && t.amount < +q.get('min_amount')) || (since && t.ts < since)) return;
    const k1 = g1(t), k2 = g2 ? g2(t) : null, key = k1 + '|' + k2; const a = acc[key] || (acc[key] = { k1, k2, n: 0, sum: 0, max: 0 });
    a.n++; a.sum += t.amount; a.max = Math.max(a.max, t.amount); });
  const rows = Object.values(acc).map(a => ({ k1: a.k1, ...(g2 ? { k2: a.k2 } : {}), n: a.n,
    v: m === 'count' ? a.n : m === 'sum' ? +a.sum.toFixed(2) : m === 'avg' ? +(a.sum / a.n).toFixed(2) : a.max })).sort((a, b) => b.v - a.v).slice(0, 500);
  return { rows, group_by: q.get('group_by'), group_by2: q.get('group_by2') || '', metric: m };
}
function refreshSummary(D, st, days) {
  const s = JSON.parse(JSON.stringify(D.summary[`${st}|${days}`] || D.summary[`|${days}`])), since = s.range.since;
  const A = D.alerts.filter(a => (!st || a.store === st) && (!since || a.ts >= since));
  const live = a => ['open', 'investigating'].includes(a.status);
  s.alerts = { total: A.length, open: A.filter(a => a.status === 'open').length, investigating: A.filter(a => a.status === 'investigating').length,
    confirmed: A.filter(a => a.status === 'confirmed').length, dismissed: A.filter(a => a.status === 'dismissed').length,
    critical_open: A.filter(a => a.severity >= 4 && live(a)).length,
    at_risk: A.filter(a => a.status !== 'dismissed').reduce((x, a) => x + a.amount, 0), confirmed_loss: A.filter(a => a.status === 'confirmed').reduce((x, a) => x + a.amount, 0) };
  s.per_store = s.per_store.map(ps => ({ ...ps, high: A.filter(a => a.store === ps.store && a.severity >= 4 && live(a)).length }));
  return s;
}
"""

html = (ROOT / "app" / "static" / "index.html").read_text()
data = json.dumps(D, separators=(",", ":")).replace("</", "<\\/")
html = html.replace('<script src="/static/i18n.js"></script>', "<script>" + (ROOT / "app" / "static" / "i18n.js").read_text() + "</script>")
html = html.replace("<!--DEMO_SCRIPT-->", f"<script>window.DEMO_DATA={data};\n{MOCK}</script>")
html = html.replace('<link rel="manifest" href="/manifest.json">', "").replace('<link rel="apple-touch-icon" href="/static/icon-192.png">', "")
html = html.replace("<title>DrawerGuard — Cashier Fraud Detection</title>", "<title>DrawerGuard 5.0 — Live Demo</title>")
out = ROOT / "dist" / "drawerguard_demo.html"
out.parent.mkdir(exist_ok=True)
out.write_text(html)
print(f"Wrote {out} ({out.stat().st_size / 1e6:.1f} MB, {len(D['alerts'])} alerts, {len(D['txns'])} txns)")
