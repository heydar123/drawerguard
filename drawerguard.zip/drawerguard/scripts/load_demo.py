"""Load the sample SplitPOS data (2 stores) into your local database to try DrawerGuard.
Usage: python scripts/load_demo.py   (then python run.py)"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except ImportError:
    pass
from app.db import connect, init_db  # noqa: E402
from app.detection.engine import run_detection  # noqa: E402
from app.ingest.csv_importer import import_file  # noqa: E402

c = connect()
init_db(c)
for f, store in (("splitpos_transactions.csv", "main"), ("splitpos_cashup.csv", "main"),
                 ("harbor_transactions.csv", "harbor"), ("harbor_cashup.csv", "harbor"),
                 ("splitpos_timeclock.csv", "main"), ("harbor_timeclock.csv", "harbor")):
    p = ROOT / "sample_data" / f
    if p.exists():
        print(import_file(c, p.read_bytes(), f, store=store)["rows_added"], "rows from", f, "->", store)
c.execute("UPDATE stores SET name='Downtown Cafe', open_hour=6, close_hour=23 WHERE id='main'")
c.execute("UPDATE stores SET name='Harbor Street', open_hour=6, close_hour=23 WHERE id='harbor'")
c.commit()
print(run_detection(c)["new_count"], "alerts created")
