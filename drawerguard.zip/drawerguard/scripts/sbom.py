"""Generate a CycloneDX 1.5 SBOM (JSON) for DrawerGuard's Python dependencies.

Walks requirements.txt and every transitive dependency of the installed packages via
importlib.metadata (no extra tools needed), with versions, licences and PURLs.

    python scripts/sbom.py [--out sbom.cdx.json]
"""
import argparse
import json
import re
import sys
import uuid
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def top_level() -> list[str]:
    out = []
    for line in (ROOT / "requirements.txt").read_text().splitlines():
        line = line.split("#")[0].strip()
        if line and not line.startswith("-"):
            out.append(norm(re.split(r"[<>=!~\[; ]", line)[0]))
    return out


def deps_of(dist) -> list[str]:
    out = []
    for req in dist.requires or []:
        if "extra ==" in req:
            continue
        out.append(norm(re.split(r"[<>=!~\[; (]", req)[0]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(ROOT / "sbom.cdx.json"))
    a = ap.parse_args()
    from app import __version__
    seen, queue, comps, graph = {}, top_level(), [], []
    while queue:
        name = queue.pop()
        if name in seen:
            continue
        try:
            dist = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            seen[name] = None
            continue
        seen[name] = dist.version
        md = dist.metadata
        lic = md.get("License-Expression") or md.get("License") or ""
        classifiers = [c.split("::")[-1].strip() for c in md.get_all("Classifier") or [] if c.startswith("License ::")]
        ref = f"pkg:pypi/{name}@{dist.version}"
        comp = {"type": "library", "bom-ref": ref, "name": name, "version": dist.version, "purl": ref}
        lic_name = (lic if lic and len(lic) < 80 else (classifiers[0] if classifiers else ""))
        if lic_name:
            comp["licenses"] = [{"license": {"name": lic_name}}]
        comps.append(comp)
        children = deps_of(dist)
        graph.append((ref, children))
        queue.extend(children)
    refs = {c["name"]: c["bom-ref"] for c in comps}
    bom = {
        "bomFormat": "CycloneDX", "specVersion": "1.5", "serialNumber": f"urn:uuid:{uuid.uuid4()}", "version": 1,
        "metadata": {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "tools": {"components": [{"type": "application", "name": "drawerguard-sbom", "version": __version__}]},
                     "component": {"type": "application", "bom-ref": f"pkg:generic/drawerguard@{__version__}", "name": "drawerguard",
                                   "version": __version__, "licenses": [{"license": {"id": "MIT"}}]}},
        "components": sorted(comps, key=lambda c: c["name"]),
        "dependencies": [{"ref": f"pkg:generic/drawerguard@{__version__}", "dependsOn": [refs[n] for n in top_level() if n in refs]}]
                        + [{"ref": r, "dependsOn": sorted({refs[c] for c in ch if c in refs})} for r, ch in graph],
    }
    Path(a.out).write_text(json.dumps(bom, indent=2))
    print(f"Wrote {a.out}: {len(comps)} components")


if __name__ == "__main__":
    main()
