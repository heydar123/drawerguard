"""Send existing DrawerGuard alerts to the SIEM destinations configured in .env (backfill).

Useful after setting up the SIEM lab: new alerts are forwarded automatically, this
sends the history. Elasticsearch uses the alert fingerprint as document id, so running
it twice doesn't create duplicates.

    python scripts/siem_replay.py [--since 2026-10-01] [--min-severity 1] [--dry-run]
"""
import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
except ImportError:
    pass

from app import siem  # noqa: E402
from app.db import connect, rows  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="")
    ap.add_argument("--min-severity", type=int, default=1)
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    conn = connect(os.environ.get("DRAWERGUARD_DB"))
    alerts = rows(conn.execute("SELECT * FROM alerts WHERE severity >= ? AND (ts >= ? OR ? = '') ORDER BY ts",
                               (a.min_severity, a.since, a.since)))
    dest = [k for k, v in siem.configured().items() if v]
    print(f"{len(alerts)} alerts → {', '.join(dest) or 'no destination configured (set SIEM_* in .env)'}")
    if a.dry_run or not dest:
        print(siem.to_cef(alerts[0]) if alerts else "")
        return
    for i in range(0, len(alerts), a.batch):
        print(f"  batch {i // a.batch + 1}:", siem.forward(alerts[i:i + a.batch]))


if __name__ == "__main__":
    main()
