"""Measure detection accuracy on labelled synthetic data.

Generates several independent datasets (different random seeds), each with
2 stores, 9 honest cashiers and 4 thieves using different schemes, two of whom
start stealing part-way through. Runs the full engine and reports:
  * cashier-level precision / recall of "high risk" (score >= 60)
  * per-detection alert precision (alert counts as true if it's on a thief,
    after that thief started stealing)
  * time-to-detect for each thief
Writes docs/EVALUATION.md.     Usage: python scripts/evaluate.py [--seeds 5]
"""
import argparse
import os
import sys
import tempfile
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("DRAWERGUARD_DATA", tempfile.mkdtemp())

from app.config import DEFAULT_RULES, PAYROLL_RULES  # noqa: E402
from app.db import connect, init_db  # noqa: E402
from app.detection.catalog import CATALOG  # noqa: E402
from app.detection.engine import PEER_RULES, cashier_scores, run_detection  # noqa: E402
from app.ingest.csv_importer import import_file  # noqa: E402
from sample_data.generate_demo import STORES, Gen  # noqa: E402

END, DAYS = datetime(2026, 11, 8), 45


def run_seed(seed: int) -> dict:
    tmp = Path(tempfile.mkdtemp())
    conn = connect(str(tmp / "eval.db"))
    init_db(conn)
    truth = {}                                   # (store, cashier) -> start date or None
    payroll_truth = {}                           # (store, employee) -> payroll scheme
    for store, name in (("main", "splitpos"), ("harbor", "harbor")):
        g = Gen(seed, store)
        g.run(END, DAYS)
        g.write(tmp, name)
        import_file(conn, (tmp / f"{name}_transactions.csv").read_bytes(), "t.csv", store=store)
        import_file(conn, (tmp / f"{name}_cashup.csv").read_bytes(), "c.csv", store=store)
        import_file(conn, (tmp / f"{name}_timeclock.csv").read_bytes(), "tc.csv", store=store)
        for emp, scheme in g.payroll_truth.items():
            payroll_truth[(store, emp)] = scheme
        first = END - timedelta(days=DAYS - 1)
        for c in g.cashiers:
            role = STORES[store]["thieves"].get(c)
            truth[(store, c)] = (first + timedelta(days=role[1])).strftime("%Y-%m-%d") if role else None
    run_detection(conn)

    res = {"tp": 0, "fp": 0, "fn": 0, "tn": 0, "rule": defaultdict(lambda: [0, 0]), "ttd": {}, "ttd_ai": {},
           "payroll": defaultdict(lambda: [0, 0]), "payroll_found": defaultdict(lambda: [0, 0])}
    for store in ("main", "harbor"):
        for s in cashier_scores(conn, 0, [store]):
            thief = truth.get((store, s["cashier"])) is not None
            high = s["level"] == "high"
            res["tp" if thief and high else "fp" if high else "fn" if thief else "tn"] += 1
    hit = set()
    for a in conn.execute("SELECT store, cashier, rule, severity, ts FROM alerts"):
        if a["rule"] in PAYROLL_RULES:
            ok = payroll_truth.get((a["store"], a["cashier"])) == a["rule"]
            res["payroll"][a["rule"]][0 if ok else 1] += 1
            if ok:
                hit.add((a["store"], a["cashier"], a["rule"]))
            continue
        start = truth.get((a["store"], a["cashier"]))
        monthly = a["rule"] in PEER_RULES                 # stamped on the 1st of the month they cover
        ok = start is not None and ((a["ts"] or "")[:7] >= start[:7] if monthly else (a["ts"] or "")[:10] >= start)
        res["rule"][a["rule"]][0 if ok else 1] += 1
        if ok and a["severity"] >= 4 and not monthly:
            d = (datetime.fromisoformat(a["ts"][:10]) - datetime.fromisoformat(start)).days
            key = f"{a['cashier']} ({a['store']})"
            res["ttd"][key] = min(res["ttd"].get(key, 99), d)
        if ok and a["rule"] in ("ai_anomaly", "behavior_change"):
            d = (datetime.fromisoformat(a["ts"][:10]) - datetime.fromisoformat(start)).days
            key = f"{a['cashier']} ({a['store']})"
            res["ttd_ai"][key] = min(res["ttd_ai"].get(key, 99), d)
    for (store, emp), scheme in payroll_truth.items():
        res["payroll_found"][scheme][0 if (store, emp, scheme) in hit else 1] += 1
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=5)
    a = ap.parse_args()
    runs = [run_seed(s) for s in range(1, a.seeds + 1)]
    tp, fp, fn, tn = (sum(r[k] for r in runs) for k in ("tp", "fp", "fn", "tn"))
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn, 1)
    rules = defaultdict(lambda: [0, 0])
    for r in runs:
        for k, (t, f) in r["rule"].items():
            rules[k][0] += t
            rules[k][1] += f
    ttd = defaultdict(list)
    ttd_ai = defaultdict(list)
    for r in runs:
        for k, v in r["ttd"].items():
            ttd[k].append(v)
        for k, v in r["ttd_ai"].items():
            ttd_ai[k].append(v)
    hi_t = sum(t for k, (t, f) in rules.items() if DEFAULT_RULES[k]["severity"] >= 4)
    hi_f = sum(f for k, (t, f) in rules.items() if DEFAULT_RULES[k]["severity"] >= 4)

    lines = [
        "# Detection evaluation", "",
        f"Generated by `scripts/evaluate.py` on {datetime.now():%Y-%m-%d}. {a.seeds} independent synthetic datasets (random seeds 1–{a.seeds}),",
        f"each with 2 stores, {DAYS} days, ~18,000 transactions, 7 honest cashiers and 5 thieves using different schemes",
        "(cash skimming via No-Sale, refund fraud, sweethearting/void fraud, a late-starting skimmer, and a cashier colluding with a manager).", "",
        "> ⚠️ This is **synthetic** data with known ground truth. It shows that the detections do what they are designed to do.",
        "> It is not a guarantee of real-world accuracy, which depends on how each business uses its POS.", "",
        "## Cashier-level (risk score ≥ 60 = flagged)", "",
        "| Metric | Value |", "|---|---|",
        f"| Precision | **{prec:.0%}** ({tp} of {tp + fp} flagged cashiers were thieves) |",
        f"| Recall | **{rec:.0%}** ({tp} of {tp + fn} thieves flagged) |",
        f"| False positives | {fp} of {fp + tn} honest cashiers |", "",
        f"High/critical alerts (severity ≥ 4): **{hi_t / max(hi_t + hi_f, 1):.0%} precision** ({hi_t:,} of {hi_t + hi_f:,} on actual thieves).", "",
        "## Time to detect (days from first theft to first high-severity alert)", "",
        "Monthly peer-comparison detections are excluded here because they are stamped at the start of the month they cover.", "",
        "| Thief | Median days (any rule) | Median days (AI rules) |", "|---|---|---|",
    ]
    for k in sorted(ttd):
        v, w = sorted(ttd[k]), sorted(ttd_ai.get(k, []))
        lines.append(f"| {k} | {v[len(v) // 2]} | {w[len(w) // 2] if w else '—'} |")
    lines += ["", "## Per-detection alert precision", "", "| ID | Detection | Alerts | On thieves | Precision |", "|---|---|---|---|---|"]
    for k, (t, f) in sorted(rules.items(), key=lambda kv: CATALOG[kv[0]]["id"]):
        if k in PAYROLL_RULES:
            continue
        lines.append(f"| {CATALOG[k]['id']} | {DEFAULT_RULES[k]['label']} | {t + f:,} | {t:,} | {t / max(t + f, 1):.0%} |")
    pay, found = defaultdict(lambda: [0, 0]), defaultdict(lambda: [0, 0])
    for r in runs:
        for k, (t, f) in r["payroll"].items():
            pay[k][0] += t
            pay[k][1] += f
        for k, (t, f) in r["payroll_found"].items():
            found[k][0] += t
            found[k][1] += f
    lines += ["", "## Payroll and timeclock fraud", "",
              "Each dataset also has a timeclock export with a ghost employee, timecard inflation by manual edits, a buddy-punching pair,",
              "a cashier whose login is used after they clock out, and a cashier who pads their hours. An alert counts as correct when it",
              "names the employee involved in that exact scheme.", "",
              "| ID | Detection | Alerts | Correct | Precision | Employees caught |", "|---|---|---|---|---|---|"]
    for k in sorted((set(pay) | set(found)) & set(CATALOG), key=lambda x: CATALOG[x]["id"]):
        t, f = pay.get(k, [0, 0])
        ft, ff = found.get(k, [0, 0])
        lines.append(f"| {CATALOG[k]['id']} | {DEFAULT_RULES[k]['label']} | {t + f:,} | {t:,} | {t / max(t + f, 1):.0%} | {ft} of {ft + ff} |")
    lines += ["", "Low-severity detections (e.g. paid-outs, round refunds) are expected to have lower precision. They are context signals,",
              "and the risk score weights them lightly. Tune thresholds on the **Detection rules** page."]
    out = ROOT / "docs" / "EVALUATION.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text("\n".join(lines) + "\n")
    print("\n".join(lines[:20]))
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
