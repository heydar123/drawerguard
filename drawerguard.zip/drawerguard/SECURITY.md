# Security policy

## Reporting a vulnerability
Please don't open a public issue. Use GitHub's **"Report a vulnerability"** (Security → Advisories) on this repository, and include steps to reproduce. You'll get a reply within 7 days.

## Security features
- PBKDF2-SHA256 password hashing (200,000 iterations, per-user salt)
- TOTP two-factor authentication (RFC 6238) with replay protection
- Role-based, store-scoped access control (owner / manager / auditor)
- Login lockout after repeated failures; failed logins are audited
- Sessions are revoked when the password changes, with "sign out everywhere" and admin sign-out
- Sign-in telemetry, new-device alerts, per-IP blocking and password-spraying detection
- API keys: shown once, stored as SHA-256, scoped (read / ingest, per store), rate-limited, revocable
- Threat-hunting SQL runs in a read-only sandbox (SQLite authorizer, table allow-list, timeout)
- Evidence chain of custody: SHA-256 on upload, verification, hashed evidence package
- HMAC-signed outbound webhooks
- Detections are code (`detections/*.toml`) with tests that run in CI, so a weakened detection fails the build
- Purple-team simulator (owner only, in memory, audited) to verify coverage after any change
- Tamper-evident, SHA-256 hash-chained audit log with in-app verification
- Real-time alert forwarding to SIEM (CEF/syslog, Splunk HEC, ECS JSON)
- Security headers: CSP, X-Frame-Options, nosniff, Referrer-Policy, no-store on API responses
- Evidence uploads: extension allow-list, size limits, random filenames, authenticated download only
- CI: ruff (incl. flake8-bandit rules), bandit SAST, and pip-audit dependency scanning on every push

See [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md) for the STRIDE analysis and the known residual risks, and
[docs/APPSEC.md](docs/APPSEC.md) for the OWASP Top 10 / ASVS mapping and the security tests that run in CI
(attack tests, fuzzing, bandit, CodeQL, gitleaks, pip-audit, ZAP, SBOM).

## Deployment hardening checklist
- [ ] Set a strong `DRAWERGUARD_PASSWORD` and a random `DRAWERGUARD_SECRET` in `.env`
- [ ] Turn on 2FA for every owner and manager account
- [ ] Give cashiers **no** account; give managers only their own stores
- [ ] Forward alerts to a SIEM or an external log, so evidence survives local tampering
- [ ] Use `HOST=127.0.0.1` if phones don't need access; otherwise keep it on a trusted Wi-Fi or put it behind HTTPS
- [ ] Keep `BACKUP_DAILY=1` and copy `data/backups` and `data/evidence` off the PC regularly
- [ ] Set `SIEM_WEBHOOK_SECRET` if you use a webhook; give API keys the smallest scope that works
- [ ] Leave `TRUST_PROXY=0` unless you run behind a reverse proxy you control
- [ ] Docker: keep the provided `read_only`, `cap_drop: ALL` and `no-new-privileges` settings (`.dockerignore` keeps `.env` and databases out of the image)
- [ ] After changing thresholds, re-run the purple-team simulation and check the coverage matrix
- [ ] Set `PASSWORD_MIN_LENGTH=12`, keep `LOCKOUT_MINUTES=30` and `IDLE_TIMEOUT_MINUTES=15`; plant at least one canary code
- [ ] Review the Compliance page monthly and export the evidence report for your records
