"""Write the demo data for one day as Square, Toast and Clover exports (sample_data/vendors/).

These files show the column layouts DrawerGuard's import adapters understand and are
used by the tests. Usage:  python sample_data/make_vendor_samples.py
"""
import csv
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE / "vendors"


def load(day: str):
    rows = list(csv.DictReader(open(HERE / "splitpos_transactions.csv", newline="")))
    out = []
    for r in rows:
        d = datetime.strptime(f"{r['Date']} {r['Time']}", "%m/%d/%Y %H:%M:%S")
        if d.strftime("%Y-%m-%d") == day:
            out.append((d, r))
    return out


def main(day="2026-10-20"):
    OUT.mkdir(exist_ok=True)
    data = load(day)
    cash = lambda r: r["Payment Type"] == "Cash"  # noqa: E731
    amt = lambda r: float(r["Total"].replace("$", "") or 0)  # noqa: E731

    with open(OUT / "square_transactions.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Date", "Time", "Time Zone", "Gross Sales", "Discounts", "Net Sales", "Tip", "Partial Refunds", "Total Collected",
                    "Source", "Card", "Cash", "Card Brand", "Transaction ID", "Payment ID", "Device Name", "Staff Name", "Event Type",
                    "Location", "Description"])
        for d, r in data:
            if r["Type"] not in ("Sale", "Refund"):
                continue
            a = amt(r)
            sign = -1 if r["Type"] == "Refund" else 1
            disc = float(r["Discount"] or 0)
            w.writerow([d.strftime("%m/%d/%Y"), d.strftime("%H:%M:%S"), "Eastern Time", f"{a + disc:.2f}", f"-{disc:.2f}" if disc else "0.00",
                        f"{a:.2f}", "0.00", "0.00", f"{sign * a:.2f}", "Square Point of Sale", "" if cash(r) else f"{sign * a:.2f}",
                        f"{sign * a:.2f}" if cash(r) else "", "" if cash(r) else "Visa", f"SQT{r['Order No'] or r['Receipt No']}",
                        f"SQP{r['Receipt No']}", r["Terminal"], r["Staff"], "Refund" if sign < 0 else "Payment", "Downtown Cafe",
                        r["Reason"]])
    with open(OUT / "square_cash_drawer.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Date", "Time", "Cash Drawer", "Event Type", "Description", "Amount", "Staff Name"])
        for d, r in data:
            if r["Type"] in ("No Sale", "Paid Out"):
                w.writerow([d.strftime("%m/%d/%Y"), d.strftime("%H:%M:%S"), r["Terminal"], r["Type"], r["Reason"], f"{amt(r):.2f}", r["Staff"]])

    with open(OUT / "toast_PaymentDetails.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Location", "Payment Id", "Order Id", "Order #", "Paid Date", "Order Date", "Server", "Amount", "Tip", "Total",
                    "Refunded", "Refund Date", "Refund Amount", "Void User", "Void Approver", "Void Date", "Status", "Type", "Cash Drawer"])
        refunds = {r["Original Receipt"]: (d, r) for d, r in data if r["Type"] == "Refund" and r["Original Receipt"]}
        for d, r in data:
            if r["Type"] != "Sale":
                continue
            ref = refunds.get(r["Receipt No"])
            ts = d.strftime("%m/%d/%Y %I:%M %p")
            w.writerow(["Downtown Cafe", r["Receipt No"], f"O{r['Order No']}", r["Order No"], ts, ts, r["Staff"], f"{amt(r):.2f}", "0.00",
                        f"{amt(r):.2f}", "FULL" if ref else "", ref[0].strftime("%m/%d/%Y %I:%M %p") if ref else "",
                        f"{amt(ref[1]):.2f}" if ref else "", "", "", "", "CAPTURED", "Cash" if cash(r) else "Credit", r["Terminal"]])
    with open(OUT / "toast_CashEntries.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Location", "Entry Id", "Created Date", "Action", "Amount", "Cash Drawer", "Payout Reason", "No Sale Reason", "Comment",
                    "Employee", "Employee 2"])
        for i, (d, r) in enumerate(data):
            if r["Type"] in ("No Sale", "Paid Out"):
                act = "NO_SALE" if r["Type"] == "No Sale" else "PAY_OUT"
                w.writerow(["Downtown Cafe", f"CE{i}", d.strftime("%m/%d/%Y %H:%M:%S"), act, f"{amt(r):.2f}", r["Terminal"],
                            r["Reason"] if act == "PAY_OUT" else "", r["Reason"] if act == "NO_SALE" else "", "", r["Staff"], r["Approved By"]])

    with open(OUT / "clover_payments.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Payment ID", "Order ID", "Payment Date", "Employee", "Device", "Tender", "Amount", "Result", "Original Payment ID", "Note"])
        for d, r in data:
            if r["Type"] in ("Sale", "Refund", "Item Void"):
                res = {"Sale": "SUCCESS", "Refund": "REFUND", "Item Void": "VOID"}[r["Type"]]
                w.writerow([r["Receipt No"], r["Order No"], d.strftime("%Y-%m-%d %H:%M:%S"), r["Staff"], r["Terminal"],
                            r["Payment Type"] or "Cash", f"{amt(r):.2f}", res, r["Original Receipt"], r["Reason"]])
    with open(OUT / "clover_cash_log.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Date", "Employee", "Device", "Event Type", "Cash Amount", "Note"])
        for d, r in data:
            if r["Type"] in ("No Sale", "Paid Out"):
                w.writerow([d.strftime("%Y-%m-%d %H:%M:%S"), r["Staff"], r["Terminal"], "Open drawer" if r["Type"] == "No Sale" else "Cash removed",
                            f"{amt(r):.2f}", r["Reason"]])
    print("Wrote", ", ".join(p.name for p in sorted(OUT.glob("*.csv"))))


if __name__ == "__main__":
    main()
