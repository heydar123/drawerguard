"""Generate realistic demo exports in SplitAbility-style CSV format.

Two stores, 45 days.
DOWNTOWN (main): busy cafe, 7 cashiers on 2 tills. Three cashiers secretly steal:
  * Jake M.  — skims cash: doesn't ring some cash sales, opens drawer with No Sale,
               drawer comes up short.
  * Tina R.  — refund fraud: fake cash refunds with no receipt, cash refunds of card
               sales, refunds her own sales, approves her own overrides.
  * Leo K.   — "sweethearting": big unapproved comps/discounts, voids items after the
               customer paid cash, cancels orders after food went to the kitchen.
               Leo only STARTS doing this 3 weeks in (the AI "behaviour change" rule catches it).
               Jake also "forgets" to count his drawer at some cash-ups.
HARBOR STREET: smaller cafe, 5 cashiers.
  * Nina R.  — starts skimming (No-Sales and short drawers) halfway through the period.
  * Sofia V. — COLLUSION: refunds earlier cash sales to "customers" who never came back,
               always approved by the same manager (Rita). Each refund looks legitimate on
               its own (real original receipt, approved, not a round amount): only the
               approver-concentration detection and behaviour analytics catch it.
Everyone else is honest but has normal day-to-day noise.

PAYROLL (timeclock export, v4) — separate from cash theft:
  * DOWNTOWN: "Kevin D." is a GHOST EMPLOYEE: punched in and out every weekday by Sam from
    the office PC, never rings a sale. Chris W.'s timecard is inflated by manual edits (Sam).
    Two honest cashiers BUDDY-PUNCH: one clocks the other in when they arrive late.
  * HARBOR: Ben T. leaves early but his colleague keeps using his POS login (sales while he
    is clocked out). Grace L. pads her hours: clocks in an hour early, out an hour late.

Usage:  python sample_data/generate_demo.py [out_dir] [--end 2026-11-08] [--days 45]
"""
import argparse
import csv
import random
from datetime import datetime, timedelta
from pathlib import Path

STORES = {
    "main": {"honest": ["Maria S.", "Daniel P.", "Aisha K.", "Chris W."], "prefix": "R",
             "thieves": {"Jake M.": ("skimmer", 0), "Tina R.": ("refunds", 0), "Leo K.": ("sweetheart", 21)}},
    "harbor": {"honest": ["Omar H.", "Grace L.", "Ben T."], "prefix": "H",
               "thieves": {"Nina R.": ("skimmer", 23), "Sofia V.": ("collusion", 0)}},
}
MANAGERS = ["Sam (Manager)", "Rita (Manager)"]
PAYROLL = {
    "main": {"ghost": ("Kevin D.", "Sam (Manager)"), "edits": ("Chris W.", "Sam (Manager)"), "buddy": True},
    "harbor": {"login_sharing": "Ben T.", "padding": "Grace L.", "buddy": False},
}
ACCOMPLICE = "Rita (Manager)"
TILLS = ["Till 1", "Till 2"]
REASONS_VOID = ["Wrong item", "Customer changed mind", "Duplicate", "Mistake"]
REASONS_REFUND = ["Cold food", "Wrong order", "Customer complaint", "Overcharged"]


class Gen:
    def __init__(self, seed=7, store="main"):
        cfg = STORES[store]
        self.r = random.Random(seed + (0 if store == "main" else 1000))
        self.txns, self.shifts = [], []
        self.n = 100000
        self.prefix = cfg["prefix"]
        self.thieves = cfg["thieves"]
        self.cashiers = cfg["honest"] + list(self.thieves)
        self.day_index = 0
        self.store = store
        self.seed = seed
        self.punches, self.payroll_truth = [], {}

    def rid(self):
        self.n += 1
        return f"{self.prefix}{self.n}"

    def role_of(self, cashier):
        role, start = self.thieves.get(cashier, (None, 0))
        return role if role and self.day_index >= start else None

    def add(self, ts, cashier, till, typ, amount=0.0, pay="", order="", orig="", disc=0.0, appr="", kitchen=False, note=""):
        t = dict(id=self.rid(), ts=ts, cashier=cashier, till=till, type=typ, amount=round(amount, 2), pay=pay,
                 order=order, orig=orig, disc=round(disc, 2), appr=appr, kitchen=kitchen, note=note)
        self.txns.append(t)
        return t

    def basket(self):
        r = self.r
        return round(r.choice([3.5, 4.2, 4.8, 5.5, 6.9, 8.5, 9.9, 12.5, 14.0, 16.8, 18.5, 22.0, 27.5, 34.0, 41.0]) + r.choice([0, 0.5, 1.2, 2.6]), 2)

    def shift(self, day, till, cashier, start_h, end_h):
        r = self.r
        role = self.role_of(cashier)
        start = day.replace(hour=start_h, minute=0, second=0)
        end = day.replace(hour=end_h, minute=0, second=0)
        t = start + timedelta(minutes=r.randint(2, 8))
        float_ = 200.0
        cash_in = 0.0          # cash the system expects in the drawer
        stolen = 0.0           # cash physically removed
        sales_today = []
        order_no = 0
        while t < end - timedelta(minutes=5):
            order_no += 1
            order = f"{day:%m%d}{till[-1]}{start_h:02d}{order_no:03d}"
            amt = self.basket()
            cash = r.random() < 0.52
            food = r.random() < 0.6
            ts = t.isoformat()

            # --- honest pre-payment void (item removed before paying)
            if r.random() < 0.03:
                self.add(ts, cashier, till, "Item Void", round(r.uniform(3, 9), 2), order=order, note=r.choice(REASONS_VOID))
                t += timedelta(seconds=r.randint(20, 60))
                ts = t.isoformat()

            # --- SKIMMER: customer pays cash, sale never rung; drawer opened via No Sale
            if role == "skimmer" and cash and r.random() < 0.22:
                if r.random() < 0.6:
                    self.add(ts, cashier, till, "No Sale")
                t += timedelta(minutes=r.uniform(4, 11))
                continue

            disc = 0.0
            appr = ""
            if r.random() < 0.04:                                   # honest small discount
                disc = round(amt * r.choice([0.1, 0.15, 0.2]), 2)
                appr = r.choice(MANAGERS) if disc > 3 else ""
            if role == "sweetheart" and r.random() < 0.07:           # comps for friends
                disc = round(amt * r.choice([0.5, 0.7, 1.0]), 2)
                appr = ""
            paid = round(amt - disc, 2)
            pay = "Cash" if cash else r.choice(["EFTPOS", "Visa", "Mastercard", "Apple Pay"])
            s = self.add(ts, cashier, till, "Sale", paid, pay, order, disc=disc, appr=appr, kitchen=food)
            sales_today.append(s)
            if cash:
                cash_in += paid

            # --- SKIMMER: re-opens drawer right after cash sale
            if role == "skimmer" and cash and r.random() < 0.10:
                self.add((t + timedelta(seconds=r.randint(15, 80))).isoformat(), cashier, till, "No Sale")
                stolen += r.choice([5, 10, 10, 20])

            # --- SWEETHEART: void after cash payment, pocket the difference
            if role == "sweetheart" and cash and paid > 10 and r.random() < 0.06:
                v = round(paid * r.uniform(0.4, 0.9), 2)
                self.add((t + timedelta(minutes=r.randint(2, 9))).isoformat(), cashier, till, "Item Void", v, order=order, note="Wrong item")
                cash_in -= v
                stolen += v

            # --- honest refund of an earlier sale, approved
            if r.random() < 0.012 and len(sales_today) > 3:
                o = r.choice(sales_today[:-1])
                self.add((t + timedelta(minutes=1)).isoformat(), cashier, till, "Refund", o["amount"],
                         o["pay"], o["order"], orig=o["id"], appr=r.choice(MANAGERS), note=r.choice(REASONS_REFUND))
                if o["pay"] == "Cash":
                    cash_in -= o["amount"]

            # --- REFUND FRAUD
            if role == "refunds" and r.random() < 0.035:
                kind = r.random()
                rt = (t + timedelta(minutes=r.randint(1, 4))).isoformat()
                if kind < 0.5:      # fake refund, no receipt, round amount
                    v = r.choice([15, 20, 20, 25, 30, 40])
                    self.add(rt, cashier, till, "Refund", v, "Cash", appr=r.choice(["", "", cashier]), note=r.choice(REASONS_REFUND))
                elif kind < 0.75:   # card sale refunded in cash
                    cards = [x for x in sales_today if x["pay"] != "Cash" and x["amount"] > 8]
                    if not cards:
                        continue
                    o = r.choice(cards)
                    v = o["amount"]
                    self.add(rt, cashier, till, "Refund", v, "Cash", o["order"], orig=o["id"], appr=cashier, note="Customer complaint")
                else:               # refund own cash sale minutes later
                    o = s
                    v = o["amount"]
                    self.add(rt, cashier, till, "Refund", v, "Cash", o["order"], orig=o["id"], note="Wrong order")
                cash_in -= v

            # --- COLLUSION: refund an earlier cash sale (customer long gone), approved by the accomplice
            if role == "collusion" and r.random() < 0.06:
                old = [x for x in sales_today if x["pay"] == "Cash" and x["amount"] > 6
                       and (t - datetime.fromisoformat(x["ts"])) > timedelta(minutes=35) and not x.get("refunded")]
                if old:
                    o = r.choice(old)
                    o["refunded"] = True
                    self.add((t + timedelta(minutes=r.randint(1, 3))).isoformat(), cashier, till, "Refund", o["amount"], "Cash",
                             o["order"], orig=o["id"], appr=ACCOMPLICE, note=r.choice(REASONS_REFUND))
                    cash_in -= o["amount"]

            # --- cancelled orders
            if r.random() < 0.01:
                self.add((t + timedelta(minutes=1)).isoformat(), cashier, till, "Cancelled", self.basket(),
                         order=f"{order}C", kitchen=False, note="Customer left")
            if role == "sweetheart" and r.random() < 0.035:
                self.add((t + timedelta(minutes=r.randint(5, 15))).isoformat(), cashier, till, "Cancelled", self.basket(),
                         order=f"{order}X", kitchen=True, note="Customer left")

            # --- honest No Sale for change, a few minutes after a sale
            if r.random() < 0.02:
                self.add((t + timedelta(minutes=r.uniform(3, 6))).isoformat(), cashier, till, "No Sale", note="Change for customer")

            # --- paid outs
            if r.random() < 0.004:
                v = round(r.uniform(25, 60), 2)
                self.add((t + timedelta(minutes=2)).isoformat(), cashier, till, "Paid Out", v, "Cash", appr=r.choice(MANAGERS), note="Milk / supplies")
                cash_in -= v
            if role == "skimmer" and r.random() < 0.004:
                v = r.choice([30, 40, 50])
                self.add((t + timedelta(minutes=2)).isoformat(), cashier, till, "Paid Out", v, "Cash", note="Supplies")
                cash_in -= v
                stolen += 0  # taken via a recorded paid-out with no receipt

            gap = r.uniform(4, 11) if 11 <= t.hour <= 14 or 7 <= t.hour <= 9 else r.uniform(7, 18)
            t += timedelta(minutes=gap)

        # skimmer: isolated drawer opens in quiet moments
        if role == "skimmer":
            for _ in range(r.randint(1, 3)):
                q = start + timedelta(minutes=r.randint(30, (end_h - start_h) * 60 - 30))
                self.add(q.isoformat(), cashier, till, "No Sale")
            if r.random() < 0.25:
                stolen += r.choice([20, 30, 40, 50, 60])

        expected = round(float_ + cash_in, 2)
        noise = round(r.choice([0, 0, 0, 0, -0.5, 0.2, -1.1, 1.0, -2.3, -6.0 if r.random() < 0.15 else 0]), 2)
        counted = round(expected - stolen + noise, 2) if role == "skimmer" else round(expected + noise, 2)
        # skimmers sometimes skip the count; honest staff very rarely forget
        if (role == "skimmer" and cashier == "Jake M." and r.random() < 0.18) or r.random() < 0.01:
            counted = None
        self.shifts.append(dict(cashier=cashier, till=till, start=start, end=end, float=float_, expected=expected, counted=counted))

    def run(self, end_day: datetime, days: int):
        r = self.r
        for d in range(days, 0, -1):
            self.day_index = days - d
            day = end_day - timedelta(days=d - 1)
            staff = self.cashiers[:]
            r.shuffle(staff)
            # thieves work most days
            for th in self.thieves:
                if r.random() < 0.75 and th not in staff[:4]:
                    staff.remove(th)
                    staff.insert(r.randint(0, 3), th)
            roster = staff[:4]
            self.shift(day, "Till 1", roster[0], 7, 15)
            self.shift(day, "Till 2", roster[1], 7, 15)
            self.shift(day, "Till 1", roster[2], 15, 22)
            self.shift(day, "Till 2", roster[3], 15, 22)
            # closing activity; skimmer sometimes comes back after close
            for th, (role, st) in self.thieves.items():
                if role == "skimmer" and th in roster[2:] and self.day_index >= st and r.random() < 0.12:
                    late = day.replace(hour=23, minute=r.randint(5, 50))
                    self.add(late.isoformat(), th, "Till 1", "No Sale")
        self.txns.sort(key=lambda x: x["ts"])
        self.make_timeclock(end_day, days)

    def make_timeclock(self, end_day: datetime, days: int):
        """Clock-in/out punches for every shift, with the payroll schemes from PAYROLL. Uses its own
        random stream so the POS data (and the cash-theft evaluation) is unchanged."""
        r = random.Random(self.seed * 31 + (0 if self.store == "main" else 77))
        cfg = PAYROLL[self.store]
        rate = {c: round(r.uniform(15, 19), 2) for c in self.cashiers}
        honest = [c for c in self.cashiers if c not in self.thieves and c not in (cfg.get("edits", ("",))[0],
                  cfg.get("login_sharing"), cfg.get("padding"))]
        pair = None
        if cfg.get("buddy"):                    # the two honest-looking staff who share the most working days
            days_of = {}
            for s in self.shifts:
                days_of.setdefault(s["cashier"], set()).add(s["start"].date())
            co = {(a, b): len(days_of.get(a, set()) & days_of.get(b, set())) for a in honest for b in honest if a < b}
            if co:
                pair = max(sorted(co), key=lambda k: co[k])
                self.payroll_truth[pair[0]] = self.payroll_truth[pair[1]] = "buddy_punch"   # they cover for each other
        first_in = {}
        for s in sorted(self.shifts, key=lambda x: (x["start"], x["cashier"])):
            c, start, end = s["cashier"], s["start"], s["end"]
            cin = start - timedelta(minutes=r.uniform(2, 25), seconds=r.randint(0, 59))
            cout = end + timedelta(minutes=r.uniform(1, 15), seconds=r.randint(0, 59))
            p = dict(employee=c, cin=cin, cout=cout, oin=None, oout=None, device="Clock 1", method="pin", editor="", note="", rate=rate[c])
            if c == cfg.get("padding"):
                self.payroll_truth[c] = "clock_padding"
                if r.random() < 0.5:
                    p["cin"] = start - timedelta(minutes=r.uniform(50, 80))
                if r.random() < 0.3:
                    p["cout"] = end + timedelta(minutes=r.uniform(50, 70))
            if c == cfg.get("login_sharing") and start.hour >= 15 and r.random() < 0.45:
                self.payroll_truth[c] = "clocked_out_activity"
                p["cout"] = end - timedelta(minutes=r.uniform(70, 120))
            if cfg.get("edits") and c == cfg["edits"][0] and r.random() < 0.45:
                self.payroll_truth[c] = "timecard_edit"
                p["oout"], p["cout"] = p["cout"], p["cout"] + timedelta(minutes=r.uniform(30, 75))
                p["editor"], p["note"] = cfg["edits"][1], "Forgot to clock out"
            elif r.random() < 0.02:
                p["oout"], p["cout"] = p["cout"], p["cout"] + timedelta(minutes=r.uniform(5, 20))
                p["editor"], p["note"] = r.choice(MANAGERS), "Missed punch"
            other = (pair[1] if c == pair[0] else pair[0]) if pair and c in pair else None
            friend, fstart = first_in.get((other, start.date()), (None, None)) if other else (None, None)
            if friend and r.random() < 0.9:                       # the friend clocks them in (arrived late)
                if fstart == start:              # same shift: right after their own clock-in
                    p["cin"] = friend["cin"] + timedelta(seconds=r.randint(5, 25))
                else:                                             # earlier shift: on the way out
                    friend["cout"] = start - timedelta(minutes=r.uniform(2, 8))
                    p["cin"] = friend["cout"] + timedelta(seconds=r.randint(5, 25))
            first_in[(c, start.date())] = (p, start)
            self.punches.append(p)
        if cfg.get("ghost"):
            ghost, mgr = cfg["ghost"]
            self.payroll_truth[ghost] = "ghost_employee"
            for d in range(days, 0, -1):
                day = end_day - timedelta(days=d - 1)
                if day.weekday() >= 5 or r.random() < 0.1:
                    continue
                cin = day.replace(hour=10, minute=0) + timedelta(minutes=r.uniform(0, 10))
                self.punches.append(dict(employee=ghost, cin=cin, cout=cin + timedelta(hours=r.uniform(6, 7)), oin=None, oout=None,
                                         device="Office PC", method="manager", editor=mgr, note="Entered by manager", rate=18.5))
        self.punches.sort(key=lambda p: p["cin"])

    def write(self, out: Path, name="splitpos"):
        out.mkdir(parents=True, exist_ok=True)
        with open(out / f"{name}_transactions.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["Receipt No", "Date", "Time", "Staff", "Terminal", "Type", "Payment Type", "Total",
                        "Discount", "Order No", "Original Receipt", "Approved By", "Sent To Kitchen", "Reason"])
            for t in self.txns:
                dt = datetime.fromisoformat(t["ts"])
                w.writerow([t["id"], dt.strftime("%m/%d/%Y"), dt.strftime("%H:%M:%S"), t["cashier"], t["till"], t["type"],
                            t["pay"], f"${t['amount']:.2f}", f"{t['disc']:.2f}" if t["disc"] else "", t["order"], t["orig"],
                            t["appr"], "Yes" if t["kitchen"] else "No", t["note"]])
        with open(out / f"{name}_cashup.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["Staff", "Terminal", "Shift Start", "Shift End", "Opening Float", "Expected Cash", "Counted Cash"])
            for s in self.shifts:
                w.writerow([s["cashier"], s["till"], s["start"].strftime("%m/%d/%Y %H:%M"), s["end"].strftime("%m/%d/%Y %H:%M"),
                            f"{s['float']:.2f}", f"{s['expected']:.2f}", "" if s["counted"] is None else f"{s['counted']:.2f}"])
        with open(out / f"{name}_timeclock.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["Employee", "Clock In", "Clock Out", "Original Clock In", "Original Clock Out", "Device", "Method",
                        "Edited By", "Edit Reason", "Hourly Rate"])
            fmt = "%m/%d/%Y %H:%M:%S"
            for p in self.punches:
                w.writerow([p["employee"], p["cin"].strftime(fmt), p["cout"].strftime(fmt), p["oin"].strftime(fmt) if p["oin"] else "",
                            p["oout"].strftime(fmt) if p["oout"] else "", p["device"], p["method"], p["editor"], p["note"], f"{p['rate']:.2f}"])
        return len(self.txns), len(self.shifts)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("out", nargs="?", default=str(Path(__file__).parent))
    ap.add_argument("--end", default="2026-11-08")
    ap.add_argument("--days", type=int, default=45)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    for store, name in (("main", "splitpos"), ("harbor", "harbor")):
        g = Gen(a.seed, store)
        g.run(datetime.fromisoformat(a.end), a.days)
        n, s = g.write(Path(a.out), name)
        print(f"{store}: wrote {n} transactions and {s} shifts to {a.out}")
