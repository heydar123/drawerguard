"""Incident grouping and the investigation (link-analysis) graph.

Incidents: analysts don't triage 800 alerts, they triage what happened. Alerts are
grouped by store + person + day (monthly peer comparisons by month), scored by
severity and by how many *different* detections agree, so one noisy rule can't
drown out a shift where five independent signals fire.

Graph: who works which till, who approves whose overrides, who punches in on which
clock, which people are linked by buddy punching or a canary, and which cases they
are in. Suspicious relationships (collusion, buddy punching, canaries) are flagged.
"""
import json
from collections import defaultdict

from .config import DECEPTION_RULES, PAYROLL_RULES
from .detection.engine import SEV_WEIGHT, alert_since_sql, cashier_scores

MONTHLY = ("peer_outlier", "low_cash_ratio")
ML = ("ai_anomaly", "behavior_change", "iforest_anomaly")


def _in(xs):
    return f"({','.join('?' * len(xs))})"


def _kind(rule: str) -> str:
    if rule in PAYROLL_RULES:
        return "payroll"
    if rule in DECEPTION_RULES:
        return "deception"
    if rule in ML:
        return "ai"
    return "cash"


def incidents(conn, stores: list[str], since: str | None, include_closed: bool = False, labels: dict | None = None) -> dict:
    w, p = alert_since_sql(since)
    q = f"SELECT id, store, rule, severity, cashier, ts, amount, title, status, assigned_to, case_id FROM alerts WHERE store IN {_in(stores)}{w}"
    if not include_closed:
        q += " AND status IN ('open','investigating')"
    groups = defaultdict(list)
    total = 0
    for r in conn.execute(q, [*stores, *p]):
        total += 1
        bucket = (r["ts"] or "")[:7] + " (month)" if r["rule"] in MONTHLY else (r["ts"] or "")[:10]
        groups[(r["store"], r["cashier"] or "—", bucket)].append(dict(r))
    out = []
    for (store, who, bucket), al in groups.items():
        rules = sorted({a["rule"] for a in al})
        max_sev = max(a["severity"] for a in al)
        score = sum(SEV_WEIGHT.get(a["severity"], 1) for a in al) + 4 * (len(rules) - 1)
        sev = min(5, max_sev + (1 if len(rules) >= 3 and max_sev >= 3 else 0))
        st = defaultdict(int)
        for a in al:
            st[a["status"]] += 1
        kinds = sorted({_kind(r) for r in rules})
        out.append({
            "key": f"{store}|{who}|{bucket}", "store": store, "who": who, "when": bucket, "severity": sev, "score": score,
            "alerts": len(al), "alert_ids": [a["id"] for a in sorted(al, key=lambda a: (-a["severity"], a["ts"] or ""))],
            "rules": rules, "labels": [(labels or {}).get(r, r) for r in rules], "kinds": kinds,
            "amount": round(sum(a["amount"] or 0 for a in al), 2), "first": min(a["ts"] or "" for a in al), "last": max(a["ts"] or "" for a in al),
            "status": "open" if st.get("open") else "investigating" if st.get("investigating") else max(st, key=st.get),
            "statuses": dict(st), "assigned": sorted({a["assigned_to"] for a in al if a["assigned_to"]}),
            "case_ids": sorted({a["case_id"] for a in al if a["case_id"]}),
            "headline": max(al, key=lambda a: (a["severity"], a["amount"] or 0))["title"],
        })
    out.sort(key=lambda x: (x["status"] not in ("open", "investigating"), -x["severity"], -x["score"]))
    return {"alerts": total, "incidents": len(out), "reduction_pct": round((1 - len(out) / total) * 100, 1) if total else 0,
            "critical": sum(1 for x in out if x["severity"] >= 5), "multi_signal": sum(1 for x in out if len(x["rules"]) >= 3),
            "items": out}


def graph(conn, stores: list[str], since: str | None, days: int | None) -> dict:
    nodes, edges = {}, defaultdict(lambda: {"weight": 0, "flags": set()})

    def node(nid, label, kind, **kw):
        n = nodes.setdefault(nid, {"id": nid, "label": label, "kind": kind, "roles": set(), "store": kw.get("store", "")})
        for k, v in kw.items():
            if k != "store":
                n[k] = v
        return n

    def edge(a, b, kind, w=1, flag=None):
        e = edges[(a, b, kind)]
        e["weight"] += w
        if flag:
            e["flags"].add(flag)

    scores = {s["cashier"]: s for s in cashier_scores(conn, days, stores)}
    tq = f"SELECT store, cashier, register, approved_by, txn_type FROM transactions WHERE store IN {_in(stores)}"
    tp = list(stores)
    if since:
        tq += " AND ts >= ?"
        tp.append(since)
    approvals = defaultdict(int)
    for t in conn.execute(tq, tp):
        pid = f"p:{t['cashier']}"
        s = scores.get(t["cashier"], {})
        node(pid, t["cashier"], "person", store=t["store"], score=s.get("score", 0), level=s.get("level", "low"))["roles"].add("cashier")
        if t["register"]:
            tid = f"t:{t['store']}|{t['register']}"
            node(tid, t["register"], "till", store=t["store"])
            edge(pid, tid, "works", 1)
        if t["approved_by"] and t["approved_by"] != t["cashier"]:
            approvals[(t["approved_by"], t["cashier"])] += 1
    canary_names = {r["value"].strip().lower() for r in conn.execute("SELECT value FROM canaries WHERE kind IN ('approver','employee')")}
    for (appr, cashier), n in approvals.items():
        if appr.strip().lower() in canary_names:          # drawn as a canary node below, not as a person
            continue
        aid = f"p:{appr}"
        s = scores.get(appr, {})
        node(aid, appr, "person", score=s.get("score", 0), level=s.get("level", "low"))["roles"].add("approver")
        edge(aid, f"p:{cashier}", "approves", n)
    pq = f"SELECT store, employee, device, method FROM timeclock WHERE store IN {_in(stores)}"
    pp = list(stores)
    if since:
        pq += " AND clock_in >= ?"
        pp.append(since)
    for r in conn.execute(pq, pp):
        pid = f"p:{r['employee']}"
        s = scores.get(r["employee"], {})
        node(pid, r["employee"], "person", store=r["store"], score=s.get("score", 0), level=s.get("level", "low"))["roles"].add("on the clock")
        did = f"d:{r['store']}|{r['device'] or '?'}"
        node(did, r["device"] or "time clock", "clock", store=r["store"])
        edge(pid, did, "punches", 1, "manager-entered" if r["method"] == "manager" else None)
    w, p = alert_since_sql(since)
    flagged = defaultdict(set)
    for a in conn.execute(f"SELECT store, rule, cashier, details, case_id FROM alerts WHERE status!='dismissed' AND store IN {_in(stores)} "
                          f"AND rule IN ('approver_concentration','buddy_punch','canary','ghost_employee','clocked_out_activity'){w}",
                          [*stores, *p]):
        try:
            d = json.loads(a["details"] or "{}")
        except ValueError:
            d = {}
        if a["rule"] == "approver_concentration" and d.get("approver"):
            edge(f"p:{d['approver']}", f"p:{a['cashier']}", "approves", 0, "collusion")
        elif a["rule"] == "buddy_punch" and d.get("partner"):
            edge(f"p:{d['partner']}", f"p:{a['cashier']}", "punches for", 1, "buddy punching")
            node(f"p:{d['partner']}", d["partner"], "person")
        elif a["rule"] == "canary":
            cid = f"k:{d.get('canary', '?')}"
            node(cid, d.get("canary", "canary"), "canary", store=a["store"])
            edge(f"p:{a['cashier']}", cid, "used", 1, "canary")
        flagged[f"p:{a['cashier']}"].add(a["rule"])
    for c in conn.execute(f"SELECT id, store, cashier, title, status FROM cases WHERE store IN {_in(stores)}", stores):
        cid = f"c:{c['id']}"
        node(cid, f"Case #{c['id']}", "case", store=c["store"], title=c["title"], status=c["status"])
        edge(cid, f"p:{c['cashier']}", "investigates", 1)
    for nid, rules in flagged.items():
        if nid in nodes:
            nodes[nid]["flags"] = sorted(rules)
    out_edges = [{"source": a, "target": b, "kind": k, "weight": e["weight"], "flags": sorted(e["flags"])}
                 for (a, b, k), e in edges.items() if a in nodes and b in nodes]
    for n in nodes.values():
        n["roles"] = sorted(n["roles"])
        n["degree"] = sum(1 for e in out_edges if n["id"] in (e["source"], e["target"]))
    return {"nodes": list(nodes.values()), "edges": out_edges,
            "suspicious": [e for e in out_edges if e["flags"] and e["flags"] != ["manager-entered"]]}
