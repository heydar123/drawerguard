"""Threat hunting: a sandboxed, read-only SQL workbench plus a library of ready-made hunts.

Defence in depth for user-supplied SQL:
  1. a separate connection opened read-only (SQLite URI mode=ro), so writes fail at the engine level
  2. sqlite3 authorizer: only SELECT/READ/FUNCTION/RECURSIVE are allowed, and only on an
     allow-list of tables (users, API keys, sign-in logs, audit log and settings are not readable)
  3. a progress handler aborts queries that run longer than HUNT_TIMEOUT seconds
  4. a row cap (results are truncated), and only one statement per call (sqlite3 rejects more)
"""
import json
import os
import re
import sqlite3
import time
import urllib.request

from .db import DB_PATH

READABLE = {"transactions", "shifts", "alerts", "cases", "case_events", "shift_anomaly", "stores", "alert_history", "evidence",
            "timeclock"}
MAX_ROWS = 2000
TIMEOUT = float(os.environ.get("HUNT_TIMEOUT", "5"))

SCHEMA_DOC = {
    "transactions": "store, id, ts (ISO text 'YYYY-MM-DDTHH:MM:SS'), cashier, register, txn_type (sale|refund|void|no_sale|discount|paid_out|cancel), "
                    "amount, payment_method (cash|card|other), order_id, original_txn_id, discount_amount, approved_by, sent_to_kitchen (0/1), note",
    "shifts": "store, cashier, register, start_ts, end_ts, opening_float, expected_cash, counted_cash (NULL = not counted)",
    "alerts": "id, store, rule, severity (1-5), cashier, register, ts, txn_id, amount, title, status (open|investigating|dismissed|confirmed), "
              "assigned_to, case_id, created_at, acked_at, resolved_at",
    "cases": "id, store, cashier, title, status, loss_amount, recovered, created_at",
    "shift_anomaly": "store, cashier, day, score (0-100), drivers (JSON)",
    "stores": "id, name, open_hour, close_hour",
    "timeclock": "store, employee, clock_in, clock_out, device, method (pin|badge|manager|app), edited_by, edit_note, minutes_added, hourly_rate",
}

LIBRARY = [
    {"name": "Paid hours vs POS activity per employee", "tactic": "Payroll",
     "description": "Hours on the clock next to transactions rung. Paid hours with zero POS activity is the classic ghost employee.",
     "sql": """WITH hrs AS (
  SELECT store, employee, COUNT(*) AS shifts,
    ROUND(SUM((julianday(clock_out) - julianday(clock_in)) * 24), 1) AS paid_hours,
    SUM(method = 'manager') AS punched_by_manager
  FROM timeclock GROUP BY store, employee),
pos AS (SELECT store, cashier, COUNT(*) AS txns FROM transactions GROUP BY store, cashier)
SELECT h.store, h.employee, h.shifts, h.paid_hours, h.punched_by_manager, COALESCE(p.txns, 0) AS pos_txns
FROM hrs h LEFT JOIN pos p ON p.store = h.store AND p.cashier = h.employee
ORDER BY pos_txns ASC, paid_hours DESC"""},
    {"name": "Punches seconds apart on the same clock", "tactic": "Payroll",
     "description": "Pairs of employees whose clock-ins are within 30 seconds on one device. Repeated pairs = buddy punching.",
     "sql": """SELECT a.store, a.employee AS first_punch, b.employee AS second_punch, a.device, COUNT(*) AS times,
  MIN(substr(a.clock_in, 1, 10)) AS first_day, MAX(substr(a.clock_in, 1, 10)) AS last_day
FROM timeclock a JOIN timeclock b ON a.store = b.store AND a.device = b.device AND a.employee != b.employee
 AND b.clock_in > a.clock_in AND b.clock_in <= strftime('%Y-%m-%dT%H:%M:%S', a.clock_in, '+30 seconds')
GROUP BY a.store, a.employee, b.employee, a.device
ORDER BY times DESC"""},
    {"name": "No-Sale right after a cash sale, by cashier", "tactic": "Skimming",
     "description": "Counts No-Sale drawer opens within 2 minutes after the same cashier's cash sale on the same till.",
     "sql": """SELECT ns.store, ns.cashier, COUNT(DISTINCT ns.id) AS no_sales_after_cash
FROM transactions ns
JOIN transactions s ON s.store = ns.store AND s.register = ns.register AND s.cashier = ns.cashier
 AND s.txn_type = 'sale' AND s.payment_method = 'cash'
 AND s.ts <= ns.ts AND s.ts >= strftime('%Y-%m-%dT%H:%M:%S', ns.ts, '-120 seconds')
WHERE ns.txn_type = 'no_sale'
GROUP BY ns.store, ns.cashier
ORDER BY no_sales_after_cash DESC"""},
    {"name": "Refund rate per cashier", "tactic": "False refunds",
     "description": "Refunds per 100 sales and refund value, by cashier. Compare people in the same store.",
     "sql": """SELECT store, cashier,
  SUM(txn_type = 'sale') AS sales,
  SUM(txn_type = 'refund') AS refunds,
  ROUND(SUM(CASE WHEN txn_type = 'refund' THEN amount ELSE 0 END), 2) AS refund_value,
  ROUND(100.0 * SUM(txn_type = 'refund') / MAX(SUM(txn_type = 'sale'), 1), 2) AS refunds_per_100_sales
FROM transactions
GROUP BY store, cashier
ORDER BY refunds_per_100_sales DESC"""},
    {"name": "Card sales refunded in cash", "tactic": "False refunds",
     "description": "Refund paid out in cash although the original sale was paid by card.",
     "sql": """SELECT r.ts, r.store, r.cashier, r.id AS refund, r.amount, o.id AS original_sale, o.payment_method AS original_tender
FROM transactions r
JOIN transactions o ON o.store = r.store AND o.id = r.original_txn_id
WHERE r.txn_type = 'refund' AND r.payment_method = 'cash' AND o.payment_method = 'card'
ORDER BY r.ts DESC"""},
    {"name": "Who approves whose overrides", "tactic": "Collusion",
     "description": "Approver × cashier matrix. One manager approving almost everything for one cashier is a collusion signal.",
     "sql": """SELECT store, approved_by AS approver, cashier, COUNT(*) AS approvals, ROUND(SUM(amount), 2) AS value
FROM transactions
WHERE approved_by != '' AND approved_by != cashier AND txn_type IN ('refund', 'void', 'paid_out', 'discount')
GROUP BY store, approver, cashier
ORDER BY approvals DESC"""},
    {"name": "Repeated refund amounts", "tactic": "False refunds",
     "description": "The same refund amount used again and again by one cashier is typical of made-up refunds.",
     "sql": """SELECT store, cashier, amount, COUNT(*) AS times
FROM transactions
WHERE txn_type = 'refund'
GROUP BY store, cashier, amount
HAVING times >= 3
ORDER BY times DESC"""},
    {"name": "Voids after cash payment on the same order", "tactic": "False voids",
     "description": "Items removed from an order after the customer already paid cash.",
     "sql": """SELECT v.ts, v.store, v.cashier, v.order_id, v.amount AS voided, s.amount AS paid
FROM transactions v
JOIN transactions s ON s.store = v.store AND s.order_id = v.order_id AND s.txn_type = 'sale'
 AND s.payment_method = 'cash' AND s.ts < v.ts
WHERE v.txn_type = 'void' AND v.order_id != ''
ORDER BY v.ts DESC"""},
    {"name": "Till activity outside opening hours", "tactic": "Cash larceny",
     "description": "Any event before the store opens or after it closes (store hours, default 6:00–23:00).",
     "sql": """SELECT t.ts, t.store, t.cashier, t.register, t.txn_type, t.amount
FROM transactions t JOIN stores st ON st.id = t.store
WHERE CAST(substr(t.ts, 12, 2) AS INTEGER) < COALESCE(st.open_hour, 6)
   OR CAST(substr(t.ts, 12, 2) AS INTEGER) >= COALESCE(st.close_hour, 23)
ORDER BY t.ts DESC"""},
    {"name": "Cash-up shortages by cashier", "tactic": "Cash larceny",
     "description": "Shifts counted short by more than $5, the total missing, and shifts never counted.",
     "sql": """SELECT store, cashier, COUNT(*) AS shifts,
  SUM(counted_cash < expected_cash - 5) AS short_shifts,
  ROUND(SUM(CASE WHEN counted_cash < expected_cash THEN expected_cash - counted_cash ELSE 0 END), 2) AS total_short,
  SUM(counted_cash IS NULL AND expected_cash IS NOT NULL) AS not_counted
FROM shifts
GROUP BY store, cashier
ORDER BY total_short DESC"""},
    {"name": "Cash share of sales by cashier", "tactic": "Skimming",
     "description": "A cashier whose customers 'pay by card' far more often than everyone else's may not be ringing cash sales.",
     "sql": """SELECT store, cashier, COUNT(*) AS sales,
  ROUND(100.0 * SUM(payment_method = 'cash') / COUNT(*), 1) AS cash_pct_of_sales
FROM transactions
WHERE txn_type = 'sale'
GROUP BY store, cashier
HAVING sales >= 30
ORDER BY cash_pct_of_sales ASC"""},
    {"name": "Most unusual days (AI score)", "tactic": "Behavioural",
     "description": "The 50 highest AI shift scores in the last 14 days of data.",
     "sql": """SELECT store, cashier, day, score
FROM shift_anomaly
WHERE day >= date((SELECT MAX(day) FROM shift_anomaly), '-14 days')
ORDER BY score DESC
LIMIT 50"""},
    {"name": "Open high-severity alerts by cashier and detection", "tactic": "Triage",
     "description": "Where the open, high-severity work is.",
     "sql": """SELECT store, cashier, rule, COUNT(*) AS alerts, ROUND(SUM(amount), 2) AS value
FROM alerts
WHERE status IN ('open', 'investigating') AND severity >= 4
GROUP BY store, cashier, rule
ORDER BY alerts DESC"""},
    {"name": "Orders cancelled after reaching the kitchen", "tactic": "Skimming",
     "description": "Food was made but the order was cancelled: was it handed over and paid in cash?",
     "sql": """SELECT ts, store, cashier, order_id, amount, note
FROM transactions
WHERE txn_type = 'cancel' AND sent_to_kitchen = 1
ORDER BY ts DESC"""},
]


class HuntError(ValueError):
    pass


DENY_FUNCS = {"load_extension", "readfile", "writefile", "edit", "fts3_tokenizer", "sqlite_offset"}


def _make_authorizer(real_tables: set[str]):
    forbidden = {t.lower() for t in real_tables} - READABLE

    def authorizer(action, arg1, arg2, dbname, source):
        if action == sqlite3.SQLITE_FUNCTION:
            return sqlite3.SQLITE_DENY if (arg2 or "").lower() in DENY_FUNCS else sqlite3.SQLITE_OK
        if action in (sqlite3.SQLITE_SELECT, sqlite3.SQLITE_RECURSIVE):
            return sqlite3.SQLITE_OK
        if action == sqlite3.SQLITE_READ:
            name = (arg1 or "").lower()
            # real tables must be on the allow-list; CTE names and sub-query aliases are fine;
            # internal schema and pragma table-valued functions are never readable
            if name in forbidden or name.startswith(("sqlite_", "pragma_")) or (dbname or "main") not in ("main", "temp"):
                return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        return sqlite3.SQLITE_DENY
    return authorizer


def _strip_comments(sql: str) -> str:
    return re.sub(r"--[^\n]*|/\*.*?\*/", " ", sql, flags=re.S).strip()


def run(sql: str, db_path: str | None = None, max_rows: int = MAX_ROWS) -> dict:
    body = _strip_comments(sql or "")
    if not body:
        raise HuntError("Write a query first")
    if not re.match(r"(?is)^(select|with)\b", body):
        raise HuntError("Only SELECT queries are allowed (read-only workbench)")
    path = db_path or DB_PATH
    ro = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    real = {r[0] for r in ro.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    ro.set_authorizer(_make_authorizer(real))
    start = time.time()
    ro.set_progress_handler(lambda: 1 if time.time() - start > TIMEOUT else 0, 20000)
    try:
        cur = ro.execute(sql)
        cols = [d[0] for d in cur.description or []]
        data = cur.fetchmany(max_rows + 1)
    except sqlite3.DatabaseError as e:
        msg = str(e)
        if "interrupted" in msg:
            msg = f"Query took longer than {TIMEOUT:g}s and was stopped"
        elif "not authorized" in msg or "prohibited" in msg:
            msg = "Not allowed: hunts can only read " + ", ".join(sorted(READABLE))
        raise HuntError(msg) from None
    except sqlite3.Warning as e:              # e.g. "You can only execute one statement at a time."
        raise HuntError(str(e)) from None
    finally:
        ro.close()
    return {"columns": cols, "rows": [list(r) for r in data[:max_rows]], "truncated": len(data) > max_rows,
            "row_count": min(len(data), max_rows), "ms": round((time.time() - start) * 1000)}


def ask_claude(question: str) -> dict:
    """Natural language → SQL with Claude. The SQL is returned for the analyst to review and
    run (human in the loop); it still goes through the read-only sandbox. Only the question and
    the schema are sent, never data."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise HuntError("Add ANTHROPIC_API_KEY to .env to ask questions in plain English")
    schema = "\n".join(f"- {t}({c})" for t, c in SCHEMA_DOC.items())
    prompt = ("Write ONE read-only SQLite query for a cash-fraud analyst. Tables:\n" + schema +
              "\nRules: SELECT or WITH only; SQLite syntax; ts is ISO text so use substr/strftime; add LIMIT 500. "
              "Return JSON only: {\"sql\": \"...\", \"explanation\": \"one sentence\"}\n\nQuestion: " + question[:500])
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps({
        "model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": 700,
        "messages": [{"role": "user", "content": prompt}]}).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            text = json.loads(r.read())["content"][0]["text"]
        data = json.loads(text[text.index("{"): text.rindex("}") + 1])
        return {"sql": str(data.get("sql", "")).strip(), "explanation": str(data.get("explanation", ""))[:300]}
    except Exception as e:
        raise HuntError(f"Claude request failed: {e}") from None


# ------------------------------------------------------------------ guided pivot (any role, store-scoped)

PIVOT_KEYS = {
    "cashier": "cashier", "register": "register", "store": "store", "type": "txn_type", "payment": "payment_method",
    "approver": "approved_by", "hour": "CAST(substr(ts, 12, 2) AS INTEGER)", "day": "substr(ts, 1, 10)",
    "weekday": "CAST(strftime('%w', ts) AS INTEGER)",
}
PIVOT_METRICS = {"count": "COUNT(*)", "sum": "ROUND(SUM(amount), 2)", "avg": "ROUND(AVG(amount), 2)", "max": "MAX(amount)"}


def pivot(conn, stores: list[str], since: str | None, group_by: str, group_by2: str, metric: str, txn_type: str,
          payment: str, cashier: str, min_amount: float) -> dict:
    if group_by not in PIVOT_KEYS or (group_by2 and group_by2 not in PIVOT_KEYS) or metric not in PIVOT_METRICS:
        raise HuntError("Unknown grouping or metric")
    g1, g2 = PIVOT_KEYS[group_by], PIVOT_KEYS.get(group_by2 or "")
    where, p = [f"store IN ({','.join('?' * len(stores))})"], list(stores)
    for col, val in (("txn_type", txn_type), ("payment_method", payment), ("cashier", cashier)):
        if val:
            where.append(f"{col} = ?"); p.append(val)
    if min_amount:
        where.append("amount >= ?"); p.append(min_amount)
    if since:
        where.append("ts >= ?"); p.append(since)
    sel = f"{g1} AS k1" + (f", {g2} AS k2" if g2 else "")
    grp = "k1" + (", k2" if g2 else "")
    q = f"SELECT {sel}, {PIVOT_METRICS[metric]} AS v, COUNT(*) AS n FROM transactions WHERE {' AND '.join(where)} GROUP BY {grp} ORDER BY v DESC LIMIT 500"
    data = [dict(r) for r in conn.execute(q, p)]
    return {"rows": data, "group_by": group_by, "group_by2": group_by2, "metric": metric}
