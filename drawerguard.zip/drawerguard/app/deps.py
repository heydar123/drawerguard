"""Shared application state and request dependencies (auth, store scoping, helpers).

Imported by app.main and every router in app.api.*
"""
import hashlib
import hmac
import json
import logging
import os
import socket
from pathlib import Path

from fastapi import Depends, Header, HTTPException, Query, Request

from . import siem
from .auth import Sessions, User, ensure_owner, load_user, user_stamp
from .config import DEFAULT_RULES
from .db import DATA_DIR, ThreadLocalConnection, init_db
from .detection.catalog import meta
from .detection.engine import run_detection
from .notify import broadcast, format_digest, notify

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("drawerguard")

BASE = Path(__file__).resolve().parent
PASSWORD = os.environ.get("DRAWERGUARD_PASSWORD", "changeme")  # noqa: S105 (bootstrap only; the UI warns until it is changed)
SESS = Sessions(os.environ.get("DRAWERGUARD_SECRET"), int(os.environ.get("DRAWERGUARD_SESSION_HOURS", "12")))
MAX_EVIDENCE_MB = int(os.environ.get("MAX_EVIDENCE_MB", "250"))
EVIDENCE_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".mp4", ".mov", ".avi", ".mkv", ".pdf", ".txt", ".csv", ".docx", ".xlsx"}

conn = ThreadLocalConnection()          # a connection per worker thread (see db.py)
init_db(conn)
ensure_owner(conn, PASSWORD)


def backfill_evidence_hashes() -> None:
    for e in conn.execute("SELECT id, stored_name FROM evidence WHERE sha256 IS NULL").fetchall():
        p = DATA_DIR / "evidence" / e["stored_name"]
        if p.exists():
            conn.execute("UPDATE evidence SET sha256=? WHERE id=?", (file_sha256(p), e["id"]))
    conn.commit()


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


backfill_evidence_hashes()


def lan_url() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
    except OSError:
        ip = "127.0.0.1"
    return f"http://{ip}:{os.environ.get('PORT', '8000')}"


def client_ip(request: Request | None) -> str:
    if request is None:
        return "-"
    if os.environ.get("TRUST_PROXY") == "1":
        fwd = request.headers.get("x-forwarded-for", "")
        if fwd:
            return fwd.split(",")[0].strip()[:64]
    return (request.client.host if request.client else "-")[:64]


# ------------------------------------------------------------------ auth dependencies

def current_user(authorization: str = Header(default=""), token: str = Query(default="")) -> User:
    tok = authorization.removeprefix("Bearer ").strip() or token
    v = SESS.verify(tok) if tok and not tok.startswith("dg_") else None
    user = load_user(conn, v[0]) if v else None
    if not user or not hmac.compare_digest(v[1], user_stamp(user)):
        raise HTTPException(401, "Not logged in")
    return user


def need(perm: str):
    def dep(user: User = Depends(current_user)) -> User:
        if not user.can(perm):
            raise HTTPException(403, f"Your role ({user.role}) can't do this")
        return user
    return dep


def scope(user: User, store: str = "") -> list[str]:
    allowed = user.store_ids(conn)
    if not store:
        return allowed or ["__none__"]
    wanted = [s for s in store.split(",") if s]
    bad = [s for s in wanted if s not in allowed]
    if bad:
        raise HTTPException(403, f"No access to store {bad[0]}")
    return wanted


def alert_store_check(user: User, alert_ids: list[int]) -> None:
    allowed = set(user.store_ids(conn))
    if not alert_ids:
        return
    for r in conn.execute(f"SELECT store FROM alerts WHERE id IN ({','.join('?' * len(alert_ids))})", alert_ids):
        if r["store"] not in allowed:
            raise HTTPException(403, "No access to that store")


def get_case(cid: int, user: User) -> dict:
    c = conn.execute("SELECT * FROM cases WHERE id=?", (cid,)).fetchone()
    if not c:
        raise HTTPException(404, "Case not found")
    scope(user, c["store"])
    return dict(c)


# ------------------------------------------------------------------ alert helpers

def rule_labels() -> dict:
    labels = {k: v["label"] for k, v in DEFAULT_RULES.items()}
    for r in conn.execute("SELECT id, name FROM custom_rules"):
        labels[f"custom:{r['id']}"] = f"🧩 {r['name']}"
    return labels


def parse_alert(a: dict) -> dict:
    a["details"] = json.loads(a.get("details") or "{}")
    m = meta(a["rule"])
    a["rule_id"], a["acfe"] = m["id"], m["acfe"]
    return a


def after_import(stores=None) -> dict:
    """Detection → suppressions & playbooks → owner notifications → SIEM."""
    from . import soc
    res = run_detection(conn, stores)
    if res["new"]:
        live, push = soc.process_new(conn, res["new"])
        notify(conn, live)
        if push:
            extra = [a for a in push if a["severity"] < int(os.environ.get("NOTIFY_MIN_SEVERITY", "4"))]
            if extra:
                subject, body = format_digest(extra, os.environ.get("DASHBOARD_URL", ""))
                broadcast("Playbook: " + subject, body)
        siem.forward(live)
        from . import integrations
        th = integrations.send_thehive_alerts(live)
        for local, ext in th.get("refs", []):
            conn.execute("INSERT INTO external_refs(system, kind, local_id, external_id) VALUES('thehive','alert',?,?)", (local, ext))
        if th.get("refs"):
            conn.commit()
        res["live"] = len(live)
    return res
