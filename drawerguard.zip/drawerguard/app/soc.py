"""SOC operations: alert lifecycle, SLAs, suppressions (allow-list), playbook automations
and SOC metrics (MTTA / MTTR / false-positive rate per detection).

Lifecycle
  open ──► investigating ──► confirmed | dismissed      (re-open allowed)
  * acked_at    = first time an alert leaves "open"      → MTTA
  * resolved_at = when it becomes confirmed/dismissed    → MTTR
  * due_at      = created_at + SLA hours for its severity → "overdue"
Every change is written to alert_history (who, field, old → new).
"""
import json
import logging
import os
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from .db import rows

log = logging.getLogger("drawerguard.soc")

STATUSES = ("open", "investigating", "dismissed", "confirmed")
CLOSED = ("dismissed", "confirmed")


def sla_hours() -> dict[int, int]:
    """Hours to triage, per severity. Override with SLA_HOURS=5:4,4:24,3:72,2:168"""
    out = {5: 4, 4: 24, 3: 72, 2: 168}
    for part in os.environ.get("SLA_HOURS", "").split(","):
        if ":" in part:
            k, v = part.split(":", 1)
            if k.strip().isdigit() and v.strip().isdigit():
                out[int(k)] = int(v)
    return out


def now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def due_for(severity: int, created: datetime | None = None) -> str | None:
    h = sla_hours().get(int(severity))
    if not h:
        return None
    return ((created or datetime.now(timezone.utc)) + timedelta(hours=h)).strftime("%Y-%m-%d %H:%M:%S")


def record(conn, alert_id: int, actor: str, field: str, old, new) -> None:
    conn.execute("INSERT INTO alert_history(alert_id, actor, field, old, new, created_at) VALUES(?,?,?,?,?,?)",
                 (alert_id, actor, field, None if old is None else str(old)[:500], None if new is None else str(new)[:500], now_utc()))


def set_status(conn, alert_id: int, status: str, actor: str, notes: str | None = None, commit: bool = True) -> dict | None:
    cur = conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
    if not cur:
        return None
    cur = dict(cur)
    ts = now_utc()
    if status and status != cur["status"]:
        acked = cur["acked_at"] or (ts if status != "open" else None)
        resolved = ts if status in CLOSED else None
        conn.execute("UPDATE alerts SET status=?, acked_at=?, resolved_at=?, updated_at=? WHERE id=?",
                     (status, acked, resolved, ts, alert_id))
        record(conn, alert_id, actor, "status", cur["status"], status)
    if notes is not None and notes != (cur["notes"] or ""):
        conn.execute("UPDATE alerts SET notes=?, updated_at=? WHERE id=?", (notes, ts, alert_id))
        record(conn, alert_id, actor, "notes", "", notes[:200])
    if commit:
        conn.commit()
    return cur


def assign(conn, alert_id: int, assignee: str | None, actor: str, commit: bool = True) -> None:
    cur = conn.execute("SELECT assigned_to FROM alerts WHERE id=?", (alert_id,)).fetchone()
    if not cur or (cur["assigned_to"] or None) == (assignee or None):
        return
    conn.execute("UPDATE alerts SET assigned_to=?, updated_at=? WHERE id=?", (assignee or None, now_utc(), alert_id))
    record(conn, alert_id, actor, "assigned_to", cur["assigned_to"], assignee)
    if commit:
        conn.commit()


def add_tag(conn, alert_id: int, tag: str, actor: str) -> None:
    cur = conn.execute("SELECT tags FROM alerts WHERE id=?", (alert_id,)).fetchone()
    tags = [t for t in (cur["tags"] or "").split(",") if t] if cur else []
    if tag and tag not in tags:
        tags.append(tag)
        conn.execute("UPDATE alerts SET tags=? WHERE id=?", (",".join(tags), alert_id))
        record(conn, alert_id, actor, "tag", "", tag)


# ------------------------------------------------------------------ suppressions

def active_suppressions(conn) -> list[dict]:
    today = datetime.now().strftime("%Y-%m-%d")
    return [s for s in rows(conn.execute("SELECT * FROM suppressions WHERE active=1"))
            if not s["expires_at"] or s["expires_at"] >= today]


def matches(sup: dict, a: dict) -> bool:
    return all(sup[k] in ("*", "", None) or sup[k] == (a.get(k) or "") for k in ("store", "rule", "cashier", "register"))


def apply_suppression_to_existing(conn, sup: dict, actor: str) -> int:
    """Close open alerts that match a new suppression (optional, chosen in the UI)."""
    n = 0
    for a in rows(conn.execute("SELECT * FROM alerts WHERE status='open'")):
        if matches(sup, a):
            set_status(conn, a["id"], "dismissed", f"{actor} (suppression #{sup['id']})", None, commit=False)
            conn.execute("UPDATE alerts SET suppressed_by=? WHERE id=?", (sup["id"], a["id"]))
            n += 1
    conn.execute("UPDATE suppressions SET hits=hits+? WHERE id=?", (n, sup["id"]))
    conn.commit()
    return n


# ------------------------------------------------------------------ automations (SOAR-lite)

def _auto_matches(cond: dict, a: dict) -> bool:
    if cond.get("rules") and a["rule"] not in cond["rules"]:
        return False
    if a["severity"] < int(cond.get("min_severity") or 1):
        return False
    if cond.get("stores") and a.get("store") not in cond["stores"]:
        return False
    if cond.get("cashiers") and a.get("cashier") not in cond["cashiers"]:
        return False
    return True


def _add_to_case(conn, a: dict, playbook: str) -> int:
    row = conn.execute("SELECT id FROM cases WHERE store=? AND cashier=? AND status='open' ORDER BY id DESC LIMIT 1",
                       (a["store"], a["cashier"])).fetchone()
    if row:
        cid = row["id"]
    else:
        cid = conn.execute("INSERT INTO cases(store, cashier, title, created_by) VALUES(?,?,?,?)",
                           (a["store"], a["cashier"], f"{a['cashier']}: opened automatically by playbook \"{playbook}\"",
                            f"automation:{playbook}")).lastrowid
        conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                     (cid, f"automation:{playbook}", "status", "Case opened automatically"))
    conn.execute("UPDATE alerts SET case_id=? WHERE id=?", (cid, a["id"]))
    record(conn, a["id"], f"automation:{playbook}", "case", None, cid)
    conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                 (cid, f"automation:{playbook}", "alert", f"Added alert #{a['id']}: {a['title'][:150]}"))
    return cid


def process_new(conn, new_alerts: list[dict]) -> tuple[list[dict], list[dict]]:
    """Run suppressions then automations on freshly created alerts.
    Returns (live alerts to notify / forward, alerts a playbook wants pushed regardless of severity)."""
    if not new_alerts:
        return [], []
    sups = active_suppressions(conn)
    autos = [dict(r) | {"conditions": json.loads(r["conditions"]), "actions": json.loads(r["actions"])}
             for r in conn.execute("SELECT * FROM automations WHERE enabled=1 ORDER BY id")]
    live, push = [], []
    for a in new_alerts:
        if not a.get("id"):
            continue
        sup = next((s for s in sups if matches(s, a)), None)
        if sup:
            set_status(conn, a["id"], "dismissed", f"suppression #{sup['id']}", f"Auto-closed: {sup['reason']}", commit=False)
            conn.execute("UPDATE alerts SET suppressed_by=? WHERE id=?", (sup["id"], a["id"]))
            conn.execute("UPDATE suppressions SET hits=hits+1 WHERE id=?", (sup["id"],))
            continue
        live.append(a)
        for au in autos:
            if not _auto_matches(au["conditions"], a):
                continue
            act, who = au["actions"], f"automation:{au['name']}"
            try:
                if act.get("assign_to"):
                    assign(conn, a["id"], act["assign_to"], who, commit=False)
                if act.get("set_status") in STATUSES:
                    set_status(conn, a["id"], act["set_status"], who, commit=False)
                if act.get("tag"):
                    add_tag(conn, a["id"], act["tag"][:40], who)
                if act.get("add_to_case") and a.get("cashier"):
                    _add_to_case(conn, a, au["name"])
                if act.get("notify"):
                    push.append(a)
                conn.execute("UPDATE automations SET runs=runs+1, last_run=? WHERE id=?", (now_utc(), au["id"]))
            except Exception as e:  # a broken playbook must never stop detection
                log.error("automation %s failed on alert %s: %s", au["name"], a.get("id"), e)
    conn.commit()
    return live, push


# ------------------------------------------------------------------ metrics

def _hours(a: str | None, b: str | None) -> float | None:
    if not a or not b:
        return None
    try:
        return (datetime.fromisoformat(b) - datetime.fromisoformat(a)).total_seconds() / 3600
    except ValueError:
        return None


def _avg(xs):
    xs = [x for x in xs if x is not None and x >= 0]
    return round(sum(xs) / len(xs), 1) if xs else None


def _median(xs):
    xs = sorted(x for x in xs if x is not None and x >= 0)
    return round(xs[len(xs) // 2], 1) if xs else None


def metrics(conn, stores: list[str], since: str | None) -> dict:
    q = f"SELECT * FROM alerts WHERE store IN ({','.join('?' * len(stores))})"
    p = list(stores)
    if since:
        q += " AND ts >= ?"
        p.append(since)
    al = rows(conn.execute(q, p))
    now = now_utc()
    live = [a for a in al if a["status"] in ("open", "investigating")]
    sev = defaultdict(lambda: {"total": 0, "open": 0, "overdue": 0, "tta": [], "ttr": []})
    per_rule = defaultdict(lambda: {"total": 0, "open": 0, "confirmed": 0, "dismissed": 0, "suppressed": 0})
    daily = defaultdict(lambda: defaultdict(int))
    for a in al:
        s = sev[a["severity"]]
        s["total"] += 1
        s["tta"].append(_hours(a["created_at"], a["acked_at"]))
        s["ttr"].append(_hours(a["created_at"], a["resolved_at"]))
        r = per_rule[a["rule"]]
        r["total"] += 1
        if a["suppressed_by"]:
            r["suppressed"] += 1
        elif a["status"] in ("confirmed", "dismissed"):
            r[a["status"]] += 1
        if a["status"] in ("open", "investigating"):
            s["open"] += 1
            r["open"] += 1
            if a["due_at"] and a["due_at"] < now:
                s["overdue"] += 1
        daily[(a["created_at"] or "")[:10]][a["severity"]] += 1
    rules_out = []
    for k, r in per_rule.items():
        resolved = r["confirmed"] + r["dismissed"]
        fp = r["dismissed"] / resolved if resolved else None
        tip = ""
        if resolved >= 8 and fp is not None and fp >= 0.7:
            tip = "Mostly dismissed: raise the threshold, lower the severity, or add a suppression for known-good cases."
        elif resolved >= 8 and fp is not None and fp <= 0.1:
            tip = "Almost always confirmed: consider raising severity or an automation that opens a case."
        elif r["open"] >= 50:
            tip = "Large backlog: add an automation to assign or triage these."
        rules_out.append({"rule": k, **r, "resolved": resolved, "fp_rate": None if fp is None else round(fp, 3), "suggestion": tip})
    rules_out.sort(key=lambda x: -x["total"])
    aging = {"<1d": 0, "1-3d": 0, "3-7d": 0, ">7d": 0}
    for a in live:
        h = _hours(a["created_at"], now) or 0
        aging["<1d" if h < 24 else "1-3d" if h < 72 else "3-7d" if h < 168 else ">7d"] += 1
    work = defaultdict(lambda: {"open": 0, "overdue": 0, "resolved": 0})
    for a in al:
        w = work[a["assigned_to"] or "(unassigned)"]
        if a["status"] in ("open", "investigating"):
            w["open"] += 1
            if a["due_at"] and a["due_at"] < now:
                w["overdue"] += 1
        else:
            w["resolved"] += 1
    return {
        "total": len(al), "open": len(live), "overdue": sum(1 for a in live if a["due_at"] and a["due_at"] < now),
        "mtta_h": _avg(x for s in sev.values() for x in s["tta"]), "mttr_h": _avg(x for s in sev.values() for x in s["ttr"]),
        "median_tta_h": _median(x for s in sev.values() for x in s["tta"]),
        "dispositions": {st: sum(1 for a in al if a["status"] == st) for st in STATUSES},
        "suppressed": sum(1 for a in al if a["suppressed_by"]),
        "by_severity": [{"severity": k, "total": v["total"], "open": v["open"], "overdue": v["overdue"],
                         "mtta_h": _avg(v["tta"]), "mttr_h": _avg(v["ttr"]), "sla_h": sla_hours().get(k)}
                        for k, v in sorted(sev.items(), reverse=True)],
        "rules": rules_out, "aging": aging,
        "workload": [{"assignee": k, **v} for k, v in sorted(work.items(), key=lambda kv: -kv[1]["open"])],
        "daily": [{"date": d, **{f"s{k}": v for k, v in sv.items()}} for d, sv in sorted(daily.items()) if d],
        "automations": rows(conn.execute("SELECT id, name, runs, last_run, enabled FROM automations ORDER BY id")),
        "suppressions": rows(conn.execute("SELECT id, rule, cashier, store, reason, hits, expires_at, active FROM suppressions ORDER BY id")),
    }
