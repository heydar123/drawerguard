"""DrawerGuard API server (v3).

Run:  python run.py     then open http://localhost:8000
"""
import csv
import hashlib
import io
import json
import mimetypes
import os
import re
import secrets
import time
import uuid
import warnings
from collections import defaultdict
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from . import __version__
from .auth import ROLES, User, check_pw, hash_pw, pw_stamp, totp_check, totp_new_secret, totp_uri
from .detection.catalog import CATALOG, meta
from . import siem
from .cctv import PRESETS, links_for
from .config import DEFAULT_RULES, merged_rules
from .db import DATA_DIR, audit, get_setting, rows, set_setting, verify_audit
from . import security, soc
from .deps import (BASE, EVIDENCE_EXT, MAX_EVIDENCE_MB, PASSWORD, SESS, after_import, alert_store_check, client_ip, conn,
                   current_user, lan_url, log, need, parse_alert, rule_labels, scope)
from .deps import get_case as _case
from .detection.ai import anomaly_series, build_summary, polish_with_claude
from .detection.engine import _in, alert_since_sql, cashier_scores, window_since
from .detection.rules import PEER_METRICS
from .ingest.connectors import InboxWatcher, SplitPOSApiConnector
from .ingest.csv_importer import ensure_stores, import_file, slug
from .notify import broadcast, channels_status, email_report
from .reports import ReportScheduler, build_case_file, save_report


def daily_jobs() -> list:
    """Once-a-day maintenance run by the scheduler (after REPORT_HOUR)."""
    from . import maintenance
    jobs = []
    if os.environ.get("BACKUP_DAILY", "1") == "1":
        jobs.append(("backup", lambda: maintenance.backup(conn)))
    if int(os.environ.get("RETENTION_DAYS", "0") or 0) >= 30:
        jobs.append(("retention", lambda: maintenance.retention(conn, int(os.environ["RETENTION_DAYS"]), dry_run=False)))

    def data_watch():                                 # "log source silent" alert
        stale = [h for h in maintenance.data_health(conn, [r["id"] for r in conn.execute("SELECT id FROM stores")]) if h["status"] == "stale"]
        if stale:
            broadcast("⚠️ DrawerGuard: store data stopped arriving",
                      "\n".join(f"{h['name']}: {'; '.join(h['issues'])}" for h in stale), "default")
    jobs.append(("data_watch", data_watch))

    def model_watch():                                # ML drift (PSI) per store
        from .config import merged_rules
        from .db import get_setting
        from .detection.engine import load_context
        from .detection.ml import model_health
        rules = merged_rules(get_setting(conn, "rules", {}))
        for r in conn.execute("SELECT id, name FROM stores").fetchall():
            h = model_health(conn, r["id"], load_context(conn, [r["id"]]), rules)
            if h.get("ready") and h["status"] == "drift":
                top = ", ".join(f"{f['label']} (PSI {f['psi']:.2f})" for f in h["features"] if f["status"] == "drift")
                broadcast(f"📉 DrawerGuard: behaviour model drift at {r['name']}",
                          f"The last {h['recent_days']} days look different from the baseline: {top}. "
                          "Check for menu or process changes and review AI thresholds.", "default")
    jobs.append(("model_watch", model_watch))
    return jobs


def _startup():
    if PASSWORD == "changeme":  # noqa: S105  # nosec B105
        log.warning("Using default password 'changeme' — set DRAWERGUARD_PASSWORD in .env!")
    inbox = os.environ.get("DRAWERGUARD_INBOX")
    if inbox:
        InboxWatcher(lambda: conn, inbox, on_import=after_import, interval=int(os.environ.get("INBOX_INTERVAL", "60"))).start()
        log.info("Watching %s for new SplitPOS exports (sub-folders = store ids)", inbox)
    if os.environ.get("REPORTS_ENABLED", "1") == "1":
        ReportScheduler(conn, email_report, daily_jobs=daily_jobs()).start()
    log.info("Open on this PC: http://localhost:%s   ·   on your phone (same Wi-Fi): %s", os.environ.get("PORT", "8000"), lan_url())


@asynccontextmanager
async def lifespan(_app):
    _startup()
    yield


app = FastAPI(title="DrawerGuard", version=__version__, description="Cashier fraud detection for SplitPOS", lifespan=lifespan)

CSP = ("default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
       "media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'")


@app.middleware("http")
async def security_headers(request, call_next):
    resp = await call_next(request)
    h = resp.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault("Permissions-Policy", "camera=(self), microphone=(), geolocation=()")
    h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
    if not request.url.path.startswith(("/docs", "/redoc", "/openapi")):
        h.setdefault("Content-Security-Policy", CSP)
    if request.url.path.startswith("/api/"):
        h.setdefault("Cache-Control", "no-store")
    return resp


# ================================================================== auth

class Login(BaseModel):
    username: str = "owner"
    password: str
    code: str = ""


_fails: dict[str, list[float]] = defaultdict(list)
_locked: dict[str, float] = {}
LOCKOUT_ATTEMPTS = int(os.environ.get("LOCKOUT_ATTEMPTS", "8"))        # PCI DSS 8.3.4: at most 10
LOCKOUT_MINUTES = int(os.environ.get("LOCKOUT_MINUTES", "30"))         # PCI DSS 8.3.4: at least 30 minutes
PASSWORD_MIN_LENGTH = int(os.environ.get("PASSWORD_MIN_LENGTH", "8"))  # PCI DSS 8.3.6: 12 (set it in .env)
IDLE_TIMEOUT_MINUTES = int(os.environ.get("IDLE_TIMEOUT_MINUTES", "15"))  # PCI DSS 8.2.8: re-authenticate after 15 idle minutes


def _check_new_password(pw: str) -> None:
    if not pw or len(pw) < PASSWORD_MIN_LENGTH:
        raise HTTPException(400, f"Password must be at least {PASSWORD_MIN_LENGTH} characters")


@app.post("/api/login")
def login(body: Login, request: Request):
    now = time.time()
    ip, ua = client_ip(request), request.headers.get("user-agent", "")[:200]
    if security.ip_blocked(ip):
        security.record_login(conn, body.username[:40], ip, ua, False, "blocked IP (too many failures)")
        raise HTTPException(429, "Too many failed sign-ins from your network. Wait 10 minutes.")
    key = body.username.lower()
    _fails[key] = [t for t in _fails[key] if now - t < 900]
    if len(_fails[key]) >= LOCKOUT_ATTEMPTS and key not in _locked:
        _locked[key] = now + LOCKOUT_MINUTES * 60
    if _locked.get(key, 0) > now:
        security.record_login(conn, body.username[:40], ip, ua, False, "account temporarily locked")
        raise HTTPException(429, f"Too many attempts: this account is locked for {LOCKOUT_MINUTES} minutes")
    if key in _locked:                            # lock expired: start counting again
        _locked.pop(key, None)
        _fails[key] = []
    r = conn.execute("SELECT * FROM users WHERE lower(username)=? AND active=1", (key,)).fetchone()
    if not r or not check_pw(body.password, r["pw_hash"]):
        _fails[key].append(now)
        security.register_failure(conn, ip, body.username[:40])
        security.record_login(conn, body.username[:40], ip, ua, False, "wrong password" if r else "unknown user")
        audit(conn, body.username[:40], "failed login", ip)
        raise HTTPException(401, "Wrong username or password")
    if r["totp_secret"]:
        if not body.code:
            raise HTTPException(401, "2fa_required")
        step = totp_check(r["totp_secret"], body.code, r["totp_last"] or 0)
        if step is None:
            _fails[key].append(now)
            security.register_failure(conn, ip, r["username"])
            security.record_login(conn, r["username"], ip, ua, False, "wrong 2FA code")
            audit(conn, r["username"], "failed 2FA code", ip)
            raise HTTPException(401, "Wrong 2FA code")
        conn.execute("UPDATE users SET totp_last=? WHERE username=?", (step, r["username"]))
    conn.execute("UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE username=?", (r["username"],))
    new_device = security.record_login(conn, r["username"], ip, ua, True, "2FA" if r["totp_secret"] else "password")
    audit(conn, r["username"], "login" + (" (2FA)" if r["totp_secret"] else "") + (" from a NEW device" if new_device else ""), ip)
    if new_device and r["role"] in ("owner", "manager") and os.environ.get("NOTIFY_NEW_DEVICE", "1") == "1":
        try:
            broadcast("🔐 New DrawerGuard sign-in", f"{r['username']} signed in from a new device: {security.ua_family(ua)} at {ip}. "
                      "If this wasn't you, change the password; that signs out every session.", "high")
        except Exception as e:
            log.error("new-device notification failed: %s", e)
    return {"token": SESS.make(r["username"], pw_stamp(r["pw_hash"], r["session_epoch"] or 0)),
            "username": r["username"], "role": r["role"]}


class TotpIn(BaseModel):
    secret: str = ""
    code: str = ""
    password: str = ""


@app.post("/api/me/2fa/setup")
def totp_setup(user: User = Depends(current_user)):
    """Step 1: get a new secret to add to Google Authenticator / Microsoft Authenticator / 1Password."""
    sec = totp_new_secret()
    return {"secret": sec, "uri": totp_uri(sec, user.name)}


@app.post("/api/me/2fa/enable")
def totp_enable(body: TotpIn, user: User = Depends(current_user)):
    step = totp_check(body.secret, body.code)
    if step is None:
        raise HTTPException(400, "That code didn't match. Check the time on your phone and try again.")
    conn.execute("UPDATE users SET totp_secret=?, totp_last=? WHERE username=?", (body.secret, step, user.name))
    conn.commit()
    audit(conn, user.name, "enabled 2FA")
    return {"ok": True}


@app.post("/api/me/2fa/disable")
def totp_disable(body: TotpIn, user: User = Depends(current_user)):
    if not check_pw(body.password, user["pw_hash"]):
        raise HTTPException(400, "Password is wrong")
    conn.execute("UPDATE users SET totp_secret=NULL, totp_last=0 WHERE username=?", (user.name,))
    conn.commit()
    audit(conn, user.name, "disabled 2FA")
    return {"ok": True}


@app.get("/api/me")
def me(user: User = Depends(current_user)):
    ids = user.store_ids(conn)
    stores = rows(conn.execute(f"SELECT id, name FROM stores WHERE id IN {_in(ids or ['-'])} ORDER BY name", ids or ["-"]))
    perms = [p for p in ("view", "review", "import", "cases", "reports", "admin") if user.can(p)]
    return {"username": user.name, "role": user.role, "full_name": user.get("full_name"), "stores": stores, "perms": perms,
            "version": __version__, "channels": channels_status(), "lan_url": lan_url(),
            "ai_cloud": bool(os.environ.get("ANTHROPIC_API_KEY")), "two_factor": bool(user.get("totp_secret")),
            "siem": siem.configured(), "idle_minutes": IDLE_TIMEOUT_MINUTES, "password_min_length": PASSWORD_MIN_LENGTH,
            "default_password": PASSWORD in ("changeme", "choose-a-strong-password") and check_pw(PASSWORD, user["pw_hash"])}


class PwChange(BaseModel):
    old: str
    new: str


@app.post("/api/me/password")
def change_pw(body: PwChange, user: User = Depends(current_user)):
    if not check_pw(body.old, user["pw_hash"]):
        raise HTTPException(400, "Current password is wrong")
    _check_new_password(body.new)
    new_hash = hash_pw(body.new)
    conn.execute("UPDATE users SET pw_hash=? WHERE username=?", (new_hash, user.name))
    conn.commit()
    audit(conn, user.name, "changed password (other sessions signed out)")
    return {"ok": True, "token": SESS.make(user.name, pw_stamp(new_hash, user.get("session_epoch") or 0))}


@app.post("/api/me/signout-all")
def signout_all(user: User = Depends(current_user)):
    """Invalidate every session for this user (lost phone, shared PC…) and return a fresh one."""
    epoch = (user.get("session_epoch") or 0) + 1
    conn.execute("UPDATE users SET session_epoch=? WHERE username=?", (epoch, user.name))
    conn.commit()
    audit(conn, user.name, "signed out all sessions")
    return {"ok": True, "token": SESS.make(user.name, pw_stamp(user["pw_hash"], epoch))}


@app.post("/api/users/{username}/signout")
def signout_user(username: str, user: User = Depends(need("admin"))):
    r = conn.execute("UPDATE users SET session_epoch=COALESCE(session_epoch,0)+1 WHERE username=?", (username,))
    conn.commit()
    if not r.rowcount:
        raise HTTPException(404, "No such user")
    audit(conn, user.name, "signed out all sessions of", username)
    return {"ok": True}


# ================================================================== users & stores (owner)

class UserIn(BaseModel):
    username: str
    password: str | None = None
    role: str = "manager"
    stores: list[str] = ["*"]
    full_name: str = ""
    active: bool = True


@app.get("/api/users")
def list_users(user: User = Depends(need("admin"))):
    return [{k: v for k, v in u.items() if k not in ("pw_hash", "totp_secret", "totp_last")}
            | {"stores": json.loads(u["stores"]), "two_factor": bool(u["totp_secret"])}
            for u in rows(conn.execute("SELECT * FROM users ORDER BY role, username"))]


@app.post("/api/users")
def create_user(body: UserIn, user: User = Depends(need("admin"))):
    if body.role not in ROLES:
        raise HTTPException(400, "Bad role")
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{2,40}", body.username):
        raise HTTPException(400, "Username: 2-40 letters, numbers, . _ -")
    _check_new_password(body.password)
    try:
        conn.execute("INSERT INTO users(username, pw_hash, role, stores, full_name) VALUES(?,?,?,?,?)",
                     (body.username, hash_pw(body.password), body.role, json.dumps(body.stores), body.full_name))
        conn.commit()
    except Exception:
        raise HTTPException(400, "That username already exists")
    audit(conn, user.name, f"created user ({body.role})", body.username)
    return {"ok": True}


@app.patch("/api/users/{username}")
def update_user(username: str, body: UserIn, user: User = Depends(need("admin"))):
    if body.role not in ROLES:
        raise HTTPException(400, "Bad role")
    owners = conn.execute("SELECT COUNT(*) n FROM users WHERE role='owner' AND active=1 AND username!=?", (username,)).fetchone()["n"]
    if (body.role != "owner" or not body.active) and owners == 0:
        raise HTTPException(400, "Keep at least one active owner")
    conn.execute("UPDATE users SET role=?, stores=?, full_name=?, active=? WHERE username=?",
                 (body.role, json.dumps(body.stores), body.full_name, int(body.active), username))
    if body.password:
        _check_new_password(body.password)
        conn.execute("UPDATE users SET pw_hash=? WHERE username=?", (hash_pw(body.password), username))
    conn.commit()
    audit(conn, user.name, "updated user", username)
    return {"ok": True}


class StoreIn(BaseModel):
    id: str | None = None
    name: str
    address: str = ""
    open_hour: int | None = None
    close_hour: int | None = None


@app.get("/api/stores")
def list_stores(user: User = Depends(current_user)):
    ids = user.store_ids(conn) or ["-"]
    return rows(conn.execute(f"""SELECT s.*, (SELECT COUNT(*) FROM transactions t WHERE t.store=s.id) txns,
        (SELECT MAX(ts) FROM transactions t WHERE t.store=s.id) latest,
        (SELECT COUNT(*) FROM alerts a WHERE a.store=s.id AND a.status IN ('open','investigating') AND a.severity>=4) open_high,
        (SELECT COUNT(*) FROM cameras c WHERE c.store=s.id) cameras
        FROM stores s WHERE id IN {_in(ids)} ORDER BY name""", ids))


@app.post("/api/stores")
def create_store(body: StoreIn, user: User = Depends(need("admin"))):
    sid = slug(body.id or body.name)
    if conn.execute("SELECT 1 FROM stores WHERE id=?", (sid,)).fetchone():
        raise HTTPException(400, "A store with that id exists")
    conn.execute("INSERT INTO stores(id, name, address, open_hour, close_hour) VALUES(?,?,?,?,?)",
                 (sid, body.name, body.address, body.open_hour, body.close_hour))
    conn.commit()
    audit(conn, user.name, "created store", sid)
    return {"id": sid}


@app.patch("/api/stores/{sid}")
def update_store(sid: str, body: StoreIn, user: User = Depends(need("admin"))):
    conn.execute("UPDATE stores SET name=?, address=?, open_hour=?, close_hour=? WHERE id=?",
                 (body.name, body.address, body.open_hour, body.close_hour, sid))
    conn.commit()
    audit(conn, user.name, "updated store", sid)
    return {"ok": True}


# ================================================================== cameras / CCTV

warnings.filterwarnings("ignore", message='Field name "register"')


class CameraIn(BaseModel):
    store: str
    register: str = ""
    name: str
    url_template: str = ""
    offset_seconds: int = 0


@app.get("/api/cameras")
def list_cameras(store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    return {"cameras": rows(conn.execute(f"SELECT * FROM cameras WHERE store IN {_in(st)} ORDER BY store, register, name", st)),
            "presets": PRESETS}


@app.post("/api/cameras")
def add_camera(body: CameraIn, user: User = Depends(need("admin"))):
    scope(user, body.store)
    cur = conn.execute("INSERT INTO cameras(store, register, name, url_template, offset_seconds) VALUES(?,?,?,?,?)",
                       (body.store, body.register, body.name, body.url_template, body.offset_seconds))
    conn.commit()
    return {"id": cur.lastrowid}


@app.put("/api/cameras/{cid}")
def edit_camera(cid: int, body: CameraIn, user: User = Depends(need("admin"))):
    conn.execute("UPDATE cameras SET store=?, register=?, name=?, url_template=?, offset_seconds=? WHERE id=?",
                 (body.store, body.register, body.name, body.url_template, body.offset_seconds, cid))
    conn.commit()
    return {"ok": True}


@app.delete("/api/cameras/{cid}")
def del_camera(cid: int, user: User = Depends(need("admin"))):
    conn.execute("DELETE FROM cameras WHERE id=?", (cid,))
    conn.commit()
    return {"ok": True}


@app.get("/api/cctv")
def cctv(store: str, register: str = "", ts: str = "", user: User = Depends(current_user)):
    scope(user, store)
    return links_for(conn, store, register, ts)


# ================================================================== dashboard data

@app.get("/api/detections")
def detections(user: User = Depends(current_user)):
    rules = merged_rules(get_setting(conn, "rules", {}))
    return [{"rule": k, **meta(k), "label": rules[k]["label"], "enabled": rules[k]["enabled"], "severity": rules[k]["severity"],
             "file": f"detections/{CATALOG[k]['id']}_{k}.toml"}
            for k in sorted(CATALOG, key=lambda x: CATALOG[x]["id"])]




@app.get("/api/health")
def health():
    return {"ok": True, "version": __version__}


@app.get("/api/summary")
def summary(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    since, latest = window_since(conn, st, days)
    tw, tp = (f"WHERE store IN {_in(st)}" + (" AND ts >= ?" if since else "")), st + ([since] if since else [])
    t = conn.execute(f"""SELECT COUNT(*) n,
        SUM(CASE WHEN txn_type='sale' THEN amount END) sales,
        SUM(CASE WHEN txn_type='sale' AND payment_method='cash' THEN amount END) cash_sales,
        SUM(CASE WHEN txn_type='refund' THEN amount END) refunds,
        SUM(CASE WHEN txn_type='void' THEN amount END) voids,
        SUM(CASE WHEN txn_type='no_sale' THEN 1 ELSE 0 END) no_sales,
        COUNT(DISTINCT cashier) cashiers FROM transactions {tw}""", tp).fetchone()
    aw, ap = alert_since_sql(since)
    abase = f"WHERE store IN {_in(st)}{aw}"
    a = conn.execute(f"""SELECT COUNT(*) total,
        SUM(status='open') open, SUM(status='investigating') investigating,
        SUM(status='confirmed') confirmed, SUM(status='dismissed') dismissed,
        SUM(CASE WHEN severity>=4 AND status IN ('open','investigating') THEN 1 ELSE 0 END) critical_open,
        SUM(CASE WHEN status!='dismissed' THEN amount ELSE 0 END) at_risk,
        SUM(CASE WHEN status='confirmed' THEN amount ELSE 0 END) confirmed_loss
        FROM alerts {abase}""", st + ap).fetchone()
    sw = f"WHERE store IN {_in(st)} AND expected_cash IS NOT NULL" + (" AND start_ts >= ?" if since else "")
    s = conn.execute(f"""SELECT COUNT(*) shifts, SUM(counted_cash-expected_cash) net,
        SUM(CASE WHEN counted_cash-expected_cash < 0 THEN expected_cash-counted_cash ELSE 0 END) short_total,
        SUM(CASE WHEN counted_cash-expected_cash < -5 THEN 1 ELSE 0 END) short_shifts FROM shifts {sw}""", tp).fetchone()

    daily = defaultdict(lambda: {"alerts": 0, "high": 0, "at_risk": 0.0, "sales": 0.0, "ai": 0.0})
    for r in conn.execute(f"SELECT substr(ts,1,10) d, SUM(CASE WHEN txn_type='sale' THEN amount END) v FROM transactions {tw} GROUP BY d", tp):
        daily[r["d"]]["sales"] = round(r["v"] or 0, 2)
    for r in conn.execute(f"""SELECT substr(ts,1,10) d, COUNT(*) n, SUM(severity>=4) h, SUM(amount) amt FROM alerts {abase}
                              AND status!='dismissed' AND rule NOT IN ('peer_outlier','low_cash_ratio','approver_concentration') GROUP BY d""", st + ap):
        if r["d"] in daily:
            daily[r["d"]].update(alerts=r["n"], high=r["h"], at_risk=round(r["amt"] or 0, 2))
    for r in conn.execute(f"SELECT day, MAX(score) sc FROM shift_anomaly WHERE store IN {_in(st)} GROUP BY day", st):
        if r["day"] in daily:
            daily[r["day"]]["ai"] = r["sc"]
    by_rule = [dict(r, label=rule_labels().get(r["rule"], r["rule"])) for r in conn.execute(
        f"SELECT rule, COUNT(*) n, SUM(amount) amount, MAX(severity) sev FROM alerts {abase} AND status!='dismissed' GROUP BY rule ORDER BY n DESC", st + ap)]
    hours = [0] * 24
    for r in conn.execute(f"""SELECT CAST(substr(ts,12,2) AS INT) h, COUNT(*) n FROM alerts {abase} AND status!='dismissed'
                              AND rule NOT IN ('peer_outlier','low_cash_ratio','approver_concentration','repeat_shortage','ai_anomaly','behavior_change','correlated_shift') GROUP BY h""", st + ap):
        if r["h"] is not None:
            hours[r["h"]] = r["n"]
    per_store = rows(conn.execute(f"""SELECT store, COUNT(*) n, SUM(severity>=4) high, SUM(amount) amount FROM alerts {abase}
                                      AND status IN ('open','investigating') GROUP BY store""", st + ap))
    cases = conn.execute(f"SELECT COUNT(*) n FROM cases WHERE store IN {_in(st)} AND status='open'", st).fetchone()["n"]
    return {
        "range": {"days": days, "since": since, "latest": latest},
        "txns": dict(t), "alerts": dict(a), "cash": dict(s), "open_cases": cases,
        "daily": [{"date": d, **v} for d, v in sorted(daily.items())],
        "by_rule": by_rule, "by_hour": hours, "per_store": per_store,
        "cashiers": cashier_scores(conn, days, st),
    }


@app.get("/api/cashiers")
def cashiers(days: int = 30, store: str = "", user: User = Depends(current_user)):
    return cashier_scores(conn, days, scope(user, store))


def _cashier_bundle(name, days, st):
    since, _latest = window_since(conn, st, days)
    score = next((c for c in cashier_scores(conn, days, st) if c["cashier"] == name), None)
    if not score:
        raise HTTPException(404, "Cashier not found")
    w = " AND ts >= ?" if since else ""
    p = [name, *st] + ([since] if since else [])
    daily = rows(conn.execute(f"""SELECT substr(ts,1,10) date,
        SUM(txn_type='sale') sales, SUM(CASE WHEN txn_type='sale' THEN amount ELSE 0 END) sales_value,
        SUM(txn_type='no_sale') no_sales, SUM(txn_type='void') voids, SUM(txn_type='refund') refunds,
        SUM(CASE WHEN txn_type='refund' THEN amount ELSE 0 END) refund_value
        FROM transactions WHERE cashier=? AND store IN {_in(st)}{w} GROUP BY date ORDER BY date""", p))
    aw, ap = alert_since_sql(since)
    alerts = [parse_alert(a) for a in rows(conn.execute(
        f"SELECT * FROM alerts WHERE cashier=? AND store IN {_in(st)}{aw} ORDER BY severity DESC, ts DESC LIMIT 400", [name, *st, *ap]))]
    sw = " AND start_ts >= ?" if since else ""
    shifts = rows(conn.execute(f"SELECT *, ROUND(counted_cash-expected_cash,2) diff FROM shifts WHERE cashier=? AND store IN {_in(st)}{sw} ORDER BY start_ts DESC", p))
    anomalies = anomaly_series(conn, st, name, since)
    return score, daily, alerts, shifts, anomalies


@app.get("/api/cashiers/{name}")
def cashier_detail(name: str, days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    score, daily, alerts, shifts, anomalies = _cashier_bundle(name, days, st)
    cases = rows(conn.execute(f"SELECT * FROM cases WHERE cashier=? AND store IN {_in(st)} ORDER BY id DESC", [name, *st]))
    return {"score": score, "daily": daily, "alerts": alerts, "shifts": shifts, "anomalies": anomalies, "cases": cases,
            "peer_metrics": PEER_METRICS, "summary": build_summary(score, alerts, anomalies, shifts)}


@app.get("/api/cashiers/{name}/ai-summary")
def cashier_ai_summary(name: str, days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    score, _daily, alerts, shifts, anomalies = _cashier_bundle(name, days, st)
    base = build_summary(score, alerts, anomalies, shifts)
    facts = {"score": {k: score[k] for k in ("score", "level", "alerts", "critical", "amount_at_risk", "net_drawer_diff", "z", "metrics")},
             "alerts_by_rule": dict(score["top_rules"]), "worst_days": sorted(anomalies, key=lambda a: -a["score"])[:5]}
    return polish_with_claude(base, facts)


@app.get("/api/alerts")
def list_alerts(status: str = "", cashier: str = "", rule: str = "", min_severity: int = 1, q: str = "", store: str = "",
                days: int = 0, id: int = 0, case_id: int = 0, assigned: str = "", overdue: bool = False, tag: str = "",
                limit: int = Query(200, le=5000), offset: int = 0, user: User = Depends(current_user)):
    st = scope(user, store)
    where, p = [f"store IN {_in(st)}", "severity >= ?"], [*st, min_severity]
    if assigned == "me":
        where.append("assigned_to = ?"); p.append(user.name)
    elif assigned == "unassigned":
        where.append("(assigned_to IS NULL OR assigned_to = '')")
    elif assigned:
        where.append("assigned_to = ?"); p.append(assigned)
    if overdue:
        where.append("due_at < ? AND status IN ('open','investigating')"); p.append(soc.now_utc())
    if tag:
        where.append("(',' || tags || ',') LIKE ?"); p.append(f"%,{tag},%")
    if id:
        where.append("id = ?"); p.append(id)
    if case_id:
        where.append("case_id = ?"); p.append(case_id)
    if status:
        sts = status.split(",")
        where.append(f"status IN {_in(sts)}"); p += sts
    if cashier:
        where.append("cashier = ?"); p.append(cashier)
    if rule:
        where.append("rule = ?"); p.append(rule)
    if q:
        where.append("(title LIKE ? OR txn_id LIKE ? OR notes LIKE ?)"); p += [f"%{q}%"] * 3
    since, _l = window_since(conn, st, days)
    w = " AND ".join(where)
    aw, ap = alert_since_sql(since)
    w += aw
    p += ap
    total = conn.execute(f"SELECT COUNT(*) n FROM alerts WHERE {w}", p).fetchone()["n"]
    items = [parse_alert(a) for a in rows(conn.execute(
        f"SELECT * FROM alerts WHERE {w} ORDER BY ts DESC, severity DESC LIMIT ? OFFSET ?", p + [limit, offset]))]
    if items:
        ids = [a["id"] for a in items]
        ev = defaultdict(int)
        for r in conn.execute(f"SELECT alert_id, COUNT(*) n FROM evidence WHERE alert_id IN {_in(ids)} GROUP BY alert_id", ids):
            ev[r["alert_id"]] = r["n"]
        now = soc.now_utc()
        for a in items:
            a["evidence"] = ev.get(a["id"], 0)
            a["overdue"] = bool(a["due_at"] and a["due_at"] < now and a["status"] in ("open", "investigating"))
    return {"total": total, "items": items, "rule_labels": rule_labels()}


@app.get("/api/alerts/{alert_id}/history")
def alert_history(alert_id: int, user: User = Depends(current_user)):
    alert_store_check(user, [alert_id])
    return rows(conn.execute("SELECT * FROM alert_history WHERE alert_id=? ORDER BY id DESC", (alert_id,)))


@app.get("/api/assignees")
def assignees(user: User = Depends(current_user)):
    """People who can own alerts (owners and managers)."""
    return [r["username"] for r in conn.execute("SELECT username FROM users WHERE active=1 AND role IN ('owner','manager') ORDER BY username")]


def _valid_assignee(name: str | None) -> str | None:
    if not name:
        return None
    if not conn.execute("SELECT 1 FROM users WHERE username=? AND active=1 AND role IN ('owner','manager')", (name,)).fetchone():
        raise HTTPException(400, f"{name} can't be assigned alerts")
    return name


class AlertUpdate(BaseModel):
    status: str | None = None
    notes: str | None = None
    assigned_to: str | None = None      # "" = unassign


STATUSES = soc.STATUSES


@app.patch("/api/alerts/{alert_id}")
def update_alert(alert_id: int, body: AlertUpdate, user: User = Depends(need("review"))):
    if body.status and body.status not in STATUSES:
        raise HTTPException(400, "Bad status")
    cur = conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
    if not cur:
        raise HTTPException(404)
    alert_store_check(user, [alert_id])
    soc.set_status(conn, alert_id, body.status, user.name, body.notes, commit=False)
    if body.assigned_to is not None:
        soc.assign(conn, alert_id, _valid_assignee(body.assigned_to), user.name, commit=False)
    if cur["case_id"] and (body.status or body.notes):
        conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                     (cur["case_id"], user.name, "alert", f"Alert #{alert_id} → {body.status or cur['status']}" + (f": {body.notes}" if body.notes else "")))
    conn.commit()
    audit(conn, user.name, f"alert {body.status or 'note'}", str(alert_id))
    return parse_alert(dict(conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()))


class BulkUpdate(BaseModel):
    ids: list[int]
    status: str | None = None
    assigned_to: str | None = None


@app.post("/api/alerts/bulk")
def bulk_update(body: BulkUpdate, user: User = Depends(need("review"))):
    if body.status and body.status not in STATUSES:
        raise HTTPException(400, "Bad status")
    if body.ids:
        alert_store_check(user, body.ids)
    who = _valid_assignee(body.assigned_to) if body.assigned_to else None
    for i in body.ids:
        if body.status:
            soc.set_status(conn, i, body.status, user.name, commit=False)
        if body.assigned_to is not None:
            soc.assign(conn, i, who, user.name, commit=False)
    conn.commit()
    audit(conn, user.name, f"bulk {body.status or 'assign → ' + (body.assigned_to or 'nobody')}", ",".join(map(str, body.ids[:50])))
    return {"updated": len(body.ids)}


@app.get("/api/transactions")
def transactions(cashier: str = "", type: str = "", order: str = "", q: str = "", start: str = "", end: str = "", store: str = "",
                 limit: int = Query(200, le=5000), offset: int = 0, user: User = Depends(current_user)):
    st = scope(user, store)
    where, p = [f"store IN {_in(st)}"], list(st)
    for col, val in (("cashier", cashier), ("txn_type", type), ("order_id", order)):
        if val:
            where.append(f"{col} = ?"); p.append(val)
    if q:
        where.append("(id LIKE ? OR note LIKE ? OR order_id LIKE ?)"); p += [f"%{q}%"] * 3
    if start:
        where.append("ts >= ?"); p.append(start)
    if end:
        where.append("ts <= ?"); p.append(end)
    w = " AND ".join(where)
    total = conn.execute(f"SELECT COUNT(*) n FROM transactions WHERE {w}", p).fetchone()["n"]
    return {"total": total, "items": rows(conn.execute(f"SELECT * FROM transactions WHERE {w} ORDER BY ts DESC LIMIT ? OFFSET ?", p + [limit, offset]))}


@app.get("/api/context")
def txn_context(store: str, id: str, minutes: int = 10, user: User = Depends(current_user)):
    """Everything on the same till around a transaction, plus CCTV links."""
    scope(user, store)
    t = conn.execute("SELECT * FROM transactions WHERE store=? AND id=?", (store, id)).fetchone()
    if not t:
        raise HTTPException(404)
    t = dict(t)
    dt = datetime.fromisoformat(t["ts"])
    a, b = (dt - timedelta(minutes=minutes)).isoformat(), (dt + timedelta(minutes=minutes)).isoformat()
    col, val = ("register", t["register"]) if t["register"] else ("cashier", t["cashier"])
    around = rows(conn.execute(f"SELECT * FROM transactions WHERE store=? AND {col}=? AND ts BETWEEN ? AND ? ORDER BY ts", (store, val, a, b)))
    order = rows(conn.execute("SELECT * FROM transactions WHERE store=? AND order_id=? AND order_id!='' ORDER BY ts", (store, t["order_id"])))
    linked = rows(conn.execute("SELECT * FROM transactions WHERE store=? AND (id=? OR original_txn_id=?)", (store, t["original_txn_id"] or "-", id)))
    return {"txn": t, "timeline": around, "order": order, "linked": linked, "cctv": links_for(conn, store, t["register"], t["ts"])}


# ================================================================== cases & evidence

class CaseIn(BaseModel):
    store: str
    cashier: str
    title: str
    alert_ids: list[int] = []


@app.get("/api/cases")
def list_cases(status: str = "", store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    q, p = f"SELECT * FROM cases WHERE store IN {_in(st)}", list(st)
    if status:
        q += " AND status=?"; p.append(status)
    out = rows(conn.execute(q + " ORDER BY status='open' DESC, updated_at DESC", p))
    for c in out:
        r = conn.execute("SELECT COUNT(*) n, SUM(amount) amt FROM alerts WHERE case_id=?", (c["id"],)).fetchone()
        c["alerts"], c["alert_value"] = r["n"], round(r["amt"] or 0, 2)
        c["evidence"] = conn.execute("SELECT COUNT(*) n FROM evidence WHERE case_id=? OR alert_id IN (SELECT id FROM alerts WHERE case_id=?)",
                                     (c["id"], c["id"])).fetchone()["n"]
    return out


def _link_alerts(cid: int, ids: list[int], actor: str) -> None:
    for i in ids:
        conn.execute("UPDATE alerts SET case_id=? WHERE id=?", (cid, i))
        soc.record(conn, i, actor, "case", None, cid)
        if (conn.execute("SELECT status FROM alerts WHERE id=?", (i,)).fetchone() or {"status": ""})["status"] == "open":
            soc.set_status(conn, i, "investigating", actor, commit=False)


@app.post("/api/cases")
def create_case(body: CaseIn, user: User = Depends(need("cases"))):
    scope(user, body.store)
    cur = conn.execute("INSERT INTO cases(store, cashier, title, created_by) VALUES(?,?,?,?)", (body.store, body.cashier, body.title, user.name))
    cid = cur.lastrowid
    if body.alert_ids:
        alert_store_check(user, body.alert_ids)
        _link_alerts(cid, body.alert_ids, user.name)
    conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                 (cid, user.name, "status", f"Case opened with {len(body.alert_ids)} alert(s)"))
    conn.commit()
    audit(conn, user.name, "opened case", str(cid))
    return {"id": cid}


@app.get("/api/cases/{cid}")
def get_case(cid: int, user: User = Depends(current_user)):
    c = _case(cid, user)
    alerts = [parse_alert(a) for a in rows(conn.execute("SELECT * FROM alerts WHERE case_id=? ORDER BY ts", (cid,)))]
    events = rows(conn.execute("SELECT * FROM case_events WHERE case_id=? ORDER BY id DESC", (cid,)))
    evidence = rows(conn.execute("SELECT * FROM evidence WHERE case_id=? OR alert_id IN (SELECT id FROM alerts WHERE case_id=?) ORDER BY id DESC", (cid, cid)))
    return {"case": c, "alerts": alerts, "events": events, "evidence": evidence}


class CaseUpdate(BaseModel):
    title: str | None = None
    status: str | None = None
    outcome: str | None = None
    loss_amount: float | None = None
    recovered: float | None = None


@app.patch("/api/cases/{cid}")
def update_case(cid: int, body: CaseUpdate, user: User = Depends(need("cases"))):
    c = _case(cid, user)
    if body.status and body.status not in ("open", "closed_theft", "closed_cleared"):
        raise HTTPException(400, "Bad status")
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    if data:
        conn.execute(f"UPDATE cases SET {', '.join(f'{k}=?' for k in data)}, updated_at=CURRENT_TIMESTAMP WHERE id=?", [*data.values(), cid])
        if body.status and body.status != c["status"]:
            conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                         (cid, user.name, "status", f"Status → {body.status.replace('_', ' ')}"))
            final = {"closed_theft": "confirmed", "closed_cleared": "dismissed"}.get(body.status)
            if final:
                for r in conn.execute("SELECT id FROM alerts WHERE case_id=? AND status IN ('open','investigating')", (cid,)).fetchall():
                    soc.set_status(conn, r["id"], final, f"{user.name} (case #{cid} closed)", commit=False)
        conn.commit()
    audit(conn, user.name, "updated case", str(cid))
    return {"ok": True}


class Note(BaseModel):
    body: str


@app.post("/api/cases/{cid}/notes")
def case_note(cid: int, body: Note, user: User = Depends(need("cases"))):
    _case(cid, user)
    conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)", (cid, user.name, "note", body.body[:4000]))
    conn.execute("UPDATE cases SET updated_at=CURRENT_TIMESTAMP WHERE id=?", (cid,))
    conn.commit()
    return {"ok": True}


class AlertIds(BaseModel):
    alert_ids: list[int]


@app.post("/api/cases/{cid}/alerts")
def case_add_alerts(cid: int, body: AlertIds, user: User = Depends(need("cases"))):
    _case(cid, user)
    alert_store_check(user, body.alert_ids)
    _link_alerts(cid, body.alert_ids, user.name)
    conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                 (cid, user.name, "alert", f"Added {len(body.alert_ids)} alert(s)"))
    conn.commit()
    return {"ok": True}


@app.get("/api/cases/{cid}/file", response_class=HTMLResponse)
def case_file(cid: int, user: User = Depends(current_user)):
    c = _case(cid, user)
    summary = None
    try:
        st = [c["store"]]
        score, _d, alerts, shifts, anomalies = _cashier_bundle(c["cashier"], 0, st)
        summary = build_summary(score, alerts, anomalies, shifts)
    except HTTPException:
        pass
    audit(conn, user.name, "exported case file", str(cid))
    return build_case_file(conn, cid, summary)


@app.post("/api/evidence")
async def upload_evidence(file: UploadFile = File(...), alert_id: int = Form(0), case_id: int = Form(0), note: str = Form(""),
                          user: User = Depends(need("cases"))):
    if not alert_id and not case_id:
        raise HTTPException(400, "Attach to an alert or a case")
    if alert_id:
        alert_store_check(user, [alert_id])
    if case_id:
        _case(case_id, user)
    ext = Path(file.filename or "").suffix.lower()
    if ext not in EVIDENCE_EXT:
        raise HTTPException(400, f"File type {ext or '?'} not allowed")
    stored = f"{uuid.uuid4().hex}{ext}"
    path = DATA_DIR / "evidence" / stored
    size = 0
    digest = hashlib.sha256()                        # chain of custody: fingerprint the file as it arrives
    with open(path, "wb") as fh:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_EVIDENCE_MB * 1024 * 1024:
                fh.close()
                path.unlink(missing_ok=True)
                raise HTTPException(413, f"Max {MAX_EVIDENCE_MB} MB")
            digest.update(chunk)
            fh.write(chunk)
    mime = file.content_type or mimetypes.guess_type(file.filename or "")[0] or "application/octet-stream"
    cur = conn.execute("INSERT INTO evidence(alert_id, case_id, filename, stored_name, mime, size, note, uploaded_by, sha256) VALUES(?,?,?,?,?,?,?,?,?)",
                       (alert_id or None, case_id or None, Path(file.filename or "file").name[:200], stored, mime, size, note[:500], user.name,
                        digest.hexdigest()))
    target_case = case_id or (conn.execute("SELECT case_id FROM alerts WHERE id=?", (alert_id,)).fetchone() or {"case_id": None})["case_id"]
    if target_case:
        conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                     (target_case, user.name, "evidence", f"Uploaded {file.filename}" + (f" — {note}" if note else "")))
    conn.commit()
    audit(conn, user.name, "uploaded evidence", f"{file.filename} sha256={digest.hexdigest()}")
    return {"id": cur.lastrowid, "sha256": digest.hexdigest()}


@app.get("/api/evidence")
def list_evidence(alert_id: int = 0, case_id: int = 0, user: User = Depends(current_user)):
    if alert_id:
        alert_store_check(user, [alert_id])
        return rows(conn.execute("SELECT * FROM evidence WHERE alert_id=? ORDER BY id DESC", (alert_id,)))
    _case(case_id, user)
    return rows(conn.execute("SELECT * FROM evidence WHERE case_id=? ORDER BY id DESC", (case_id,)))


@app.get("/api/evidence/{eid}/file")
def get_evidence(eid: int, user: User = Depends(current_user)):
    e = conn.execute("SELECT * FROM evidence WHERE id=?", (eid,)).fetchone()
    if not e:
        raise HTTPException(404)
    if e["alert_id"]:
        alert_store_check(user, [e["alert_id"]])
    if e["case_id"]:
        _case(e["case_id"], user)
    return FileResponse(DATA_DIR / "evidence" / e["stored_name"], media_type=e["mime"], filename=e["filename"],
                        content_disposition_type="inline")


@app.delete("/api/evidence/{eid}")
def del_evidence(eid: int, user: User = Depends(need("admin"))):
    e = conn.execute("SELECT * FROM evidence WHERE id=?", (eid,)).fetchone()
    if e:
        (DATA_DIR / "evidence" / e["stored_name"]).unlink(missing_ok=True)
        conn.execute("DELETE FROM evidence WHERE id=?", (eid,))
        conn.commit()
        audit(conn, user.name, "deleted evidence", e["filename"])
    return {"ok": True}


# ================================================================== reports

class ReportIn(BaseModel):
    days: int = 7
    kind: str = "custom"
    store: str = ""
    email: bool = False


@app.get("/api/reports")
def list_reports(user: User = Depends(current_user)):
    return rows(conn.execute("SELECT id, kind, store, period_start, period_end, headline, emailed, created_by, created_at FROM reports ORDER BY id DESC LIMIT 100"))


@app.post("/api/reports")
def make_report(body: ReportIn, user: User = Depends(need("reports"))):
    st = scope(user, body.store)
    try:
        rep = save_report(conn, st, body.days, body.kind if body.kind in ("daily", "weekly", "custom") else "custom", user.name)
    except ValueError as e:
        raise HTTPException(400, str(e))
    emailed = email_report(rep["title"], rep["html"]) if body.email else False
    if emailed:
        conn.execute("UPDATE reports SET emailed=1 WHERE id=?", (rep["id"],))
        conn.commit()
    audit(conn, user.name, "created report", rep["title"])
    return {"id": rep["id"], "title": rep["title"], "headline": rep["headline"], "emailed": emailed}


@app.get("/api/reports/{rid}/view", response_class=HTMLResponse)
def view_report(rid: int, user: User = Depends(current_user)):
    r = conn.execute("SELECT * FROM reports WHERE id=?", (rid,)).fetchone()
    if not r:
        raise HTTPException(404)
    for s in [x for x in (r["store"] or "").split(",") if x]:
        scope(user, s)
    return (DATA_DIR / "reports" / r["file"]).read_text(encoding="utf-8")


# ================================================================== import / detection / settings

@app.post("/api/import")
async def upload(file: UploadFile = File(...), kind: str = Form("auto"), store: str = Form("main"), user: User = Depends(need("import"))):
    store = slug(store)
    if user.can("admin") and not conn.execute("SELECT 1 FROM stores WHERE id=?", (store,)).fetchone():
        ensure_stores(conn, [store])          # owner can import into a brand-new store
        conn.commit()
    scope(user, store)
    content = await file.read()
    if len(content) > 100 * 1024 * 1024:
        raise HTTPException(413, "File too large (max 100 MB)")
    try:
        res = import_file(conn, content, file.filename or "upload.csv", kind, store=store)
    except ValueError as e:
        raise HTTPException(400, str(e))
    det = after_import(res["stores"] or [store])
    audit(conn, user.name, f"import → {store}", file.filename or "")
    return {**res, "new_alerts": det["new_count"]}


@app.post("/api/detect")
def detect(user: User = Depends(need("import"))):
    det = after_import(user.store_ids(conn))
    audit(conn, user.name, "run detection")
    return {"new_alerts": det["new_count"], "total_found": det["total_found"]}


@app.post("/api/sync")
def sync_api(user: User = Depends(need("import"))):
    c = SplitPOSApiConnector()
    if not c.configured:
        raise HTTPException(400, "SplitPOS API is not configured. Set SPLITPOS_API_URL and SPLITPOS_API_KEY.")
    added = c.sync(conn)
    det = after_import()
    return {"added": added, "new_alerts": det["new_count"]}


@app.get("/api/imports")
def imports(user: User = Depends(current_user)):
    st = user.store_ids(conn) or ["-"]
    return rows(conn.execute(f"SELECT * FROM import_log WHERE store IN {_in(st)} ORDER BY id DESC LIMIT 100", st))


@app.get("/api/settings/rules")
def get_rules(user: User = Depends(current_user)):
    return merged_rules(get_setting(conn, "rules", {}))


@app.put("/api/settings/rules")
def put_rules(body: dict, rerun: bool = True, user: User = Depends(need("admin"))):
    current = get_setting(conn, "rules", {})
    for k, v in body.items():
        if k in DEFAULT_RULES and isinstance(v, dict):
            clean = {kk: vv for kk, vv in v.items() if kk in DEFAULT_RULES[k] and kk != "label"}
            current.setdefault(k, {}).update(clean)
    set_setting(conn, "rules", current)
    audit(conn, user.name, "update rules")
    det = after_import() if rerun else {"new_count": 0}
    return {"rules": merged_rules(current), "new_alerts": det["new_count"]}


@app.post("/api/notify/test")
def notify_test(user: User = Depends(need("admin"))):
    sent = broadcast("DrawerGuard test alert ✅", "If you can read this, phone/email alerts are working.", "default")
    return {"channels": sent, "configured": channels_status()}


@app.get("/api/audit")
def audit_log(user: User = Depends(need("admin"))):
    return rows(conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 300"))


@app.get("/api/audit/verify")
def audit_verify(user: User = Depends(need("admin"))):
    return verify_audit(conn)


@app.post("/api/siem/test")
def siem_test(user: User = Depends(need("admin"))):
    sample = {"id": 0, "fingerprint": "test", "store": "main", "rule": "no_sale_after_cash", "severity": 4, "cashier": "TEST",
              "register": "Till 1", "ts": datetime.now().isoformat(timespec="seconds"), "txn_id": "TEST-1", "amount": 0,
              "title": "DrawerGuard SIEM test event", "details": {}}
    return {"configured": siem.configured(), "sent": siem.forward([sample]), "cef": siem.to_cef(sample), "ecs": siem.to_ecs(sample)}


@app.get("/api/export/alerts.jsonl")
def export_jsonl(store: str = "", user: User = Depends(current_user)):
    """ECS-style JSON lines: import into Elastic, Splunk, Sentinel or a data lake."""
    st = scope(user, store)
    lines = (json.dumps(siem.to_ecs(dict(a)), default=str) for a in conn.execute(f"SELECT * FROM alerts WHERE store IN {_in(st)} ORDER BY ts", st))
    audit(conn, user.name, "exported alerts (JSONL)")
    return StreamingResponse((ln + "\n" for ln in lines), media_type="application/x-ndjson",
                             headers={"Content-Disposition": "attachment; filename=drawerguard_alerts.jsonl"})


@app.get("/api/export/alerts.cef")
def export_cef(store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    lines = (siem.to_cef(dict(a)) for a in conn.execute(f"SELECT * FROM alerts WHERE store IN {_in(st)} ORDER BY ts", st))
    audit(conn, user.name, "exported alerts (CEF)")
    return StreamingResponse((ln + "\n" for ln in lines), media_type="text/plain",
                             headers={"Content-Disposition": "attachment; filename=drawerguard_alerts.cef"})


def csv_safe(v):
    """Neutralise spreadsheet formula injection (CWE-1236): cashier names, notes and titles come
    from POS data an insider controls, so a cell starting with = + - @ must not run in Excel."""
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + v
    return v


@app.get("/api/export/alerts.csv")
def export_alerts(status: str = "", store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    where, p = f"WHERE store IN {_in(st)}", list(st)
    if status:
        where += " AND status=?"; p.append(status)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "store", "time", "severity", "cashier", "register", "rule", "title", "amount", "transaction", "status", "case", "notes"])
    for a in conn.execute(f"SELECT * FROM alerts {where} ORDER BY ts", p):
        w.writerow([csv_safe(x) for x in (a["id"], a["store"], a["ts"], a["severity"], a["cashier"], a["register"],
                    rule_labels().get(a["rule"], a["rule"]), a["title"], a["amount"], a["txn_id"], a["status"], a["case_id"] or "", a["notes"])])
    audit(conn, user.name, "exported alerts")
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=drawerguard_alerts.csv"})


# ================================================================== app shell & PWA

from .api import (compliance_api, deception_api, detection_api, forensics_api, hunt_api, integrations_api,  # noqa: E402
                  investigate_api, ir_api, ml_api, payroll_api, platform_api, purple_api, soc_api)

for _r in (soc_api.router, detection_api.router, hunt_api.router, forensics_api.router, platform_api.router,
           payroll_api.router, ml_api.router, purple_api.router, ir_api.router, deception_api.router, investigate_api.router,
           compliance_api.router, integrations_api.router):
    app.include_router(_r)

app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")


@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")


@app.get("/manifest.json")
def manifest():
    return FileResponse(BASE / "static" / "manifest.json", media_type="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    return FileResponse(BASE / "static" / "sw.js", media_type="application/javascript", headers={"Service-Worker-Allowed": "/"})


@app.get("/robots.txt", response_class=PlainTextResponse)
def robots():
    return "User-agent: *\nDisallow: /\n"


_ = (secrets, Response)
