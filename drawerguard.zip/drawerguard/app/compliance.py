"""Continuous control monitoring: DrawerGuard's own controls checked live and mapped to
PCI DSS v4.0.1, NIST CSF 2.0 and CIS Controls v8.

Each check looks at the running system (settings, users, logs, backups, data) and returns
pass / warn / fail / info with evidence and a fix. The mapping shows which requirement a
control *supports*: DrawerGuard is a monitoring tool for a merchant, not a certified
component, and passing these checks is evidence for an assessor, not certification.
"""
import html
import os
from datetime import datetime, timedelta, timezone

from .db import verify_audit

FRAMEWORKS = ("PCI DSS v4.0.1", "NIST CSF 2.0", "CIS Controls v8")


def _in(xs):
    return f"({','.join('?' * len(xs))})"


def _env_int(k, d):
    try:
        return int(os.environ.get(k, d))
    except ValueError:
        return int(d)


def _r(status, evidence, fix=""):
    return {"status": status, "evidence": evidence, "fix": fix}


# ------------------------------------------------------------------ checks

def chk_mfa(conn, stores):
    rows = conn.execute("SELECT username, totp_secret FROM users WHERE active=1 AND role IN ('owner','manager')").fetchall()
    on = [r["username"] for r in rows if r["totp_secret"]]
    off = [r["username"] for r in rows if not r["totp_secret"]]
    if rows and not off:
        return _r("pass", f"All {len(rows)} owner/manager accounts use TOTP 2FA.")
    return _r("fail" if not on else "warn", f"2FA on {len(on)} of {len(rows)} owner/manager accounts. Missing: {', '.join(off[:8])}.",
              "Each owner and manager: My account → Turn on 2FA.")


def chk_lockout(conn, stores):
    n, m = _env_int("LOCKOUT_ATTEMPTS", "8"), _env_int("LOCKOUT_MINUTES", "30")
    ok = n <= 10 and m >= 30
    return _r("pass" if ok else "fail", f"Account locks after {n} failed attempts for {m} minutes; per-IP blocking and spraying detection on.",
              "" if ok else "Set LOCKOUT_ATTEMPTS ≤ 10 and LOCKOUT_MINUTES ≥ 30 in .env.")


def chk_pw_length(conn, stores):
    n = _env_int("PASSWORD_MIN_LENGTH", "8")
    return _r("pass" if n >= 12 else "warn", f"Minimum password length is {n} characters (PBKDF2-SHA256, 200,000 iterations).",
              "" if n >= 12 else "Set PASSWORD_MIN_LENGTH=12 in .env.")


def chk_idle(conn, stores):
    n = _env_int("IDLE_TIMEOUT_MINUTES", "15")
    ok = 0 < n <= 15
    return _r("pass" if ok else "warn", f"The dashboard signs out after {n} idle minutes." if n else "Idle sign-out is turned off.",
              "" if ok else "Set IDLE_TIMEOUT_MINUTES=15 in .env.")


def chk_default_pw(conn, stores):
    from .auth import check_pw
    pw = os.environ.get("DRAWERGUARD_PASSWORD", "changeme")
    r = conn.execute("SELECT pw_hash FROM users WHERE username='owner'").fetchone()
    weak = r and pw in ("changeme", "choose-a-strong-password") and check_pw(pw, r["pw_hash"])
    return _r("fail" if weak else "pass", "The owner account still uses the example password." if weak else "No account uses the shipped default password.",
              "Change the owner password under My account." if weak else "")


def chk_stale_accounts(conn, stores):
    cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S")
    rows = conn.execute("SELECT username, last_login, created_at FROM users WHERE active=1").fetchall()
    stale = [r["username"] for r in rows if (r["last_login"] or r["created_at"] or "") < cutoff]
    by_role = {r["role"]: r["n"] for r in conn.execute("SELECT role, COUNT(*) n FROM users WHERE active=1 GROUP BY role")}
    return _r("warn" if stale else "pass",
              f"{len(rows)} active accounts ({', '.join(f'{k}: {v}' for k, v in by_role.items())}). "
              + (f"Not used for 90+ days: {', '.join(stale[:8])}." if stale else "None unused for 90+ days."),
              "Disable accounts that haven't signed in for 90 days (Users page)." if stale else "")


def chk_audit_chain(conn, stores):
    v = verify_audit(conn)
    return _r("pass" if v["ok"] else "fail", f"Hash-chained audit log: {v['message']}",
              "" if v["ok"] else "Investigate the break: compare with the SIEM copy and the latest backup.")


def chk_audit_retention(conn, stores):
    r = conn.execute("SELECT MIN(created_at) first, COUNT(*) n FROM audit_log").fetchone()
    days = _env_int("RETENTION_DAYS", "0")
    return _r("pass", f"{r['n']:,} audit entries since {(r['first'] or '—')[:10]}. Audit entries are never deleted by data retention "
                      f"(transaction retention: {'keep forever' if not days else f'{days} days'}).")


def chk_siem(conn, stores):
    from . import siem
    on = [k for k, v in siem.configured().items() if v]
    return _r("pass" if on else "warn", f"Alerts forwarded to: {', '.join(on)}." if on else "Alerts are not forwarded to a SIEM or central log.",
              "" if on else "Set SIEM_SYSLOG_HOST, SPLUNK_HEC_URL, SIEM_ELASTIC_URL or SIEM_WEBHOOK_URL (see siem-lab/).")


def chk_daily_review(conn, stores):
    since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
    r = conn.execute(f"SELECT COUNT(*) n, SUM(acked_at IS NOT NULL AND (julianday(acked_at) - julianday(created_at)) <= 1) quick "
                     f"FROM alerts WHERE severity >= 4 AND created_at >= ? AND store IN {_in(stores)}", [since, *stores]).fetchone()
    n, quick = r["n"] or 0, r["quick"] or 0
    if not n:
        return _r("info", "No high-severity alerts in the last 30 days. Detection runs automatically on every import.")
    pct = quick / n
    return _r("pass" if pct >= .9 else "warn" if pct >= .5 else "fail",
              f"{quick} of {n} high/critical alerts from the last 30 days were reviewed within 24 hours ({pct:.0%}). Review is automated "
              "(30 detections) and every decision is recorded in the alert history.",
              "" if pct >= .9 else "Work the SLA queue daily (SOC metrics → overdue); add playbooks to auto-assign.")


def chk_overdue(conn, stores):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    r = conn.execute(f"SELECT COUNT(*) n, SUM(severity>=5) crit FROM alerts WHERE status IN ('open','investigating') AND due_at < ? "
                     f"AND store IN {_in(stores)}", [now, *stores]).fetchone()
    n, crit = r["n"] or 0, r["crit"] or 0
    return _r("pass" if not n else "warn" if not crit else "fail", f"{n} alerts are past their SLA ({crit} critical).",
              "" if not n else "Assign and resolve overdue alerts; suppress known-good patterns with a documented reason.")


def chk_backups(conn, stores):
    from .maintenance import list_backups
    b = list_backups()
    if not b:
        return _r("fail", "No database backups found.", "Keep BACKUP_DAILY=1, or press Back up now (Security center).")
    age = (datetime.now() - datetime.fromisoformat(b[0]["created"])).total_seconds() / 3600
    return _r("pass" if age <= 26 else "warn", f"{len(b)} backups; newest {b[0]['name']} ({age:.0f} h ago). Copy data/backups off this PC too.",
              "" if age <= 26 else "Check the daily backup job (BACKUP_DAILY=1).")


def chk_pan(conn, stores):
    from .ingest.csv_importer import find_pans
    hits = 0
    for r in conn.execute(f"SELECT note, order_id FROM transactions WHERE store IN {_in(stores)} AND (note GLOB '*[0-9][0-9][0-9][0-9]*' "
                          f"OR order_id GLOB '*[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]*')", stores):
        hits += len(find_pans(r["note"])) + len(find_pans(r["order_id"]))
    masked = conn.execute("SELECT COUNT(*) n FROM audit_log WHERE action='masked card numbers on import'").fetchone()["n"]
    return _r("fail" if hits else "pass",
              (f"{hits} card-number-like values (Luhn-valid) found in stored transactions." if hits else
               "No card numbers stored: free-text fields are scanned (Luhn) and masked on import, last 4 digits kept.")
              + (f" Masking happened during {masked} import(s)." if masked else ""),
              "Remove card numbers from the POS export (don't type them into notes) and re-import." if hits else "")


def chk_ir(conn, stores):
    r = conn.execute(f"SELECT COUNT(*) n, SUM(phase != 'detection') moved, SUM(status != 'open') closed FROM cases WHERE store IN {_in(stores)}",
                     stores).fetchone()
    if not r["n"]:
        return _r("warn", "No cases yet: the incident-response process (NIST 800-61 phases, checklists, report) hasn't been exercised.",
                  "Open a case from an alert and walk it through the phases.")
    return _r("pass" if r["moved"] else "warn", f"{r['n']} cases; {r['moved'] or 0} progressed past detection, {r['closed'] or 0} closed "
                                                 "with an outcome. Each case keeps a timestamped checklist and an exportable report.")


def chk_purple(conn, stores):
    since = (datetime.now(timezone.utc) - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S")
    r = conn.execute(f"SELECT COUNT(*) n, MAX(coverage) best, MAX(created_at) last FROM purple_runs WHERE created_at >= ? "
                     f"AND store IN {_in(stores)}", [since, *stores]).fetchone()
    if not r["n"]:
        return _r("warn", "No purple-team simulation in the last 90 days.", "Run one from the Purple team page after any rule change.")
    return _r("pass", f"{r['n']} purple-team runs in 90 days; latest {r['last'][:10]}, best coverage {r['best']:.0%}.")


def chk_dac(conn, stores):
    from .detection.dac import load_all, validate
    items = load_all()
    problems = validate(items)
    tests = sum(len(d.get("tests", [])) for d in items)
    return _r("fail" if problems else "pass",
              f"{len(items)} detections as code with {tests} tests; {len(problems)} validation problems. CI runs every test on each change.",
              "Run python scripts/dac.py and fix the reported files." if problems else "")


def chk_data_health(conn, stores):
    from .maintenance import data_health
    h = data_health(conn, stores)
    bad = [x["name"] for x in h if x["status"] not in ("ok",)]
    return _r("pass" if not bad else "warn", f"{len(h) - len(bad)} of {len(h)} stores sending data normally."
              + (f" Check: {', '.join(bad)}." if bad else ""), "Fix the export or inbox job for the listed stores." if bad else "")


def chk_sod(conn, stores):
    since = (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%S")
    n = conn.execute(f"SELECT COUNT(*) n FROM transactions WHERE store IN {_in(stores)} AND ts >= ? AND approved_by != '' "
                     f"AND lower(approved_by) = lower(cashier) AND txn_type != 'sale'", [*stores, since]).fetchone()["n"]
    return _r("pass" if not n else "warn", f"{n} self-approved overrides in the last 30 days (DG-012).",
              "" if not n else "Remove override rights from cashier logins in SplitPOS; managers approve with their own PIN.")


def chk_transport(conn, stores):
    # only read to report the exposure, never used to bind
    host = os.environ.get("HOST", "0.0.0.0")  # noqa: S104  # nosec B104
    if host in ("127.0.0.1", "localhost"):
        return _r("pass", "Bound to this PC only (HOST=127.0.0.1).")
    if os.environ.get("TRUST_PROXY") == "1":
        return _r("pass", "Served behind a reverse proxy (TRUST_PROXY=1); the proxy terminates HTTPS.")
    return _r("warn", f"Listening on {host} without TLS: fine on a trusted Wi-Fi, not across the internet.",
              "Set HOST=127.0.0.1, or put DrawerGuard behind HTTPS (Caddy, Nginx, Cloudflare Tunnel).")


def chk_time(conn, stores):
    return _r("info", "Timestamps come from the host clock and the POS export. Keep Windows time sync on, and set each camera's DVR offset "
                      "on Stores & CCTV so footage lines up.")


def chk_deception(conn, stores):
    c = conn.execute("SELECT COUNT(*) n FROM canaries WHERE enabled=1").fetchone()["n"]
    w = conn.execute(f"SELECT COUNT(*) n FROM watchlist WHERE store IN {_in(stores)}", stores).fetchone()["n"]
    return _r("pass" if c else "info", f"{c} canaries (honeytokens) planted; {w} cashiers on the watchlist.",
              "" if c else "Plant a canary manager code (Canaries & watchlist page): any use is a critical alert.")


CONTROLS = [
    # id, area, title, check, mapping
    ("IA-01", "Identity & access", "Multi-factor authentication for owners and managers", chk_mfa,
     {"PCI DSS v4.0.1": ["8.4.2"], "NIST CSF 2.0": ["PR.AA-03"], "CIS Controls v8": ["6.5"]}),
    ("IA-02", "Identity & access", "Account lockout after repeated failures", chk_lockout,
     {"PCI DSS v4.0.1": ["8.3.4"], "NIST CSF 2.0": ["PR.AA-03"]}),
    ("IA-03", "Identity & access", "Password length", chk_pw_length,
     {"PCI DSS v4.0.1": ["8.3.6"], "NIST CSF 2.0": ["PR.AA-01"], "CIS Controls v8": ["5.2"]}),
    ("IA-04", "Identity & access", "Idle session timeout", chk_idle,
     {"PCI DSS v4.0.1": ["8.2.8"], "NIST CSF 2.0": ["PR.AA-03"]}),
    ("IA-05", "Identity & access", "No default passwords", chk_default_pw,
     {"PCI DSS v4.0.1": ["2.2.2"], "NIST CSF 2.0": ["PR.AA-01"], "CIS Controls v8": ["4.7"]}),
    ("IA-06", "Identity & access", "Inactive accounts reviewed", chk_stale_accounts,
     {"PCI DSS v4.0.1": ["8.2.6", "7.2.4"], "NIST CSF 2.0": ["PR.AA-05"], "CIS Controls v8": ["5.3"]}),
    ("IA-07", "Identity & access", "Separation of duties on overrides", chk_sod,
     {"NIST CSF 2.0": ["PR.AA-05"]}),
    ("LM-01", "Logging & monitoring", "Tamper-evident audit log", chk_audit_chain,
     {"PCI DSS v4.0.1": ["10.2.1", "10.3.2", "10.3.4"], "NIST CSF 2.0": ["PR.PS-04", "RS.AN-06"], "CIS Controls v8": ["8.2"]}),
    ("LM-02", "Logging & monitoring", "Audit log retention", chk_audit_retention,
     {"PCI DSS v4.0.1": ["10.5.1"], "NIST CSF 2.0": ["PR.PS-04"], "CIS Controls v8": ["8.10"]}),
    ("LM-03", "Logging & monitoring", "Alerts sent to a central SIEM", chk_siem,
     {"PCI DSS v4.0.1": ["10.3.3"], "NIST CSF 2.0": ["DE.AE-03", "DE.AE-06"], "CIS Controls v8": ["8.9"]}),
    ("LM-04", "Logging & monitoring", "Automated daily review of security events", chk_daily_review,
     {"PCI DSS v4.0.1": ["10.4.1", "10.4.1.1"], "NIST CSF 2.0": ["DE.CM-03", "DE.AE-02"], "CIS Controls v8": ["8.11"]}),
    ("LM-05", "Logging & monitoring", "Exceptions addressed within SLA", chk_overdue,
     {"PCI DSS v4.0.1": ["10.4.3"], "NIST CSF 2.0": ["RS.MA-02"]}),
    ("LM-06", "Logging & monitoring", "Detection data sources are healthy", chk_data_health,
     {"PCI DSS v4.0.1": ["10.7.2"], "NIST CSF 2.0": ["PR.PS-04"]}),
    ("LM-07", "Logging & monitoring", "Time synchronisation", chk_time,
     {"PCI DSS v4.0.1": ["10.6.1"], "CIS Controls v8": ["8.4"]}),
    ("DP-01", "Data protection", "No card numbers (PAN) stored", chk_pan,
     {"PCI DSS v4.0.1": ["3.2.1", "3.5.1"], "NIST CSF 2.0": ["PR.DS-01"]}),
    ("DP-02", "Data protection", "Backups are current", chk_backups,
     {"NIST CSF 2.0": ["PR.DS-11"], "CIS Controls v8": ["11.2"]}),
    ("DP-03", "Data protection", "Exposure and encryption in transit", chk_transport,
     {"NIST CSF 2.0": ["PR.DS-02"], "CIS Controls v8": ["3.10"]}),
    ("IR-01", "Incident response", "Incident-response process in use", chk_ir,
     {"PCI DSS v4.0.1": ["12.10.1"], "NIST CSF 2.0": ["RS.MA-01", "RS.AN-03"], "CIS Controls v8": ["17.4"]}),
    ("IR-02", "Incident response", "Detections tested by adversary simulation", chk_purple,
     {"NIST CSF 2.0": ["ID.IM-02"]}),
    ("DE-01", "Detection engineering", "Detection content versioned and tested", chk_dac,
     {"NIST CSF 2.0": ["ID.IM-02", "DE.CM-03"]}),
    ("DE-02", "Detection engineering", "Deception (honeytokens) deployed", chk_deception,
     {"NIST CSF 2.0": ["DE.CM-03"]}),
]


def assess(conn, stores: list[str]) -> dict:
    controls = []
    for cid, area, title, fn, mapping in CONTROLS:
        try:
            res = fn(conn, stores)
        except Exception as e:                    # a broken check must not hide the others
            res = _r("warn", f"Check could not run: {e}")
        controls.append({"id": cid, "area": area, "title": title, "mapping": mapping, **res})
    scored = [c for c in controls if c["status"] != "info"]
    pts = dict(zip(("pass", "warn", "fail"), (1, 0.5, 0), strict=True))

    def score(items):
        return round(sum(pts[c["status"]] for c in items) / len(items) * 100) if items else None
    fw = {}
    for f in FRAMEWORKS:
        items = [c for c in scored if f in c["mapping"]]
        fw[f] = {"score": score(items), "controls": len(items), "requirements": sorted({r for c in items for r in c["mapping"][f]}),
                 **{s: sum(1 for c in items if c["status"] == s) for s in ("pass", "warn", "fail")}}
    return {"score": score(scored), "generated": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "counts": {s: sum(1 for c in controls if c["status"] == s) for s in ("pass", "warn", "fail", "info")},
            "frameworks": fw, "controls": controls,
            "disclaimer": "DrawerGuard is a monitoring tool for the merchant. These checks show which requirements its controls support; "
                          "they are evidence for an assessor, not a certification."}


def report_html(a: dict, who: str) -> str:
    e = lambda v: html.escape(str(v))  # noqa: E731
    color = dict(zip(("pass", "warn", "fail", "info"), ("#059669", "#d97706", "#dc2626", "#64748b"), strict=True))
    fw = "".join(f"<tr><td><b>{e(k)}</b></td><td>{v['score'] if v['score'] is not None else '—'}%</td><td>{v['pass']}</td><td>{v['warn']}</td>"
                 f"<td>{v['fail']}</td><td class=small>{e(', '.join(v['requirements']))}</td></tr>" for k, v in a["frameworks"].items())
    rows = "".join(f"<tr><td><b>{e(c['id'])}</b></td><td>{e(c['title'])}<div class=small>{e(c['area'])}</div></td>"
                   f"<td><b style='color:{color[c['status']]}'>{c['status'].upper()}</b></td><td>{e(c['evidence'])}"
                   + (f"<div class=fix>Fix: {e(c['fix'])}</div>" if c["fix"] else "") + "</td><td class=small>"
                   + "<br>".join(f"{e(k)}: {e(', '.join(v))}" for k, v in c["mapping"].items()) + "</td></tr>" for c in a["controls"])
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>DrawerGuard control evidence report</title>
<style>body{{font:13.5px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;max-width:1000px;margin:30px auto;padding:0 20px;color:#0f172a}}
h1{{font-size:22px;margin:0}}table{{width:100%;border-collapse:collapse;margin-top:12px}}td,th{{border-bottom:1px solid #e2e8f0;padding:6px;text-align:left;vertical-align:top}}
.small{{color:#64748b;font-size:11.5px}}.fix{{color:#7c4a03;font-size:12px;margin-top:3px}}.big{{font-size:34px;font-weight:800}}
@media print{{.noprint{{display:none}}}}</style></head><body>
<div class=noprint style="margin-bottom:14px"><button onclick="print()">🖨️ Print / save as PDF</button></div>
<h1>Control evidence report</h1><div class=small>Generated {e(a['generated'])} by {e(who)} with DrawerGuard</div>
<p><span class=big>{a['score']}%</span> overall · {a['counts']['pass']} pass · {a['counts']['warn']} warn · {a['counts']['fail']} fail · {a['counts']['info']} info</p>
<p class=small>{e(a['disclaimer'])}</p>
<h2>By framework</h2><table><tr><th>Framework</th><th>Score</th><th>Pass</th><th>Warn</th><th>Fail</th><th>Requirements covered</th></tr>{fw}</table>
<h2>Controls</h2><table><tr><th>ID</th><th>Control</th><th>Status</th><th>Evidence</th><th>Mapping</th></tr>{rows}</table>
</body></html>"""
