"""Backups, data retention and data-source health ("log source monitoring")."""
import json
import os
import re
import sqlite3
from datetime import datetime, timedelta, timezone

from .db import DATA_DIR, rows

BACKUP_DIR = DATA_DIR / "backups"
BACKUP_RE = re.compile(r"^drawerguard_\d{8}_\d{6}\.db$")


def backup(conn, keep: int | None = None) -> dict:
    """Consistent online copy of the live database (SQLite backup API), keeping the newest N."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    name = f"drawerguard_{datetime.now():%Y%m%d_%H%M%S}.db"
    dest = sqlite3.connect(BACKUP_DIR / name)
    try:
        conn.backup(dest)
    finally:
        dest.close()
    keep = keep or int(os.environ.get("BACKUP_KEEP", "14"))
    files = sorted((p for p in BACKUP_DIR.iterdir() if BACKUP_RE.match(p.name)), key=lambda p: p.name, reverse=True)
    for old in files[keep:]:
        old.unlink(missing_ok=True)
    return {"name": name, "size": (BACKUP_DIR / name).stat().st_size}


def list_backups() -> list[dict]:
    if not BACKUP_DIR.exists():
        return []
    return [{"name": p.name, "size": p.stat().st_size, "created": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")}
            for p in sorted(BACKUP_DIR.iterdir(), key=lambda p: p.name, reverse=True) if BACKUP_RE.match(p.name)]


def backup_path(name: str):
    """Resolve a backup file name safely (no path traversal: strict pattern + same directory)."""
    if not BACKUP_RE.match(name or ""):
        return None
    p = (BACKUP_DIR / name).resolve()
    if p.parent != BACKUP_DIR.resolve() or not p.exists():
        return None
    return p


def retention(conn, days: int, dry_run: bool = True) -> dict:
    """Delete raw transactions / cash-ups older than N days. Alerts, cases and evidence are kept,
    as are transactions that belong to an alert inside a case (needed for the case timeline)."""
    if days < 30:
        raise ValueError("Keep at least 30 days of data")
    cutoff = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%dT00:00:00")
    keep = "NOT EXISTS (SELECT 1 FROM alerts a WHERE a.store=t.store AND a.txn_id=t.id AND a.case_id IS NOT NULL)"
    counts = {
        "transactions": conn.execute(f"SELECT COUNT(*) n FROM transactions t WHERE ts < ? AND {keep}", (cutoff,)).fetchone()["n"],
        "shifts": conn.execute("SELECT COUNT(*) n FROM shifts WHERE start_ts < ?", (cutoff,)).fetchone()["n"],
        "ai_scores": conn.execute("SELECT COUNT(*) n FROM shift_anomaly WHERE day < ?", (cutoff[:10],)).fetchone()["n"],
        "timeclock": conn.execute("SELECT COUNT(*) n FROM timeclock WHERE clock_in < ?", (cutoff,)).fetchone()["n"],
    }
    if not dry_run:
        conn.execute(f"DELETE FROM transactions WHERE rowid IN (SELECT t.rowid FROM transactions t WHERE ts < ? AND {keep})", (cutoff,))
        conn.execute("DELETE FROM shifts WHERE start_ts < ?", (cutoff,))
        conn.execute("DELETE FROM shift_anomaly WHERE day < ?", (cutoff[:10],))
        conn.execute("DELETE FROM timeclock WHERE clock_in < ?", (cutoff,))
        conn.commit()
        conn.execute("VACUUM")
    return {"cutoff": cutoff[:10], "dry_run": dry_run, "would_delete" if dry_run else "deleted": counts}


def data_health(conn, stores: list[str]) -> list[dict]:
    stale_h = float(os.environ.get("DATA_STALE_HOURS", "36"))
    out = []
    for sid in stores:
        st = conn.execute("SELECT * FROM stores WHERE id=?", (sid,)).fetchone()
        if not st:
            continue
        last_ts = conn.execute("SELECT MAX(ts) m, MIN(ts) f, COUNT(*) n FROM transactions WHERE store=?", (sid,)).fetchone()
        imp = rows(conn.execute("SELECT * FROM import_log WHERE store=? ORDER BY id DESC LIMIT 10", (sid,)))
        last_import = imp[0]["created_at"] if imp else None
        daily = {r["d"]: r["n"] for r in conn.execute(
            "SELECT substr(ts,1,10) d, COUNT(*) n FROM transactions WHERE store=? GROUP BY d ORDER BY d DESC LIMIT 60", (sid,))}
        gaps = []
        if last_ts["f"]:
            d, end = datetime.fromisoformat(last_ts["f"][:10]), datetime.fromisoformat(last_ts["m"][:10])
            while d <= end:
                if d.strftime("%Y-%m-%d") not in daily and (end - d).days < 60:
                    gaps.append(d.strftime("%Y-%m-%d"))
                d += timedelta(days=1)
        shifts = conn.execute("""SELECT COUNT(*) n, SUM(counted_cash IS NULL AND expected_cash IS NOT NULL) not_counted,
                                 MAX(start_ts) last FROM shifts WHERE store=?""", (sid,)).fetchone()
        age_h = None
        if last_import:
            age_h = (datetime.now(timezone.utc).replace(tzinfo=None) - datetime.fromisoformat(last_import)).total_seconds() / 3600
        issues = []
        if not last_ts["n"]:
            status = "no data"
            issues.append("No transactions imported yet")
        else:
            status = "ok"
            if age_h is not None and age_h > stale_h:
                status = "stale"
                issues.append(f"No new data for {age_h:.0f} hours: check the export or inbox folder")
            if gaps:
                issues.append(f"{len(gaps)} day(s) with no transactions: {', '.join(gaps[-5:])}")
            if not shifts["n"]:
                issues.append("No cash-up (shift) data: shortage detections can't run")
            if shifts["not_counted"]:
                issues.append(f"{shifts['not_counted']} shift(s) closed without a cash count")
            errs = sum(len(json.loads(i["errors"] or "[]")) for i in imp[:5])
            if errs:
                issues.append(f"{errs} row(s) rejected in the last imports (bad dates/columns)")
            if gaps or (shifts["n"] == 0) or errs:
                status = "warning" if status == "ok" else status
        out.append({"store": sid, "name": st["name"], "status": status, "issues": issues, "transactions": last_ts["n"],
                    "first_ts": last_ts["f"], "last_ts": last_ts["m"], "last_import": last_import,
                    "hours_since_import": None if age_h is None else round(age_h, 1), "shifts": shifts["n"],
                    "daily": [{"date": d, "n": n} for d, n in sorted(daily.items())[-30:]],
                    "imports": [{k: i[k] for k in ("filename", "kind", "rows_read", "rows_added", "created_at")} for i in imp[:5]]})
    return out
