"""Smart AI detection.

1. Shift anomaly score (0-100). Each cashier-day is turned into a behaviour
   profile (No-Sales, voids, refunds, discounts, cancels, cash share, drawer
   shortage, paid-outs). The profile is compared with
     a) the cashier's OWN normal days  (robust median / MAD baseline), and
     b) the whole team's normal days   (same store)
   and the result is combined into one score, with the drivers explained in
   plain English.

2. Behaviour change. Compares the last N days with everything before, to catch
   a cashier who *started* stealing recently. Uses a two-proportion z-test.

3. Case summary. A plain-English write-up of why a cashier is flagged and what
   to check next. It is built from the data, and optionally polished by Claude
   when ANTHROPIC_API_KEY is set (only aggregated numbers are sent, no receipts).

Pure Python: no numpy or scikit-learn, so it installs anywhere.
"""
import json
import math
import os
import statistics
import urllib.request
from collections import defaultdict
from datetime import datetime, timedelta

from .rules import alert

FEATURES = {
    # key: (label, direction, scale floor, unit)
    "no_sale_rate": ("No-Sale drawer opens", +1, 2.5, "per 100 sales"),
    "void_rate": ("voids", +1, 2.5, "per 100 sales"),
    "refund_rate": ("refunds", +1, 2.0, "per 100 sales"),
    "refund_pct": ("refund value", +1, 2.0, "% of sales"),
    "discount_pct": ("discounts / comps", +1, 2.5, "% of sales"),
    "cancel_rate": ("cancelled orders", +1, 2.5, "per 100 sales"),
    "cash_ratio": ("cash share of sales", -1, 8.0, "% of sales"),
    "short": ("drawer shortage", +1, 12.0, "$"),
    "paid_out": ("cash paid out", +1, 25.0, "$"),
}


def day_profiles(ctx) -> dict:
    """{(cashier, day): feature dict} from a rules.Context."""
    acc = defaultdict(lambda: defaultdict(float))
    for t in ctx.txns:
        d = acc[(t["cashier"], t["ts"][:10])]
        typ = t["txn_type"]
        d[f"n_{typ}"] += 1
        d[f"v_{typ}"] += t["amount"]
        if typ == "sale":
            d["v_disc"] += t["discount_amount"]
            if t["payment_method"] == "cash":
                d["v_cash"] += t["amount"]
    for s in ctx.shifts:
        if s.get("expected_cash") is not None and s.get("counted_cash") is not None:
            acc[(s["cashier"], s["start_ts"][:10])]["short"] += max(0.0, s["expected_cash"] - s["counted_cash"])
    out = {}
    for key, d in acc.items():
        n = d["n_sale"]
        if n <= 0:
            continue
        v = max(d["v_sale"], 1.0)
        out[key] = {
            "sales": n,
            "no_sale_rate": d["n_no_sale"] / n * 100, "void_rate": d["n_void"] / n * 100,
            "refund_rate": d["n_refund"] / n * 100, "refund_pct": d["v_refund"] / v * 100,
            "discount_pct": (d["v_disc"] + d["v_discount"]) / v * 100, "cancel_rate": d["n_cancel"] / n * 100,
            "cash_ratio": d["v_cash"] / v * 100, "short": d["short"], "paid_out": d["v_paid_out"],
        }
    return out


def _robust(vals: list[float], floor: float) -> tuple[float, float]:
    med = statistics.median(vals)
    mad = statistics.median([abs(x - med) for x in vals]) * 1.4826
    return med, max(mad, floor)


def score_days(profiles: dict, cfg: dict) -> list[dict]:
    by_cashier = defaultdict(list)
    for (c, day), f in profiles.items():
        by_cashier[c].append((day, f))
    results = []
    for cashier, days in by_cashier.items():
        team = [f for (c, _), f in profiles.items() if c != cashier and f["sales"] >= cfg["min_sales"]]
        for day, f in days:
            if f["sales"] < cfg["min_sales"]:
                continue
            own = [g for d2, g in days if d2 != day and g["sales"] >= cfg["min_sales"]]
            parts, drivers = [], []
            for k, (label, direction, floor, unit) in FEATURES.items():
                zs = []
                if len(own) >= cfg["min_history_days"]:
                    med_s, sc_s = _robust([g[k] for g in own], floor)
                    zs.append(("self", direction * (f[k] - med_s) / sc_s, med_s))
                if len(team) >= 10:
                    med_t, sc_t = _robust([g[k] for g in team], floor)
                    zs.append(("team", direction * (f[k] - med_t) / sc_t, med_t))
                if not zs:
                    continue
                a = sum(max(0.0, z) for _, z, _ in zs) / len(zs)
                parts.append(a)
                if a >= 1.5:
                    usual = next((m for src, _, m in zs if src == "self"), zs[0][2])
                    drivers.append({"feature": k, "label": label, "value": round(f[k], 1), "usual": round(usual, 1),
                                    "unit": unit, "weight": round(a, 2)})
            if not parts:
                continue
            norm = math.sqrt(sum(a * a for a in parts))
            score = round(100 * (1 - math.exp(-norm / 4.5)), 1)
            drivers.sort(key=lambda x: -x["weight"])
            results.append({"cashier": cashier, "day": day, "score": score, "drivers": drivers[:4], "sales": int(f["sales"])})
    return results


def describe_driver(d: dict) -> str:
    unit = d["unit"]
    if unit == "$":
        return f"{d['label']} ${d['value']:,.0f} (usually ${d['usual']:,.0f})"
    return f"{d['label']} {d['value']:.1f} {unit} (usually {d['usual']:.1f})"


def rule_ai_anomaly(ctx, cfg, store: str, conn=None) -> list[dict]:
    scored = score_days(day_profiles(ctx), cfg)
    if conn is not None:
        conn.execute("DELETE FROM shift_anomaly WHERE store=?", (store,))
        conn.executemany("INSERT INTO shift_anomaly(store, cashier, day, score, drivers) VALUES(?,?,?,?,?)",
                         [(store, r["cashier"], r["day"], r["score"], json.dumps(r["drivers"])) for r in scored])
        conn.commit()
    out = []
    for r in scored:
        if r["score"] >= cfg["min_score"] and r["drivers"]:
            why = "; ".join(describe_driver(d) for d in r["drivers"][:3])
            sev = min(5, cfg["severity"] + (1 if r["score"] >= 93 else 0))
            out.append(alert("ai_anomaly", cfg, fp=f"{r['cashier']}:{r['day']}", cashier=r["cashier"], ts=f"{r['day']}T23:59:00",
                             severity=sev, title=f"AI: {r['cashier']}'s shift on {r['day']} looks unusual (score {r['score']:.0f}) — {why}",
                             score=r["score"], drivers=[describe_driver(d) for d in r["drivers"]], sales=r["sales"]))
    return out


CHANGE_METRICS = {
    "no_sale": ("No-Sale drawer opens", "no_sale"),
    "void": ("voids", "void"),
    "refund": ("refunds", "refund"),
    "cancel": ("cancelled orders", "cancel"),
    "discount": ("discounted sales", None),
}


def rule_behavior_change(ctx, cfg) -> list[dict]:
    if not ctx.txns:
        return []
    end = ctx.txns[-1]["_dt"]
    cut = end - timedelta(days=cfg["recent_days"])
    week = end.strftime("%G-W%V")
    stats = defaultdict(lambda: {"recent": defaultdict(int), "prior": defaultdict(int)})
    for t in ctx.txns:
        bucket = stats[t["cashier"]]["recent" if t["_dt"] >= cut else "prior"]
        typ = t["txn_type"]
        bucket[typ] += 1
        if typ == "sale":
            if t["discount_amount"] > 0:
                bucket["discount_sale"] += 1
            if t["payment_method"] == "cash":
                bucket["cash_sale"] += 1
    out = []
    for cashier, s in stats.items():
        r, p = s["recent"], s["prior"]
        n1, n0 = r["sale"], p["sale"]
        if n1 < 30 or n0 < 60:
            continue
        checks = [(k, label, r[typ] if typ else r["discount_sale"], p[typ] if typ else p["discount_sale"], +1)
                  for k, (label, typ) in CHANGE_METRICS.items()]
        checks.append(("cash", "cash share of sales", r["cash_sale"], p["cash_sale"], -1))
        for key, label, k1, k0, direction in checks:
            r1, r0 = k1 / n1, k0 / n0
            pool = (k1 + k0) / (n1 + n0)
            if pool <= 0 or pool >= 1:
                continue
            z = (r1 - r0) / math.sqrt(pool * (1 - pool) * (1 / n1 + 1 / n0))
            if direction > 0:
                hit = z >= cfg["z_threshold"] and r1 >= cfg["min_ratio"] * max(r0, 0.005) and k1 >= 4
            else:
                hit = z <= -cfg["z_threshold"] and r0 - r1 >= 0.08
            if hit:
                unit = "% of sales" if key == "cash" else "per 100 sales"
                out.append(alert("behavior_change", cfg, fp=f"{cashier}:{key}:{week}", cashier=cashier, ts=end.isoformat(),
                                 title=f"AI: {cashier}'s {label} changed — {r1 * 100:.1f} {unit} in the last {cfg['recent_days']} days vs {r0 * 100:.1f} before",
                                 metric=key, recent=round(r1 * 100, 2), before=round(r0 * 100, 2), z=round(z, 2),
                                 recent_sales=n1, prior_sales=n0))
    return out


# ------------------------------------------------------------------ plain-English case summary

RULE_PLAIN = {
    "no_sale_after_cash": "opened the drawer with No Sale right after cash sales",
    "no_sale_excess": "opened the drawer with No Sale far more often than allowed",
    "no_sale_isolated": "opened the drawer when no customer was buying",
    "post_payment_void": "voided items after the customer had already paid cash",
    "unmatched_refund": "gave refunds that have no original sale on record",
    "refund_exceeds_original": "refunded more than the customer originally paid",
    "cash_refund_on_card_sale": "refunded card payments in cash",
    "refund_own_sale_quick": "refunded their own sales minutes after ringing them",
    "round_amount_refund": "gave round-number refunds (e.g. $20.00)",
    "excess_discount": "gave large discounts or free items",
    "unapproved_override": "did refunds/voids/paid-outs without manager approval",
    "self_approved": "approved their own overrides",
    "cancel_after_kitchen": "cancelled orders after the food was already made",
    "paid_out": "took cash out of the drawer as paid-outs",
    "off_hours": "used the till outside business hours",
    "cash_shortage": "had drawers come up short at cash-up",
    "repeat_shortage": "had repeated drawer shortages",
    "peer_outlier": "behaves very differently from the rest of the team",
    "low_cash_ratio": "records far fewer cash sales than colleagues",
    "ai_anomaly": "had shifts the AI model rated as highly unusual",
    "behavior_change": "changed behaviour suddenly in the last week",
}

NEXT_STEPS = {
    "no_sale_after_cash": "Watch CCTV at the No-Sale times listed: look for cash going to a pocket, apron or tip jar.",
    "no_sale_excess": "Limit No-Sale to managers in SplitPOS, or require a reason code.",
    "unmatched_refund": "Phone a few 'refunded' customers or check CCTV: was a customer actually at the counter?",
    "cash_refund_on_card_sale": "Set SplitPOS so card sales can only be refunded to the card.",
    "post_payment_void": "Require manager PIN for voids after payment.",
    "excess_discount": "Require manager approval for discounts over your limit; check who received them on CCTV.",
    "cancel_after_kitchen": "Compare kitchen tickets with CCTV: was the food handed to a customer?",
    "cash_shortage": "Do a surprise mid-shift drawer count; use one cashier per drawer.",
    "repeat_shortage": "Do a surprise mid-shift drawer count; use one cashier per drawer.",
    "self_approved": "Remove override permission from this cashier's SplitPOS account.",
    "low_cash_ratio": "Watch cash customers on CCTV and check each gets a printed receipt.",
}


def build_summary(score: dict, alerts: list[dict], anomalies: list[dict], shifts: list[dict]) -> dict:
    name = score["cashier"]
    active = [a for a in alerts if a["status"] != "dismissed"]
    by_rule = defaultdict(list)
    for a in active:
        by_rule[a["rule"]].append(a)
    ranked = sorted(by_rule.items(), key=lambda kv: -sum(x["severity"] ** 2 for x in kv[1]))
    lvl = score["level"]
    head = {"high": f"{name} is HIGH risk ({score['score']}/100). This pattern is consistent with theft and should be investigated now.",
            "medium": f"{name} is MEDIUM risk ({score['score']}/100). Worth a closer look.",
            "low": f"{name} is LOW risk ({score['score']}/100). Nothing stands out."}[lvl]
    paras = []
    if ranked:
        bits = [f"{RULE_PLAIN.get(r, r)} ({len(v)}×)" for r, v in ranked[:4]]
        paras.append(f"In this period {name} " + ", ".join(bits[:-1]) + (" and " if len(bits) > 1 else "") + bits[-1] + ".")
    z = score.get("z", {})
    peer = []
    m = score.get("metrics", {})
    for k, lab in (("no_sale_rate", "No-Sale opens"), ("void_rate", "voids"), ("refund_rate", "refunds"),
                   ("discount_pct", "discounts"), ("cancel_rate", "cancelled orders")):
        if z.get(k, 0) >= 2:
            how = "far above" if z[k] >= 5 else f"about {z[k]:.0f} standard deviations above"
            peer.append(f"{lab} ({m.get(k, 0):.1f} per 100 sales, {how} the team)")
    if z.get("cash_ratio", 0) <= -1.8:
        peer.append(f"a low cash share ({m.get('cash_ratio', 0):.0f}% of sales)")
    if peer:
        paras.append("Compared with colleagues, " + name + " stands out for " + "; ".join(peer) + ".")
    short = [s for s in shifts if s.get("diff") is not None and s["diff"] < -5]
    if short:
        paras.append(f"{len(short)} of {len(shifts)} cash-ups were short, by ${-sum(s['diff'] for s in short):,.2f} in total.")
    hi = sorted([a for a in anomalies if a["score"] >= 80], key=lambda x: -x["score"])[:3]
    if hi:
        paras.append("The AI model flagged these days as most unusual: " +
                     "; ".join(f"{a['day']} (score {a['score']:.0f}: {', '.join(d['label'] for d in a['drivers'][:2])})" for a in hi) + ".")
    exposure = score.get("amount_at_risk", 0)
    if exposure:
        paras.append(f"Money linked to these alerts: about ${exposure:,.2f}. Treat this as an upper bound for review, not a proven loss.")
    steps = []
    for r, _v in ranked:
        if r in NEXT_STEPS and NEXT_STEPS[r] not in steps:
            steps.append(NEXT_STEPS[r])
    top = sorted(sorted([a for a in active if a.get("txn_id")], key=lambda a: a["ts"] or "", reverse=True),
                 key=lambda a: -a["severity"])[:3]
    if top:
        steps.insert(0, "Start with CCTV at: " + "; ".join(f"{(a['ts'] or '')[:16].replace('T', ' ')} on {a.get('register') or 'the till'}" for a in top) + ".")
    if lvl != "low":
        steps.append("Keep everything factual and talk to HR before confronting the employee.")
    return {"headline": head, "paragraphs": paras or [f"No suspicious activity found for {name}."],
            "next_steps": steps[:6], "source": "built-in"}


def polish_with_claude(summary: dict, facts: dict) -> dict:
    """Optional: rewrite the summary with Claude. Only aggregated facts are sent."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key:
        return summary
    prompt = ("You are a loss-prevention analyst for a small restaurant. Rewrite this cashier risk summary for the owner "
              "in clear, calm plain English (max 180 words, then up to 5 bullet next steps). Do not invent facts; do not "
              "claim theft is proven.\n\nFACTS:\n" + json.dumps(facts, default=str)[:12000] +
              "\n\nDRAFT:\n" + json.dumps(summary)[:6000] +
              '\n\nReturn JSON only: {"headline": str, "paragraphs": [str], "next_steps": [str]}')
    body = json.dumps({"model": os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": 900,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            text = json.loads(r.read())["content"][0]["text"]
        data = json.loads(text[text.index("{"): text.rindex("}") + 1])
        return {**summary, **{k: data[k] for k in ("headline", "paragraphs", "next_steps") if k in data}, "source": "claude"}
    except Exception as e:  # never break the dashboard because of the AI call
        return {**summary, "ai_error": str(e)[:200]}


def anomaly_series(conn, stores: list[str], cashier: str, since: str | None) -> list[dict]:
    q = f"SELECT day, MAX(score) score, drivers FROM shift_anomaly WHERE cashier=? AND store IN ({','.join('?' * len(stores))})"
    p = [cashier, *stores]
    if since:
        q += " AND day >= ?"
        p.append(since[:10])
    q += " GROUP BY day ORDER BY day"
    return [{"day": r["day"], "score": r["score"], "drivers": json.loads(r["drivers"])} for r in conn.execute(q, p)]


_ = datetime  # keep import for type hints in older Pythons
