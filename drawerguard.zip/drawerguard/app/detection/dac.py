"""Detection-as-code.

Every detection lives in its own TOML file under detections/ (one file = metadata,
default thresholds and unit tests). The app's default rule configuration and the
detection catalog are both built from these files, so a pull request that changes
a threshold or adds a detection is reviewed, versioned and tested like code:

    python scripts/dac.py            validate + run every detection's tests
    python scripts/dac.py --report   also write docs/DETECTION_TESTS.md

Test events use a compact, readable line format:

    "d0 10:00:15 sale 12.50 cash by=Ana till=T1 order=A1 id=s1"
     │  │        │    │     │    └─ key=value: by, till, order, orig, appr, disc, kitchen, id, note
     │  │        │    │     └─ payment (cash | card)            (optional)
     │  │        │    └─ amount                                  (optional)
     │  │        └─ type: sale refund void no_sale discount paid_out cancel
     │  └─ time HH:MM[:SS]
     └─ day offset from the test's base date (Monday 2026-01-05)

    "*5/10m d0 10:00 no_sale by=Ana"      repeat 5 times, 10 minutes apart (s, m, h, d)
    shifts  = ["d0 07:00-15:00 by=Ana till=T1 expected=300 counted=270"]   (counted=none: not counted)
    punches = ["d0 06:55-15:05 by=Ana device=Clock1 method=pin edited_by=Sam added=30 rate=16"]

Data-hungry detections (peer comparison, AI/ML, collusion) are tested against the
labelled demo dataset instead: dataset = "demo", expect_cashiers / forbid_cashiers.
"""
import tomllib
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
DETECTIONS_DIR = ROOT / "detections"
BASE_DAY = datetime(2026, 1, 5)
REQUIRED = ("id", "key", "name", "status", "version", "scheme", "source", "logic", "false_positives", "triage", "config")
STATUSES = ("stable", "experimental", "deprecated")
TXN_TYPES = ("sale", "refund", "void", "no_sale", "discount", "paid_out", "cancel")


class DacError(ValueError):
    pass


def load_file(path: Path) -> dict:
    with open(path, "rb") as f:
        d = tomllib.load(f)
    d["_file"] = path.name
    return d


def load_all(directory: Path = DETECTIONS_DIR) -> list[dict]:
    if not directory.exists():
        raise DacError(f"Detection folder not found: {directory}")
    items = [load_file(p) for p in sorted(directory.glob("*.toml"))]
    return sorted(items, key=lambda d: d.get("id", ""))


def validate(items: list[dict], implemented: set[str] | None = None, schemes: set[str] | None = None) -> list[str]:
    """Schema and consistency checks. Returns a list of problems (empty = valid)."""
    errors, ids, keys = [], {}, {}
    for d in items:
        f = d.get("_file", "?")
        for r in REQUIRED:
            if r not in d:
                errors.append(f"{f}: missing '{r}'")
        if d.get("id", "")[:3] not in ("DG-", "CU-") or not d.get("id", "")[3:].isdigit() or len(d.get("id", "")) != 6:
            errors.append(f"{f}: id must look like DG-001")
        if d.get("status") not in STATUSES:
            errors.append(f"{f}: status must be one of {STATUSES}")
        if d.get("id") and not f.startswith(d["id"]):
            errors.append(f"{f}: file name must start with the id {d['id']}")
        cfg = d.get("config", {})
        if not isinstance(cfg.get("enabled"), bool):
            errors.append(f"{f}: config.enabled must be true/false")
        if not isinstance(cfg.get("severity"), int) or not 1 <= cfg.get("severity", 0) <= 5:
            errors.append(f"{f}: config.severity must be 1-5")
        if schemes is not None and d.get("scheme") not in schemes:
            errors.append(f"{f}: unknown scheme '{d.get('scheme')}'")
        if implemented is not None and d.get("key") not in implemented:
            errors.append(f"{f}: no rule implementation for key '{d.get('key')}'")
        for k, seen in ((d.get("id"), ids), (d.get("key"), keys)):
            if k in seen:
                errors.append(f"{f}: duplicate {k} (also in {seen[k]})")
            seen[k] = f
        if not d.get("tests"):
            errors.append(f"{f}: no tests")
        for i, t in enumerate(d.get("tests", []), 1):
            if "dataset" in t:
                if not t.get("expect_cashiers") and not t.get("forbid_cashiers"):
                    errors.append(f"{f}: test {i} needs expect_cashiers or forbid_cashiers")
            elif "expect" not in t or "events" not in t:
                errors.append(f"{f}: test {i} needs 'expect' and 'events'")
            else:
                for c in t.get("canaries", []):
                    if ":" not in c or c.split(":", 1)[0] not in ("approver", "employee", "order", "till", "note"):
                        errors.append(f"{f}: test {i}: canary must look like kind:value")
                try:
                    parse_events(t["events"])
                    parse_shifts(t.get("shifts", []))
                    parse_punches(t.get("punches", []))
                except (DacError, ValueError, IndexError) as e:
                    errors.append(f"{f}: test {i}: {e}")
    return errors


# ------------------------------------------------------------------ event DSL

_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400}


def _expand(lines: list[str]) -> list[tuple[int, list[str], int]]:
    """Expand '*N/STEP ...' repeats → (repeat index, tokens, offset seconds)."""
    out = []
    for line in lines:
        tok = line.split()
        n, step = 1, 0
        if tok and tok[0].startswith("*"):
            spec = tok.pop(0)[1:]
            cnt, _, st = spec.partition("/")
            n = int(cnt)
            step = int(st[:-1]) * _UNITS[st[-1]] if st else 0
        for i in range(n):
            out.append((i, list(tok), i * step))
    return out


def _when(day: str, clock: str, offset: int = 0) -> datetime:
    if not day.startswith("d"):
        raise DacError(f"expected a day like d0, got '{day}'")
    parts = [int(x) for x in clock.split(":")]
    t = BASE_DAY + timedelta(days=int(day[1:]), hours=parts[0], minutes=parts[1], seconds=parts[2] if len(parts) > 2 else 0)
    return t + timedelta(seconds=offset)


def _kv(tokens):
    pos, kv = [], {}
    for t in tokens:
        if "=" in t:
            k, v = t.split("=", 1)
            kv[k] = v.replace("_", " ") if k in ("note", "by", "appr", "till") else v
        else:
            pos.append(t)
    return pos, kv


def parse_events(lines: list[str]) -> list[dict]:
    out = []
    for n, (i, tok, off) in enumerate(_expand(lines)):
        pos, kv = _kv(tok)
        if len(pos) < 3:
            raise DacError(f"event needs day, time and type: {' '.join(tok)}")
        day, clock, typ = pos[:3]
        if typ not in TXN_TYPES:
            raise DacError(f"unknown type '{typ}'")
        amount = float(pos[3]) if len(pos) > 3 else 0.0
        pay = pos[4] if len(pos) > 4 else ""
        rid = kv.get("id", f"e{n}")
        if i and "id" in kv:
            rid = f"{rid}-{i}"
        out.append({"store": "test", "id": rid, "ts": _when(day, clock, off).isoformat(), "cashier": kv.get("by", "Ana"),
                    "register": kv.get("till", "T1"), "txn_type": typ, "amount": amount, "payment_method": pay,
                    "order_id": kv.get("order", "") + (f"-{i}" if i and "order" in kv else ""), "original_txn_id": kv.get("orig", ""),
                    "discount_amount": float(kv.get("disc", 0)), "approved_by": kv.get("appr", ""),
                    "sent_to_kitchen": int(kv.get("kitchen", 0)), "note": kv.get("note", "")})
    return out


def _span(day, rng, off):
    a, b = rng.split("-")
    start, end = _when(day, a, off), _when(day, b, off)
    if end < start:
        end += timedelta(days=1)
    return start.isoformat(), end.isoformat()


def parse_shifts(lines: list[str]) -> list[dict]:
    out = []
    for _i, tok, off in _expand(lines):
        pos, kv = _kv(tok)
        s, e = _span(pos[0], pos[1], off)
        counted = kv.get("counted", "none")
        out.append({"store": "test", "cashier": kv.get("by", "Ana"), "register": kv.get("till", "T1"), "start_ts": s, "end_ts": e,
                    "opening_float": float(kv.get("float", 0)), "expected_cash": float(kv["expected"]) if "expected" in kv else None,
                    "counted_cash": None if counted == "none" else float(counted)})
    return out


def parse_punches(lines: list[str]) -> list[dict]:
    out = []
    for _i, tok, off in _expand(lines):
        pos, kv = _kv(tok)
        s, e = _span(pos[0], pos[1], off)
        out.append({"store": "test", "employee": kv.get("by", "Ana"), "clock_in": s, "clock_out": e, "device": kv.get("device", "Clock1"),
                    "method": kv.get("method", "pin"), "edited_by": kv.get("edited_by", "").replace("_", " "), "edit_note": "",
                    "minutes_added": float(kv.get("added", 0)), "hourly_rate": float(kv["rate"]) if "rate" in kv else None})
    return out


# ------------------------------------------------------------------ test runner

_DATASETS: dict = {}


def _dataset(seed: int, store: str):
    """Labelled demo data, generated in memory and imported through the real importer."""
    key = (seed, store)
    if key not in _DATASETS:
        import sys
        import tempfile
        sys.path.insert(0, str(ROOT))
        from sample_data.generate_demo import Gen

        from ..db import connect, init_db
        from ..ingest.csv_importer import import_file
        from .engine import load_context
        tmp = Path(tempfile.mkdtemp())
        g = Gen(seed, store)
        g.run(datetime(2026, 11, 8), 45)
        g.write(tmp, store)
        conn = connect(":memory:")
        init_db(conn)
        for part in ("transactions", "cashup", "timeclock"):
            import_file(conn, (tmp / f"{store}_{part}.csv").read_bytes(), f"{part}.csv", store=store)
        _DATASETS[key] = load_context(conn, [store])
    return _DATASETS[key]


def run_test(det: dict, test: dict, base_rules: dict) -> dict:
    import copy

    from .engine import detect_store
    from .rules import Context
    rules = copy.deepcopy(base_rules)
    rules[det["key"]].update(det.get("config", {}))
    rules[det["key"]].update(test.get("config", {}))
    rules[det["key"]]["enabled"] = True
    if "dataset" in test:
        src = _dataset(test.get("seed", 7), test["store"])
        ctx = Context([dict(t) for t in src.txns], [dict(s) for s in src.shifts], [dict(p) for p in src.timeclock])
    else:
        ctx = Context(parse_events(test["events"]), parse_shifts(test.get("shifts", [])), parse_punches(test.get("punches", [])))
    ctx.canaries = [{"kind": c.split(":", 1)[0], "value": c.split(":", 1)[1], "note": ""} for c in test.get("canaries", [])]
    alerts = [a for a in detect_store(None, "test", rules, [], persist_ai=False, ctx=ctx) if a["rule"] == det["key"]]
    if "dataset" in test:
        who = {a["cashier"] for a in alerts}
        missing = [c for c in test.get("expect_cashiers", []) if c not in who]
        wrong = [c for c in test.get("forbid_cashiers", []) if c in who]
        ok = not missing and not wrong
        detail = f"{len(alerts)} alerts on {sorted(who)}" + (f"; missing {missing}" if missing else "") + (f"; should not flag {wrong}" if wrong else "")
    else:
        exp = test["expect"]
        ok = len(alerts) == exp
        detail = f"expected {exp}, got {len(alerts)}" + (f": {alerts[0]['title']}" if alerts and not ok else "")
    return {"name": test.get("name", ""), "kind": "dataset" if "dataset" in test else "unit",
            "polarity": "positive" if (test.get("expect", 1) or test.get("expect_cashiers")) else "negative",
            "passed": ok, "detail": detail}


def run_all(items: list[dict] | None = None) -> dict:
    from ..config import DEFAULT_RULES
    items = items or load_all()
    results = []
    for d in items:
        tests = [run_test(d, t, DEFAULT_RULES) for t in d.get("tests", [])]
        results.append({"id": d["id"], "key": d["key"], "name": d["name"], "status": d["status"], "version": d.get("version"),
                        "file": d.get("_file"), "tests": tests, "passed": all(t["passed"] for t in tests),
                        "positive": sum(1 for t in tests if t["polarity"] == "positive"),
                        "negative": sum(1 for t in tests if t["polarity"] == "negative")})
    n = sum(len(r["tests"]) for r in results)
    ok = sum(1 for r in results for t in r["tests"] if t["passed"])
    return {"detections": len(results), "tests": n, "passed": ok, "failed": n - ok,
            "with_positive_and_negative": sum(1 for r in results if r["positive"] and r["negative"]), "results": results}
