"""Deception for the till: canary values (honeytokens) and the watchlist.

A canary is a value nobody legitimately uses: a fake manager override code left
on a sticky note under the till, a decommissioned till name, a table number that
doesn't exist, a reason code that is never taught, or a staff login that belongs
to nobody. Any transaction (or punch) that uses one is, by construction, someone
probing the system: DG-031 raises a critical alert with no false-positive tuning
needed. This is the honeytoken idea from network security applied to a POS.

The watchlist is the containment side: cashiers under investigation get every
new alert one severity higher until the watch expires.
"""
from collections import defaultdict
from datetime import date

from .rules import alert

CANARY_KINDS = {"approver": "approved_by", "employee": "cashier", "order": "order_id", "till": "register", "note": "note"}
KIND_LABEL = {"approver": "manager override code", "employee": "staff login", "order": "order / table number",
              "till": "decommissioned till", "note": "reason code"}


def load_canaries(conn, store: str) -> list[dict]:
    return [dict(r) for r in conn.execute("SELECT * FROM canaries WHERE enabled=1 AND (store='' OR store=?)", (store,))]


def load_watch(conn, store: str) -> dict:
    today = date.today().isoformat()
    return {r["cashier"]: dict(r) for r in conn.execute(
        "SELECT * FROM watchlist WHERE store=? AND (until IS NULL OR until='' OR until>=?)", (store, today))}


def rule_canary(ctx, cfg):
    canaries = getattr(ctx, "canaries", None) or []
    if not canaries:
        return []
    by_kind = defaultdict(dict)
    for c in canaries:
        by_kind[c["kind"]][c["value"].strip().lower()] = c
    out = []
    for t in ctx.txns:
        for kind, field in CANARY_KINDS.items():
            vals = by_kind.get(kind)
            v = str(t.get(field) or "").strip().lower()
            if not vals or not v:
                continue
            hit = next((c for k, c in vals.items() if k in v), None) if kind == "note" else vals.get(v)
            if hit:
                out.append(alert("canary", cfg, fp=f"{t['id']}:{kind}", cashier=t["cashier"], register=t["register"], ts=t["ts"],
                                 txn_id=t["id"], amount=t["amount"],
                                 title=f"Canary tripped: the {KIND_LABEL[kind]} '{hit['value']}' was used on a "
                                       f"{t['txn_type'].replace('_', ' ')} by {t['cashier']}",
                                 canary=hit["value"], kind=kind, planted_note=hit.get("note", "")))
    emp = by_kind.get("employee", {})
    for p in getattr(ctx, "timeclock", []) or []:
        hit = emp.get(p["employee"].strip().lower())
        if hit:
            out.append(alert("canary", cfg, fp=f"punch:{p['employee']}:{p['clock_in']}", cashier=p["employee"], register=p.get("device"),
                             ts=p["clock_in"], title=f"Canary tripped: the canary staff login '{hit['value']}' clocked in on "
                                                     f"{p.get('device') or 'a time clock'}",
                             canary=hit["value"], kind="employee", planted_note=hit.get("note", "")))
    return out


def apply_watchlist(items: list[dict], watch: dict) -> int:
    """Raise the severity of alerts on watched cashiers (containment: tighter monitoring)."""
    import json
    n = 0
    for a in items:
        w = watch.get(a.get("cashier"))
        if not w:
            continue
        a["severity"] = min(5, a["severity"] + 1)
        try:
            d = json.loads(a.get("details") or "{}")
        except ValueError:
            d = {}
        d["watchlist"] = w["reason"]
        a["details"] = json.dumps(d, default=str)
        a["tags"] = ",".join(x for x in (a.get("tags") or "").split(",") + ["watchlist"] if x)
        n += 1
    return n


DECEPTION_RULE_FUNCS = {"canary": rule_canary}
