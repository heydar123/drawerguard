"""Export DrawerGuard detections as Sigma rules (https://sigmahq.io).

Sigma is the vendor-neutral format detection engineers use to share rules across
SIEMs. Simple, single-event detections map 1:1. Stateful ones (sequences, joins to the
original sale, statistics) can't be fully expressed in Sigma, so they are exported with
their primary selection plus the extra logic written in the description and the tag
`drawerguard.stateful`, which is honest about what a SIEM would need to add.
"""
import json
import uuid
from datetime import date

from ..config import DEFAULT_RULES
from .catalog import CATALOG, meta
from .custom import describe

LEVEL = {1: "informational", 2: "low", 3: "medium", 4: "high", 5: "critical"}
OVERRIDES = ["refund", "void", "paid_out", "discount"]

# primary selection, aggregation condition (optional), extra logic (optional)
SPEC = {
    "no_sale_excess": ({"txn_type": "no_sale"}, "selection | count() by cashier > {max_per_shift}", None),
    "no_sale_after_cash": ({"txn_type": "no_sale"}, None, "Preceded by a cash sale by the same cashier on the same register within {window_seconds}s."),
    "no_sale_isolated": ({"txn_type": "no_sale"}, None, "No sale or refund on the same register within ±{quiet_minutes} minutes."),
    "post_payment_void": ({"txn_type": "void", "amount|gte": "{min_amount}"}, None, "The same order already has a cash payment."),
    "unmatched_refund": ({"txn_type": "refund"}, None, "original_txn_id does not match any sale (and no sale on the same order)."),
    "refund_exceeds_original": ({"txn_type": "refund"}, None, "Refund amount is greater than the original sale amount."),
    "cash_refund_on_card_sale": ({"txn_type": "refund", "payment_method": "cash"}, None, "The original sale was paid by card."),
    "refund_own_sale_quick": ({"txn_type": "refund"}, None, "Original sale rung by the same cashier within {window_minutes} minutes."),
    "round_amount_refund": ({"txn_type": "refund", "amount|gte": "{min_amount}"}, None, "Amount is a whole multiple of 5."),
    "excess_discount": ({"txn_type": ["discount", "sale"], "discount_amount|gte": "{min_amount}"}, None, "Discount is more than {max_pct}% of the order."),
    "unapproved_override": ({"txn_type": OVERRIDES, "amount|gte": "{min_amount}", "approved_by": ""}, None, None),
    "self_approved": ({"approved_by|exists": True}, None, "approved_by equals cashier (field-to-field comparison)."),
    "cancel_after_kitchen": ({"txn_type": "cancel", "sent_to_kitchen": 1}, None, None),
    "paid_out": ({"txn_type": "paid_out", "amount|gte": "{min_amount}"}, None, None),
    "off_hours": ({"txn_type|exists": True}, None, "Event hour < {open_hour} or ≥ {close_hour} (store-specific opening hours)."),
    "cash_shortage": ({"record": "cashup"}, None, "counted_cash < expected_cash - {tolerance}."),
    "repeat_shortage": ({"record": "cashup"}, None, "{count}+ shortages for the same cashier within {days} days."),
    "missing_count": ({"record": "cashup", "counted_cash": None}, None, None),
    "peer_outlier": (None, None, "Monthly leave-one-out z-score of the cashier's rates against the team ≥ {z_threshold}."),
    "low_cash_ratio": (None, None, "Monthly cash share of sales with leave-one-out z ≤ {z_threshold}."),
    "approver_concentration": (None, None, "Binomial z-test on approver × cashier override counts against the median peer share; z ≥ {z_threshold}, share ≥ {min_share}."),
    "ai_anomaly": (None, None, "Robust (median/MAD) behavioural z-scores against own and team baselines; score ≥ {min_score}."),
    "behavior_change": (None, None, "Two-proportion z-test, last {recent_days} days against earlier history; z ≥ {z_threshold}."),
    "correlated_shift": (None, None, "Sigma correlation: {min_distinct}+ distinct DrawerGuard rules for the same cashier on the same day."),
}


def _fill(v, cfg):
    if isinstance(v, str) and v.startswith("{") and v.endswith("}") and v[1:-1] in cfg:
        return cfg[v[1:-1]]
    if isinstance(v, str):
        try:
            return v.format(**cfg)
        except (KeyError, IndexError, ValueError):
            return v
    return v


def _yaml(v, indent=0) -> str:
    pad = "  " * indent
    if isinstance(v, dict):
        out = []
        for k, x in v.items():
            if isinstance(x, (dict, list)) and x:
                out.append(f"{pad}{k}:\n{_yaml(x, indent + 1)}")
            else:
                out.append(f"{pad}{k}: {_scalar(x)}")
        return "\n".join(out)
    if isinstance(v, list):
        return "\n".join(f"{pad}- {_scalar(x)}" if not isinstance(x, (dict, list)) else f"{pad}-\n{_yaml(x, indent + 1)}" for x in v)
    return f"{pad}{_scalar(v)}"


def _scalar(x) -> str:
    if x is None:
        return "null"
    if isinstance(x, bool):
        return "true" if x else "false"
    if isinstance(x, (int, float)):
        return repr(x)
    if isinstance(x, (list, dict)) and not x:
        return "[]" if isinstance(x, list) else "{}"
    return json.dumps(str(x), ensure_ascii=False)        # JSON strings are valid YAML double-quoted scalars


def builtin_rule(key: str, cfg: dict) -> dict:
    m = meta(key)
    sel, cond, extra = SPEC.get(key, (None, None, None))
    desc = f"{cfg['label']}. {m.get('logic', '')}"
    tags = [f"acfe.{m['scheme']}", "drawerguard.builtin"]
    detection = {}
    if sel is None:
        detection = {"selection": {"txn_type|exists": True}, "condition": "selection"}
        tags.append("drawerguard.analytics")
        desc += " (Statistical analytic: export is a placeholder, the logic runs in DrawerGuard.)"
    else:
        detection = {"selection": {k: _fill(v, cfg) for k, v in sel.items()}, "condition": _fill(cond, cfg) if cond else "selection"}
        if cond:
            detection["timeframe"] = "1d"
    if extra:
        desc += " Additional logic: " + _fill(extra, cfg)
        tags.append("drawerguard.stateful")
    service = "splitpos_cashup" if sel and sel.get("record") == "cashup" else "splitpos"
    if sel and "record" in sel:
        detection["selection"].pop("record", None)
        if not detection["selection"]:
            detection["selection"] = {"expected_cash|exists": True}
    return {
        "title": cfg["label"], "id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"drawerguard/{key}")),
        "status": "experimental" if key in ("ai_anomaly", "behavior_change", "approver_concentration", "correlated_shift") else "stable",
        "description": desc, "references": ["https://github.com/YOUR_USERNAME/drawerguard/blob/main/docs/DETECTIONS.md"],
        "author": "DrawerGuard", "date": date.today().strftime("%Y/%m/%d"), "tags": tags,
        "logsource": {"product": "pos", "service": service}, "detection": detection,
        "falsepositives": [CATALOG.get(key, {}).get("fp") or "Unknown"], "level": LEVEL.get(cfg["severity"], "medium"),
        "custom": {"drawerguard_id": m["id"], "rule_key": key},
    }


SIGMA_OP = {">": "gt", ">=": "gte", "<": "lt", "<=": "lte", "contains": "contains"}


def custom_rule(r: dict) -> dict:
    d = r["definition"]
    sel, filt, n = {}, {}, 0
    extra_sel = {}
    for c in d["match"]:
        f, op, v = c["field"], c["op"], c["value"]
        if op in ("==", "in"):
            sel[f] = v
        elif op in SIGMA_OP:
            sel[f"{f}|{SIGMA_OP[op]}"] = v
        elif op == "between":
            sel[f"{f}|gte"] = v[0]
            n += 1
            extra_sel[f"selection_{n}"] = {f"{f}|lte": v[1]}
        elif op in ("!=", "not_in"):
            filt[f] = v
        elif op == "not_contains":
            filt[f"{f}|contains"] = v
        elif op == "is_empty":
            sel[f] = ""
        elif op == "not_empty":
            filt[f] = ""
    detection = {"selection": sel or {"txn_type|exists": True}, **extra_sel}
    cond = " and ".join(["selection", *extra_sel])
    if filt:
        detection["filter"] = filt
        cond += " and not filter"
    agg = d.get("aggregate")
    if agg:
        by = ", ".join(k for k in agg["by"] if k not in ("day", "hour"))
        if agg.get("count_gte"):
            cond = f"{cond} | count() by {by} >= {agg['count_gte']}"
        elif agg.get("sum_gte"):
            cond = f"{cond} | sum(amount) by {by} >= {agg['sum_gte']}"
        detection["timeframe"] = "1d"
    detection["condition"] = cond
    m = meta(f"custom:{r['id']}")
    return {
        "title": r["name"], "id": str(uuid.uuid5(uuid.NAMESPACE_URL, f"drawerguard/custom/{r['id']}/{r['name']}")),
        "status": "experimental", "description": (r.get("description") or "") + " " + describe(d),
        "author": r.get("created_by") or "DrawerGuard", "date": date.today().strftime("%Y/%m/%d"),
        "tags": ["drawerguard.custom"] + (["drawerguard.derived_fields"] if any(c["field"] in ("hour", "weekday") for c in d["match"]) else []),
        "logsource": {"product": "pos", "service": "splitpos"}, "detection": detection,
        "falsepositives": ["Unknown"], "level": LEVEL.get(int(r.get("severity") or 3), "medium"),
        "custom": {"drawerguard_id": m["id"]},
    }


def export(rules_cfg: dict, custom: list[dict]) -> str:
    docs = [builtin_rule(k, rules_cfg[k]) for k in sorted(CATALOG, key=lambda x: CATALOG[x]["id"]) if k in rules_cfg]
    docs += [custom_rule(r) for r in custom]
    header = (f"# DrawerGuard detections as Sigma rules. Generated {date.today()}.\n"
              "# Field names follow DrawerGuard's normalised schema (store, ts, cashier, register, txn_type, amount,\n"
              "# payment_method, order_id, original_txn_id, discount_amount, approved_by, sent_to_kitchen, note).\n")
    return header + "\n---\n".join(_yaml(d) + "\n" for d in docs)


_ = DEFAULT_RULES
