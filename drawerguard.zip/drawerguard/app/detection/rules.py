"""Fraud-detection rules.

Each rule is a function (ctx, cfg) -> list[Alert dict]. The engine runs every
enabled rule over all stored data; alerts are de-duplicated by `fingerprint`, so
running detection again never creates duplicates and never touches alerts the
owner has already reviewed.
"""
import json
import math
import statistics
from bisect import bisect_left, bisect_right
from collections import defaultdict
from datetime import datetime, timedelta


def _dt(s: str) -> datetime:
    return datetime.fromisoformat(s)


def _money(x: float) -> str:
    return f"${x:,.2f}"


def alert(rule, cfg, *, fp, title, cashier=None, register=None, ts=None, txn_id=None, amount=0.0, severity=None, **details):
    return {
        "fingerprint": f"{rule}:{fp}",
        "rule": rule,
        "severity": int(severity if severity is not None else cfg["severity"]),
        "cashier": cashier,
        "register": register,
        "ts": ts,
        "txn_id": txn_id,
        "amount": round(float(amount or 0), 2),
        "title": title,
        "details": json.dumps(details, default=str),
    }


class Context:
    """Pre-indexed view of the data shared by all rules."""

    def __init__(self, txns: list[dict], shifts: list[dict], timeclock: list[dict] | None = None):
        self.txns = sorted(txns, key=lambda t: t["ts"])
        self.shifts = shifts
        self.timeclock = timeclock or []
        self.canaries: list[dict] = []          # honeytokens for DG-031 (set by the engine)
        self.by_id = {t["id"]: t for t in self.txns}
        self.by_type = defaultdict(list)
        self.by_order = defaultdict(list)
        self.by_register = defaultdict(list)      # register (or cashier fallback) -> txns sorted
        for t in self.txns:
            t["_dt"] = _dt(t["ts"])
            self.by_type[t["txn_type"]].append(t)
            if t["order_id"]:
                self.by_order[t["order_id"]].append(t)
            self.by_register[t["register"] or f"cashier:{t['cashier']}"].append(t)
        self.reg_times = {k: [x["_dt"] for x in v] for k, v in self.by_register.items()}

    def reg_key(self, t):
        return t["register"] or f"cashier:{t['cashier']}"

    def window(self, t, before_s: float, after_s: float) -> list[dict]:
        k = self.reg_key(t)
        times = self.reg_times[k]
        lo = bisect_left(times, t["_dt"] - timedelta(seconds=before_s))
        hi = bisect_right(times, t["_dt"] + timedelta(seconds=after_s))
        return [x for x in self.by_register[k][lo:hi] if x is not t]


# ---------------------------------------------------------------- drawer opens

def rule_no_sale_excess(ctx, cfg):
    out = []
    per_day = defaultdict(list)
    for t in ctx.by_type["no_sale"]:
        per_day[(t["cashier"], t["ts"][:10])].append(t)
    for (cashier, day), items in per_day.items():
        if len(items) > cfg["max_per_shift"]:
            sev = cfg["severity"] + (1 if len(items) >= 2 * cfg["max_per_shift"] else 0)
            out.append(alert("no_sale_excess", cfg, fp=f"{cashier}:{day}", cashier=cashier, register=items[0]["register"],
                             ts=items[-1]["ts"], severity=min(sev, 5),
                             title=f"{cashier} opened the drawer {len(items)}× with No Sale on {day}",
                             count=len(items), limit=cfg["max_per_shift"], times=[i["ts"][11:16] for i in items]))
    return out


def rule_no_sale_after_cash(ctx, cfg):
    out = []
    for t in ctx.by_type["no_sale"]:
        prior = [x for x in ctx.window(t, cfg["window_seconds"], 0)
                 if x["txn_type"] == "sale" and x["payment_method"] == "cash" and x["cashier"] == t["cashier"]]
        if prior:
            p = prior[-1]
            gap = int((t["_dt"] - p["_dt"]).total_seconds())
            out.append(alert("no_sale_after_cash", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"],
                             title=f"Drawer re-opened {gap}s after a {_money(p['amount'])} cash sale",
                             previous_sale=p["id"], previous_amount=p["amount"], seconds_after=gap))
    return out


def rule_no_sale_isolated(ctx, cfg):
    out = []
    q = cfg["quiet_minutes"] * 60
    for t in ctx.by_type["no_sale"]:
        nearby = [x for x in ctx.window(t, q, q) if x["txn_type"] in ("sale", "refund")]
        if not nearby:
            out.append(alert("no_sale_isolated", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"],
                             title=f"No-Sale drawer open with no sales within {cfg['quiet_minutes']} min",
                             quiet_minutes=cfg["quiet_minutes"]))
    return out


# ---------------------------------------------------------------- voids / cancels

def rule_post_payment_void(ctx, cfg):
    out = []
    for t in ctx.by_type["void"]:
        if t["amount"] < cfg["min_amount"]:
            continue
        paid = []
        if t["original_txn_id"] and t["original_txn_id"] in ctx.by_id:
            paid = [ctx.by_id[t["original_txn_id"]]]
        elif t["order_id"]:
            paid = [x for x in ctx.by_order[t["order_id"]] if x["txn_type"] == "sale" and x["_dt"] <= t["_dt"]]
        paid = [p for p in paid if p["payment_method"] == "cash"]
        if paid:
            out.append(alert("post_payment_void", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"],
                             title=f"{_money(t['amount'])} voided after customer paid cash (order {t['order_id'] or paid[0]['id']})",
                             paid_txn=paid[-1]["id"], paid_at=paid[-1]["ts"], reason=t["note"]))
    return out


def rule_cancel_after_kitchen(ctx, cfg):
    out = []
    for t in ctx.by_type["cancel"]:
        sent = t["sent_to_kitchen"] or any(x["sent_to_kitchen"] for x in ctx.by_order.get(t["order_id"], []) if x is not t)
        if sent:
            out.append(alert("cancel_after_kitchen", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"],
                             title=f"Order {t['order_id'] or t['id']} ({_money(t['amount'])}) cancelled after food was sent to kitchen",
                             reason=t["note"]))
    return out


# ---------------------------------------------------------------- refunds

def rule_refunds(ctx, rules):
    out = []
    for t in ctx.by_type["refund"]:
        orig = ctx.by_id.get(t["original_txn_id"]) if t["original_txn_id"] else None
        if orig is None and t["order_id"]:
            sales = [x for x in ctx.by_order[t["order_id"]] if x["txn_type"] == "sale" and x["_dt"] <= t["_dt"]]
            orig = sales[-1] if sales else None
        if orig is None:
            c = rules["unmatched_refund"]
            if c["enabled"]:
                out.append(alert("unmatched_refund", c, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                                 txn_id=t["id"], amount=t["amount"],
                                 severity=min(5, c["severity"] + (1 if t["amount"] >= 50 else 0)),
                                 title=f"{_money(t['amount'])} {t['payment_method'] or ''} refund with no original sale on record".replace("  ", " "),
                                 reason=t["note"]))
        else:
            c = rules["refund_exceeds_original"]
            if c["enabled"] and t["amount"] > orig["amount"] + 0.01:
                out.append(alert("refund_exceeds_original", c, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                                 txn_id=t["id"], amount=t["amount"] - orig["amount"],
                                 title=f"Refund {_money(t['amount'])} is more than the original sale {_money(orig['amount'])}",
                                 original=orig["id"]))
            c = rules["cash_refund_on_card_sale"]
            if c["enabled"] and t["payment_method"] == "cash" and orig["payment_method"] == "card":
                out.append(alert("cash_refund_on_card_sale", c, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                                 txn_id=t["id"], amount=t["amount"],
                                 title=f"Card sale refunded in cash ({_money(t['amount'])}) — cash left the drawer",
                                 original=orig["id"]))
            c = rules["refund_own_sale_quick"]
            if c["enabled"] and orig["cashier"] == t["cashier"]:
                mins = (t["_dt"] - orig["_dt"]).total_seconds() / 60
                if 0 <= mins <= c["window_minutes"]:
                    out.append(alert("refund_own_sale_quick", c, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                                     txn_id=t["id"], amount=t["amount"],
                                     title=f"Refunded own sale {int(mins)} min after ringing it ({_money(t['amount'])})",
                                     original=orig["id"]))
        c = rules["round_amount_refund"]
        if c["enabled"] and t["amount"] >= c["min_amount"] and abs(t["amount"] % 5) < 0.001:
            out.append(alert("round_amount_refund", c, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"], title=f"Round-number refund of {_money(t['amount'])}"))
    return out


# ---------------------------------------------------------------- discounts / overrides

def rule_excess_discount(ctx, cfg):
    out = []
    for t in ctx.txns:
        if t["txn_type"] == "discount":
            value = t["amount"]
            sales = [x for x in ctx.by_order.get(t["order_id"], []) if x["txn_type"] == "sale"] if t["order_id"] else []
            base = sum(s["amount"] for s in sales) + value if sales else None
        elif t["txn_type"] == "sale" and t["discount_amount"] > 0:
            value = t["discount_amount"]
            base = t["amount"] + value
        else:
            continue
        if value < cfg["min_amount"]:
            continue
        pct = (value / base * 100) if base else 100.0
        if pct > cfg["max_pct"]:
            out.append(alert("excess_discount", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=value,
                             severity=min(5, cfg["severity"] + (1 if pct >= 90 else 0)),
                             title=f"{pct:.0f}% discount ({_money(value)}) on order {t['order_id'] or t['id']}",
                             pct=round(pct, 1), approved_by=t["approved_by"], reason=t["note"]))
    return out


def rule_unapproved_override(ctx, cfg):
    out = []
    for t in ctx.txns:
        val = t["amount"] if t["txn_type"] != "sale" else 0
        if t["txn_type"] in cfg["types"] and val >= cfg["min_amount"] and not t["approved_by"]:
            out.append(alert("unapproved_override", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=val,
                             title=f"{t['txn_type'].replace('_', ' ').title()} of {_money(val)} with no manager approval"))
    return out


def rule_self_approved(ctx, cfg):
    out = []
    for t in ctx.txns:
        if t["approved_by"] and t["approved_by"].strip().lower() == t["cashier"].strip().lower() and t["txn_type"] != "sale":
            out.append(alert("self_approved", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"],
                             title=f"{t['cashier']} approved their own {t['txn_type'].replace('_', ' ')} ({_money(t['amount'])})"))
    return out


def rule_paid_out(ctx, cfg):
    out = []
    for t in ctx.by_type["paid_out"]:
        if t["amount"] >= cfg["min_amount"]:
            out.append(alert("paid_out", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"],
                             severity=min(5, cfg["severity"] + 1) if not t["approved_by"] else max(1, cfg["severity"] - 1),
                             title=f"{_money(t['amount'])} paid out of drawer" + ("" if t["approved_by"] else " (not approved)"),
                             reason=t["note"], approved_by=t["approved_by"]))
    return out


def rule_off_hours(ctx, cfg):
    out = []
    for t in ctx.txns:
        h = t["_dt"].hour
        if h < cfg["open_hour"] or h >= cfg["close_hour"]:
            out.append(alert("off_hours", cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"],
                             txn_id=t["id"], amount=t["amount"],
                             severity=min(5, cfg["severity"] + (1 if t["txn_type"] in ("no_sale", "refund", "paid_out", "void") else 0)),
                             title=f"{t['txn_type'].replace('_', ' ').title()} at {t['ts'][11:16]} — outside business hours"))
    return out


# ---------------------------------------------------------------- cash-up

def rule_cash_shortage(ctx, rules):
    out = []
    c, rc = rules["cash_shortage"], rules["repeat_shortage"]
    shorts = defaultdict(list)
    for s in ctx.shifts:
        if s["expected_cash"] is None or s["counted_cash"] is None:
            continue
        diff = s["counted_cash"] - s["expected_cash"]
        if diff < -c["tolerance"]:
            short = -diff
            shorts[s["cashier"]].append((s, short))
            if c["enabled"]:
                out.append(alert("cash_shortage", c, fp=f"{s['cashier']}:{s['register']}:{s['start_ts']}", cashier=s["cashier"],
                                 register=s["register"], ts=s["end_ts"], amount=short,
                                 severity=min(5, c["severity"] + (1 if short >= 50 else 0)),
                                 title=f"Drawer {_money(short)} short at end of shift ({s['start_ts'][:10]})",
                                 expected=s["expected_cash"], counted=s["counted_cash"]))
    if rc["enabled"]:
        for cashier, items in shorts.items():
            items.sort(key=lambda x: x[0]["end_ts"])
            window = []
            for s, short in items:
                end = _dt(s["end_ts"])
                window = [x for x in window if (end - _dt(x[0]["end_ts"])).days <= rc["days"]] + [(s, short)]
                if len(window) >= rc["count"]:
                    total = sum(x[1] for x in window)
                    out.append(alert("repeat_shortage", rc, fp=f"{cashier}:{s['end_ts'][:10]}", cashier=cashier, register=s["register"],
                                     ts=s["end_ts"],
                                     title=f"{cashier}: {len(window)} short drawers within {rc['days']} days (total {_money(total)})",
                                     total_short=round(total, 2), shifts=[x[0]["start_ts"][:10] for x in window]))
                    window = []      # start counting again so we alert once per streak
    return out


# ---------------------------------------------------------------- peer comparison

def cashier_metrics(ctx, since: datetime | None = None, until: datetime | None = None) -> dict:
    m = defaultdict(lambda: defaultdict(float))
    for t in ctx.txns:
        if since and t["_dt"] < since or until and t["_dt"] >= until:
            continue
        d = m[t["cashier"]]
        d["txns"] += 1
        typ = t["txn_type"]
        d[f"n_{typ}"] += 1
        d[f"v_{typ}"] += t["amount"]
        if typ == "sale":
            d["v_discount"] += t["discount_amount"]
            if t["payment_method"] == "cash":
                d["v_cash_sales"] += t["amount"]
                d["n_cash_sales"] += 1
    out = {}
    for c, d in m.items():
        sales = max(d["n_sale"], 1)
        sv = max(d["v_sale"], 1)
        out[c] = {
            "txns": int(d["txns"]), "sales": int(d["n_sale"]), "sales_value": round(d["v_sale"], 2),
            "void_rate": d["n_void"] / sales * 100, "refund_rate": d["n_refund"] / sales * 100,
            "no_sale_rate": d["n_no_sale"] / sales * 100, "cancel_rate": d["n_cancel"] / sales * 100,
            "discount_pct": d["v_discount"] / sv * 100, "refund_value_pct": d["v_refund"] / sv * 100,
            "cash_ratio": d["v_cash_sales"] / sv * 100,
            "n_void": int(d["n_void"]), "n_refund": int(d["n_refund"]), "n_no_sale": int(d["n_no_sale"]),
            "n_cancel": int(d["n_cancel"]), "n_paid_out": int(d["n_paid_out"]),
            "v_refund": round(d["v_refund"], 2), "v_void": round(d["v_void"], 2),
            "v_discount": round(d["v_discount"], 2), "v_paid_out": round(d["v_paid_out"], 2),
        }
    return out


PEER_METRICS = {
    "void_rate": "voids per 100 sales", "refund_rate": "refunds per 100 sales",
    "no_sale_rate": "No-Sale opens per 100 sales", "cancel_rate": "cancelled orders per 100 sales",
    "discount_pct": "% of sales given as discount", "refund_value_pct": "refund $ as % of sales $",
}


Z_FLOOR = {"cash_ratio": 2.5}   # percentage points; other metrics use a relative floor


def loo_z(metrics: dict, cashier: str, key: str) -> float | None:
    """Leave-one-out z-score: compare a cashier to everyone else."""
    others = [v[key] for c, v in metrics.items() if c != cashier]
    if len(others) < 2:
        return None
    mu = statistics.mean(others)
    sd = statistics.pstdev(others)
    floor = Z_FLOOR.get(key, max(abs(mu) * 0.25, 0.5))   # floor so tiny teams don't explode
    sd = max(sd, floor)
    return (metrics[cashier][key] - mu) / sd


def _months(ctx):
    seen = sorted({t["ts"][:7] for t in ctx.txns})
    for ym in seen:
        y, mth = map(int, ym.split("-"))
        start = datetime(y, mth, 1)
        end = datetime(y + (mth == 12), mth % 12 + 1, 1)
        yield ym, start, end


def rule_peer_outlier(ctx, rules):
    out = []
    c, lc = rules["peer_outlier"], rules["low_cash_ratio"]
    for ym, start, end in _months(ctx):
        metrics = cashier_metrics(ctx, start, end)
        eligible = {k: v for k, v in metrics.items() if v["txns"] >= c["min_txns"]}
        if len(eligible) < 3:
            continue
        for cashier, v in eligible.items():
            if c["enabled"]:
                for key, label in PEER_METRICS.items():
                    z = loo_z(eligible, cashier, key)
                    if z is not None and z >= c["z_threshold"]:
                        team = statistics.mean(x[key] for k, x in eligible.items() if k != cashier)
                        out.append(alert("peer_outlier", c, fp=f"{cashier}:{key}:{ym}", cashier=cashier, ts=f"{ym}-01T00:00:00",
                                         severity=min(5, c["severity"] + (1 if z >= c["z_threshold"] * 2 else 0)),
                                         title=f"{cashier}: {v[key]:.1f} {label} vs team {team:.1f} ({ym})",
                                         metric=key, value=round(v[key], 2), team_avg=round(team, 2), z=round(z, 2), month=ym))
            if lc["enabled"] and v["txns"] >= lc["min_txns"]:
                z = loo_z(eligible, cashier, "cash_ratio")
                if z is not None and z <= lc["z_threshold"]:
                    team = statistics.mean(x["cash_ratio"] for k, x in eligible.items() if k != cashier)
                    gap = (team - v["cash_ratio"]) / 100 * v["sales_value"]
                    out.append(alert("low_cash_ratio", lc, fp=f"{cashier}:{ym}", cashier=cashier, ts=f"{ym}-01T00:00:00",
                                     amount=max(gap, 0),
                                     title=f"{cashier} rings only {v['cash_ratio']:.0f}% cash vs team {team:.0f}% ({ym}) — cash sales may not be rung up",
                                     cash_ratio=round(v["cash_ratio"], 1), team_avg=round(team, 1), z=round(z, 2), month=ym))
    return out


# ---------------------------------------------------------------- control gaps & collusion

def rule_missing_count(ctx, cfg):
    out = []
    by_cashier = defaultdict(list)
    for sh in ctx.shifts:
        if sh.get("expected_cash") is not None and sh.get("counted_cash") is None:
            by_cashier[sh["cashier"]].append(sh)
    for cashier, items in by_cashier.items():
        items.sort(key=lambda x: x["start_ts"])
        for i, sh in enumerate(items):
            end = _dt(sh["end_ts"] or sh["start_ts"])
            recent = [x for x in items[: i + 1] if (end - _dt(x["end_ts"] or x["start_ts"])).days <= cfg["repeat_days"]]
            repeat = len(recent) >= cfg["repeat_count"]
            out.append(alert("missing_count", cfg, fp=f"{cashier}:{sh['register']}:{sh['start_ts']}", cashier=cashier,
                             register=sh["register"], ts=sh["end_ts"], severity=min(5, cfg["severity"] + (1 if repeat else 0)),
                             title=f"{cashier} closed the {sh['start_ts'][11:16]} shift on {sh['start_ts'][:10]} without counting the drawer"
                                   + (f" ({len(recent)}× in {cfg['repeat_days']} days)" if repeat else ""),
                             expected=sh["expected_cash"], times_in_window=len(recent)))
    return out


OVERRIDE_TYPES = ("refund", "void", "paid_out", "discount", "cancel")
WINDOW_EPOCH = datetime(2020, 1, 6)


def _windows30(ctx, length=30, step=15):
    """Overlapping 30-day windows every 15 days (fixed epoch, so fingerprints are stable):
    any scheme that runs for 15 days or less falls entirely inside one window."""
    if not ctx.txns:
        return
    lo, hi = ctx.txns[0]["_dt"], ctx.txns[-1]["_dt"]
    k = max(0, int((lo - WINDOW_EPOCH).days // step) - 1)
    while True:
        start = WINDOW_EPOCH + timedelta(days=k * step)
        if start > hi:
            break
        end = start + timedelta(days=length)
        if end > lo:
            yield start.strftime("%Y-%m-%d"), start, end
        k += 1


def rule_approver_concentration(ctx, cfg):
    """Possible collusion: one approver signs off a cashier's overrides far more often than
    their usual share. Expected share = the approver's share of everyone else's approvals."""
    out = []
    latest = ctx.txns[-1]["_dt"] if ctx.txns else None
    for ym, start, end in _windows30(ctx):
        pairs = defaultdict(lambda: defaultdict(lambda: [0, 0.0]))     # cashier -> approver -> [n, amount]
        for t in ctx.txns:
            if not (start <= t["_dt"] < end):
                continue
            appr = (t["approved_by"] or "").strip()
            is_override = t["txn_type"] in OVERRIDE_TYPES or (t["txn_type"] == "sale" and t["discount_amount"] > 0)
            if not appr or not is_override or appr.lower() == t["cashier"].strip().lower():
                continue
            cell = pairs[t["cashier"]][appr]
            cell[0] += 1
            cell[1] += t["amount"] if t["txn_type"] != "sale" else t["discount_amount"]
        for cashier, approvers in pairs.items():
            n_c = sum(v[0] for v in approvers.values())
            if n_c < cfg["min_approvals"]:
                continue
            # Robust baseline: the MEDIAN share this approver has across the other cashiers, so one
            # colluding pair can't distort what "normal" looks like for everyone else.
            peers = {c2: (ap2, sum(v[0] for v in ap2.values())) for c2, ap2 in pairs.items()
                     if c2 != cashier and sum(v[0] for v in ap2.values()) >= 3}
            if len(peers) < 2:
                continue
            for appr, (k, amount) in approvers.items():
                p = max(statistics.median(ap2.get(appr, [0])[0] / n2 for ap2, n2 in peers.values()), 0.02)
                if p >= 0.98:
                    continue
                z = (k - n_c * p) / math.sqrt(n_c * p * (1 - p))
                share = k / n_c
                if z >= cfg["z_threshold"] and share >= cfg["min_share"]:
                    stamp = min(end - timedelta(seconds=1), latest).strftime("%Y-%m-%dT%H:%M:%S")
                    out.append(alert("approver_concentration", cfg, fp=f"{cashier}:{appr}:w{ym}", cashier=cashier,
                                     ts=stamp, amount=amount,
                                     severity=min(5, cfg["severity"] + (1 if z >= 2 * cfg["z_threshold"] else 0)),
                                     title=f"{appr} approved {k} of {cashier}'s {n_c} overrides ({share:.0%}) in the 30 days from {ym} "
                                           f"vs {p:.0%} of everyone else's: possible collusion",
                                     approver=appr, approvals=k, cashier_overrides=n_c, share=round(share, 3),
                                     expected_share=round(p, 3), z=round(z, 2), window_start=ym, value=round(amount, 2)))
    return out


SIMPLE_RULES = {
    "no_sale_excess": rule_no_sale_excess,
    "no_sale_after_cash": rule_no_sale_after_cash,
    "no_sale_isolated": rule_no_sale_isolated,
    "post_payment_void": rule_post_payment_void,
    "cancel_after_kitchen": rule_cancel_after_kitchen,
    "excess_discount": rule_excess_discount,
    "unapproved_override": rule_unapproved_override,
    "self_approved": rule_self_approved,
    "paid_out": rule_paid_out,
    "off_hours": rule_off_hours,
    "missing_count": rule_missing_count,
    "approver_concentration": rule_approver_concentration,
}
GROUP_RULES = [rule_refunds, rule_cash_shortage, rule_peer_outlier]  # receive full rules dict


def run_rules(ctx: Context, rules: dict) -> list[dict]:
    from .deception import DECEPTION_RULE_FUNCS
    from .payroll import PAYROLL_RULE_FUNCS
    alerts = []
    for key, fn in {**SIMPLE_RULES, **PAYROLL_RULE_FUNCS, **DECEPTION_RULE_FUNCS}.items():
        if rules[key]["enabled"]:
            alerts.extend(fn(ctx, rules[key]))
    for fn in GROUP_RULES:
        alerts.extend(fn(ctx, rules))
    return alerts


def nan_safe(x):
    return None if x is None or (isinstance(x, float) and math.isnan(x)) else x
