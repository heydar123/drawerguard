"""Detection engine: loads data per store, runs rules + AI, stores alerts, scores cashiers."""
import copy
import math
from collections import defaultdict
from datetime import datetime, timedelta

from ..config import PAYROLL_RULES, merged_rules
from ..db import get_setting, rows
import json
import logging
from datetime import timezone

from .ai import rule_ai_anomaly, rule_behavior_change
from .deception import apply_watchlist, load_watch
from .ml import rule_iforest
from .custom import RuleError, evaluate as evaluate_custom, validate as validate_custom
from .rules import PEER_METRICS, Context, alert, cashier_metrics, loo_z, run_rules

ALERT_COLS = ["fingerprint", "store", "rule", "severity", "cashier", "register", "ts", "txn_id", "amount", "title", "details",
              "due_at", "created_at", "tags"]
PEER_RULES = ("peer_outlier", "low_cash_ratio")


def all_stores(conn) -> list[str]:
    return [r["id"] for r in conn.execute("SELECT id FROM stores ORDER BY id")]


def _in(stores):
    return f"({','.join('?' * len(stores))})"


def load_context(conn, stores: list[str], since: str | None = None) -> Context:
    q, p = f"SELECT * FROM transactions WHERE store IN {_in(stores)}", list(stores)
    if since:
        q += " AND ts >= ?"
        p.append(since)
    txns = rows(conn.execute(q, p))
    sq, sp = f"SELECT * FROM shifts WHERE store IN {_in(stores)}", list(stores)
    if since:
        sq += " AND start_ts >= ?"
        sp.append(since)
    tq, tp = f"SELECT * FROM timeclock WHERE store IN {_in(stores)}", list(stores)
    if since:
        tq += " AND clock_in >= ?"
        tp.append(since)
    return Context(txns, rows(conn.execute(sq, sp)), rows(conn.execute(tq, tp)))


log = logging.getLogger("drawerguard.engine")


def load_custom_rules(conn, only_enabled: bool = True) -> list[dict]:
    out = []
    q = "SELECT * FROM custom_rules" + (" WHERE enabled=1" if only_enabled else "")
    for r in conn.execute(q):
        try:
            out.append({**dict(r), "definition": validate_custom(json.loads(r["definition"]))})
        except (RuleError, ValueError) as e:
            log.error("custom rule %s is invalid and was skipped: %s", r["id"], e)
    return out


def detect_store(conn, sid: str, rules: dict, custom: list[dict], persist_ai: bool = True, ctx=None) -> list[dict]:
    """All alerts for one store under a given rule configuration (no database writes
    except the AI score table when persist_ai=True). Used by detection and backtesting."""
    ctx = ctx or load_context(conn, [sid])
    if not ctx.txns:
        return []
    if conn is not None and not ctx.canaries:
        from .deception import load_canaries
        ctx.canaries = load_canaries(conn, sid)
    items = run_rules(ctx, rules)
    if rules["ai_anomaly"]["enabled"]:
        items += rule_ai_anomaly(ctx, rules["ai_anomaly"], sid, conn if persist_ai else None)
    if rules["behavior_change"]["enabled"]:
        items += rule_behavior_change(ctx, rules["behavior_change"])
    if rules["iforest_anomaly"]["enabled"]:
        items += rule_iforest(ctx, rules["iforest_anomaly"])
    for cr in custom:
        items += evaluate_custom(ctx, cr)
    if rules["correlated_shift"]["enabled"]:
        items += correlate_shift(items, rules["correlated_shift"])
    return items


def store_rules(base: dict, st: dict) -> dict:
    rules = copy.deepcopy(base)
    if st.get("open_hour") is not None:
        rules["off_hours"]["open_hour"] = st["open_hour"]
    if st.get("close_hour") is not None:
        rules["off_hours"]["close_hour"] = st["close_hour"]
    return rules


def run_detection(conn, stores: list[str] | None = None) -> dict:
    """Run every rule for every store; insert new alerts. Returns {'new': [...], ...}."""
    from ..soc import due_for          # local import: soc depends on db only
    base = merged_rules(get_setting(conn, "rules", {}))
    custom = load_custom_rules(conn)
    store_rows = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM stores")}
    found = []
    for sid in stores or list(store_rows):
        items = detect_store(conn, sid, store_rules(base, store_rows.get(sid, {})), custom)
        apply_watchlist(items, load_watch(conn, sid))
        for a in items:
            a["store"] = sid
            a["fingerprint"] = f"{sid}|{a['fingerprint']}"
        found += items
    existing = {r["fingerprint"] for r in conn.execute("SELECT fingerprint FROM alerts")}
    seen, new = set(existing), []
    now = datetime.now(timezone.utc)
    created = now.strftime("%Y-%m-%d %H:%M:%S")
    for a in found:
        if a["fingerprint"] not in seen:
            seen.add(a["fingerprint"])
            a["due_at"], a["created_at"] = due_for(a["severity"], now), created
            a.setdefault("tags", "")
            new.append(a)
    conn.executemany(
        f"INSERT OR IGNORE INTO alerts({','.join(ALERT_COLS)}) VALUES({','.join('?' * len(ALERT_COLS))})",
        [tuple(a[c] for c in ALERT_COLS) for a in new],
    )
    conn.commit()
    if new:                                          # attach database ids for playbooks / notifications
        ids = {}
        fps = [a["fingerprint"] for a in new]
        for i in range(0, len(fps), 500):
            chunk = fps[i:i + 500]
            for r in conn.execute(f"SELECT id, fingerprint FROM alerts WHERE fingerprint IN {_in(chunk)}", chunk):
                ids[r["fingerprint"]] = r["id"]
        for a in new:
            a["id"] = ids.get(a["fingerprint"])
            a["status"] = "open"
    return {"new": new, "new_count": len(new), "total_found": len(found)}


NOT_CORRELATED = {"peer_outlier", "low_cash_ratio", "approver_concentration", "behavior_change", "correlated_shift", "repeat_shortage",
                  *PAYROLL_RULES}


def correlate_shift(items: list[dict], cfg: dict) -> list[dict]:
    """DG-024: several *different* detections firing for one cashier on one day is far
    stronger evidence than any single alert (a simple correlation / kill-chain rule)."""
    groups = defaultdict(lambda: defaultdict(list))
    for a in items:
        if a["rule"] in NOT_CORRELATED or a["severity"] < cfg["min_severity"] or not a.get("cashier") or not a.get("ts"):
            continue
        groups[(a["cashier"], a["ts"][:10])][a["rule"]].append(a)
    out = []
    for (cashier, day), by_rule in groups.items():
        if len(by_rule) >= cfg["min_distinct"]:
            labels = sorted(by_rule)
            total = sum(x["amount"] for v in by_rule.values() for x in v)
            out.append(alert("correlated_shift", cfg, fp=f"{cashier}:{day}", cashier=cashier, ts=f"{day}T23:59:30", amount=total,
                             title=f"{cashier}: {len(by_rule)} different fraud indicators on {day} "
                                   f"({', '.join(r.replace('_', ' ') for r in labels[:4])}{'…' if len(labels) > 4 else ''})",
                             rules=labels, alerts=sum(len(v) for v in by_rule.values()), day=day))
    return out


SEV_WEIGHT = {1: 1, 2: 2, 3: 4, 4: 8, 5: 15}


def window_since(conn, stores: list[str], days: int | None) -> tuple[str | None, str | None]:
    latest = conn.execute(f"SELECT MAX(ts) m FROM transactions WHERE store IN {_in(stores)}", stores).fetchone()["m"]
    if not latest or not days:
        return None, latest
    end = datetime.fromisoformat(latest) + timedelta(seconds=1)
    return (end - timedelta(days=days)).isoformat(), latest


def alert_since_sql(since: str | None) -> tuple[str, list]:
    """Monthly peer alerts are stamped on the 1st, so include their whole month."""
    if not since:
        return "", []
    return f" AND (ts >= ? OR (rule IN {PEER_RULES} AND ts >= ?))", [since, since[:7] + "-01T00:00:00"]


def cashier_scores(conn, days: int | None = 30, stores: list[str] | None = None) -> list[dict]:
    """Risk score 0–100 per cashier, plus the evidence behind it."""
    stores = stores or all_stores(conn)
    if not stores:
        return []
    since, latest = window_since(conn, stores, days)
    if not latest:
        return []
    ctx = load_context(conn, stores, since)
    metrics = cashier_metrics(ctx)
    home = defaultdict(lambda: defaultdict(int))
    for t in ctx.txns:
        home[t["cashier"]][t["store"]] += 1

    w, p = alert_since_sql(since)
    al, payroll = defaultdict(list), defaultdict(int)
    for r in conn.execute(f"SELECT cashier, severity, status, amount, rule FROM alerts WHERE status != 'dismissed' "
                          f"AND store IN {_in(stores)}{w}", [*stores, *p]):
        if r["rule"] in PAYROLL_RULES:         # payroll fraud has its own page; it doesn't drive the cash-theft score
            payroll[r["cashier"]] += 1
            continue
        al[r["cashier"]].append(dict(r))

    ai = defaultdict(list)
    aq = f"SELECT cashier, score FROM shift_anomaly WHERE store IN {_in(stores)}"
    ap = list(stores)
    if since:
        aq += " AND day >= ?"
        ap.append(since[:10])
    for r in conn.execute(aq, ap):
        ai[r["cashier"]].append(r["score"])

    shortages = defaultdict(float)
    for s in ctx.shifts:
        if s["expected_cash"] is not None and s["counted_cash"] is not None:
            shortages[s["cashier"]] += s["counted_cash"] - s["expected_cash"]

    eligible = {k: v for k, v in metrics.items() if v["txns"] >= 30}
    out = []
    for cashier in sorted(set(metrics) | set(al)):
        if cashier not in metrics and not al.get(cashier):
            continue
        m = metrics.get(cashier, {"txns": 0, "sales": 0, "sales_value": 0, "cash_ratio": 0})
        a = al.get(cashier, [])
        weight = sum(SEV_WEIGHT.get(x["severity"], 1) for x in a if x["rule"] not in ("ai_anomaly", "iforest_anomaly"))
        confirmed = sum(1 for x in a if x["status"] == "confirmed")
        per100 = weight / max(m["txns"], 1) * 100
        zs = {}
        if cashier in eligible and len(eligible) >= 3:
            for key in list(PEER_METRICS) + ["cash_ratio"]:
                z = loo_z(eligible, cashier, key)
                if z is not None:
                    zs[key] = round(z * min(1.0, m["txns"] / 300), 2)    # shrink for small samples
        z_pressure = sum(max(0, z - 1) for k, z in zs.items() if k != "cash_ratio") + max(0, -zs.get("cash_ratio", 0) - 1) * 1.5
        short = -min(shortages.get(cashier, 0), 0)
        scores = ai.get(cashier, [])
        ai_avg = sum(scores) / len(scores) if scores else 0
        ai_hot = sum(1 for s in scores if s >= 80)
        ai_pressure = max(0, ai_avg - 35) / 5 + ai_hot * 1.5
        raw = per100 * 0.6 + z_pressure * 6 + confirmed * 15 + min(short / 20, 20) + min(weight / 10, 15) + ai_pressure
        score = round(100 * (1 - math.exp(-raw / 30)))
        level = "high" if score >= 60 else "medium" if score >= 30 else "low"
        out.append({
            "cashier": cashier, "score": score, "level": level,
            "stores": sorted(home.get(cashier, {}), key=lambda s: -home[cashier][s]),
            "alerts": len(a), "critical": sum(1 for x in a if x["severity"] >= 4),
            "confirmed": confirmed, "amount_at_risk": round(sum(x["amount"] for x in a), 2),
            "net_drawer_diff": round(shortages.get(cashier, 0), 2),
            "ai_avg": round(ai_avg, 1), "ai_hot_days": ai_hot,
            "metrics": {k: (round(v, 2) if isinstance(v, float) else v) for k, v in m.items()},
            "z": zs,
            "top_rules": _top_rules(a), "payroll_alerts": payroll.get(cashier, 0),
        })
    out.sort(key=lambda x: -x["score"])
    return out


def _top_rules(a):
    c = defaultdict(int)
    for x in a:
        c[x["rule"]] += 1
    return sorted(c.items(), key=lambda kv: -kv[1])[:4]
