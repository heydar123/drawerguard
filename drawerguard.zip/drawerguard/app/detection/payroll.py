"""Payroll and timeclock fraud detections (DG-025 … DG-029).

Cash isn't the only thing that walks out of a store: paid time does too. These
rules join the timeclock (who was on the clock, on which device) with the POS
(who actually rang sales) to find the classic payroll schemes from the ACFE
Fraud Tree: ghost employees and falsified hours (buddy punching, padding,
manual edits), plus shared logins (sales under a cashier who was clocked out).

Every rule is a no-op for stores that don't import timeclock data.
"""
from bisect import bisect_right
from collections import defaultdict
from datetime import datetime, timedelta

from .rules import alert


def _dt(s):
    return datetime.fromisoformat(s)


def _hours(p) -> float:
    if not p.get("clock_out"):
        return 0.0
    return max(0.0, (_dt(p["clock_out"]) - _dt(p["clock_in"])).total_seconds() / 3600)


def _pos_people(ctx) -> set[str]:
    """Everyone who did anything on the POS (rang a transaction or approved one)."""
    people = {t["cashier"] for t in ctx.txns}
    people |= {t["approved_by"] for t in ctx.txns if t.get("approved_by")}
    return {p.strip().lower() for p in people if p}


def rule_buddy_punch(ctx, cfg):
    """Two different employees punch on the same device within N seconds of each other,
    and the same pair does it repeatedly: one person is clocking in for an absent friend."""
    by_device = defaultdict(list)
    for p in ctx.timeclock:
        if (p.get("method") or "") == "manager":
            continue
        by_device[p.get("device") or "?"].append((_dt(p["clock_in"]), p["employee"], p, "in"))
        if p.get("clock_out") and not p.get("edited_by"):
            by_device[p.get("device") or "?"].append((_dt(p["clock_out"]), p["employee"], p, "out"))
    hits = defaultdict(list)                                      # (a, b) -> [(dt, later punch)]
    for punches in by_device.values():
        punches.sort(key=lambda x: x[0])
        for (t1, e1, _, k1), (t2, e2, p2, k2) in zip(punches, punches[1:], strict=False):
            # the suspicious pattern: someone's clock-IN seconds after another person's punch
            if e1 != e2 and k2 == "in" and (t2 - t1).total_seconds() <= cfg["window_seconds"]:
                hits[tuple(sorted((e1, e2)))].append((t2, e2, e1, p2, int((t2 - t1).total_seconds()), k1))
    out = []
    for (a, b), items in hits.items():
        items.sort(key=lambda x: x[0])
        for i, (t, late, by, p, secs, k1) in enumerate(items):
            recent = [x for x in items[: i + 1] if (t - x[0]).days < cfg["days"]]
            if len(recent) < cfg["min_times"]:
                continue
            sev = min(5, cfg["severity"] + (1 if len(recent) >= 2 * cfg["min_times"] else 0))
            out.append(alert("buddy_punch", cfg, fp=f"{a}:{b}:{t:%Y-%m-%dT%H:%M}", cashier=late, register=p.get("device"),
                             ts=t.isoformat(), severity=sev,
                             title=f"{late} was clocked in {secs} s after {by} clocked {k1} on {p.get('device') or 'the same clock'} "
                                   f"({len(recent)}× in {cfg['days']} days): possible buddy punching",
                             partner=by, seconds=secs, device=p.get("device"), times_in_window=len(recent),
                             dates=[x[0].strftime("%Y-%m-%d") for x in recent][-8:]))
    return out


def rule_ghost_employee(ctx, cfg):
    """Paid hours for someone who never appears in the POS: no sales, no approvals."""
    if not ctx.timeclock or not ctx.txns:
        return []
    pos = _pos_people(ctx)
    ignore = {x.strip().lower() for x in cfg.get("ignore", [])}
    by_emp = defaultdict(list)
    for p in ctx.timeclock:
        by_emp[p["employee"]].append(p)
    out = []
    for emp, punches in by_emp.items():
        if emp.strip().lower() in pos or emp.strip().lower() in ignore:
            continue
        hours = sum(_hours(p) for p in punches)
        if hours < cfg["min_hours"]:
            continue
        rate = next((p["hourly_rate"] for p in punches if p.get("hourly_rate")), None)
        punched_by = defaultdict(int)
        for p in punches:
            punched_by[(p.get("method") or "?") + ((" by " + p["edited_by"]) if p.get("edited_by") else "")] += 1
        devices = sorted({p.get("device") or "?" for p in punches})
        last = max(punches, key=lambda p: p["clock_in"])
        cost = round(hours * rate, 2) if rate else 0.0
        out.append(alert("ghost_employee", cfg, fp=f"{emp}:{last['clock_in'][:7]}", cashier=emp, ts=last["clock_in"], amount=cost,
                         title=f"{emp}: {hours:.0f} paid hours over {len(punches)} shifts but not one POS transaction or approval"
                               + (f" (≈${cost:,.0f} in wages)" if cost else ""),
                         hours=round(hours, 1), shifts=len(punches), devices=devices, methods=dict(punched_by), hourly_rate=rate))
    return out


def rule_clocked_out_activity(ctx, cfg):
    """POS transactions under a cashier who was not on the clock: someone else is using
    their login (or they work off the clock). Only for staff who use the timeclock."""
    if not ctx.timeclock:
        return []
    spans = defaultdict(list)
    for p in ctx.timeclock:
        spans[p["employee"].strip().lower()].append((_dt(p["clock_in"]), _dt(p["clock_out"]) if p.get("clock_out") else None))
    for v in spans.values():
        v.sort(key=lambda x: x[0])
    grace = timedelta(minutes=cfg["grace_minutes"])
    starts = {k: [s for s, _ in v] for k, v in spans.items()}
    per_day = defaultdict(list)
    for t in ctx.txns:
        k = t["cashier"].strip().lower()
        if k not in spans:
            continue
        i = bisect_right(starts[k], t["_dt"] + grace) - 1
        on = i >= 0 and (spans[k][i][1] is None or t["_dt"] <= spans[k][i][1] + grace)
        if not on:
            per_day[(t["cashier"], t["ts"][:10])].append(t)
    out = []
    for (cashier, day), items in per_day.items():
        if len(items) < cfg["min_txns"]:
            continue
        value = sum(x["amount"] for x in items if x["txn_type"] in ("sale", "refund", "paid_out"))
        out.append(alert("clocked_out_activity", cfg, fp=f"{cashier}:{day}", cashier=cashier, register=items[0]["register"],
                         ts=items[0]["ts"], amount=value,
                         title=f"{len(items)} transactions under {cashier}'s login on {day} while {cashier} was clocked out "
                               f"({items[0]['ts'][11:16]}–{items[-1]['ts'][11:16]})",
                         txns=len(items), first=items[0]["ts"], last=items[-1]["ts"],
                         types=sorted({x["txn_type"] for x in items})))
    return out


def rule_clock_padding(ctx, cfg):
    """Clocked in long before the first POS activity, or out long after the last one, again
    and again: paid time with nothing done."""
    if not ctx.timeclock:
        return []
    acts = defaultdict(list)
    for t in ctx.txns:
        acts[t["cashier"].strip().lower()].append(t["_dt"])
    gap = timedelta(minutes=cfg["gap_minutes"])
    events = defaultdict(list)
    for p in ctx.timeclock:
        k = p["employee"].strip().lower()
        if k not in acts or not p.get("clock_out") or (p.get("minutes_added") or 0) > 0:
            continue                                   # edited punches are DG-029's job
        cin, cout = _dt(p["clock_in"]), _dt(p["clock_out"])
        inside = [x for x in acts[k] if cin <= x <= cout]
        if not inside:
            continue
        early, late = min(inside) - cin, cout - max(inside)
        if early > gap or late > gap:
            events[p["employee"]].append((cin, round(early.total_seconds() / 60), round(late.total_seconds() / 60), p))
    out = []
    for emp, items in events.items():
        items.sort(key=lambda x: x[0])
        for i, (cin, early, late, p) in enumerate(items):
            recent = [x for x in items[: i + 1] if (cin - x[0]).days < cfg["days"]]
            if len(recent) < cfg["min_times"]:
                continue
            idle = sum(max(0, e - 15) + max(0, l_ - 15) for _, e, l_, _ in recent)
            rate = p.get("hourly_rate") or 0
            out.append(alert("clock_padding", cfg, fp=f"{emp}:{p['clock_in']}", cashier=emp, register=p.get("device"), ts=p["clock_in"],
                             amount=round(idle / 60 * rate, 2), severity=min(5, cfg["severity"] + (1 if len(recent) >= 2 * cfg["min_times"] else 0)),
                             title=f"{emp} clocked in {early} min before the first sale and out {late} min after the last "
                                   f"on {p['clock_in'][:10]} ({len(recent)}× in {cfg['days']} days, ≈{idle / 60:.1f} idle paid hours)",
                             early_minutes=early, late_minutes=late, times_in_window=len(recent), idle_hours=round(idle / 60, 1)))
    return out


def rule_timecard_edit(ctx, cfg):
    """Manual punch edits that add paid time: many in 30 days, a large total, or an
    employee editing their own card."""
    by_emp = defaultdict(list)
    for p in ctx.timeclock:
        if p.get("edited_by") and (p.get("minutes_added") or 0) >= cfg["min_minutes"]:
            by_emp[p["employee"]].append(p)
    out = []
    for emp, edits in by_emp.items():
        edits.sort(key=lambda p: p["clock_in"])
        for i, p in enumerate(edits):
            t = _dt(p["clock_in"])
            recent = [x for x in edits[: i + 1] if (t - _dt(x["clock_in"])).days < 30]
            total = sum(x["minutes_added"] for x in recent)
            self_edit = p["edited_by"].strip().lower() == emp.strip().lower()
            if not (self_edit or len(recent) >= cfg["min_edits"] or total >= cfg["min_total_minutes"]):
                continue
            editors = defaultdict(int)
            for x in recent:
                editors[x["edited_by"]] += 1
            top, n_top = max(editors.items(), key=lambda kv: kv[1])
            rate = p.get("hourly_rate") or 0
            sev = 5 if self_edit else min(5, cfg["severity"] + (1 if total >= 2 * cfg["min_total_minutes"] else 0))
            out.append(alert("timecard_edit", cfg, fp=f"{emp}:{p['clock_in']}", cashier=emp, ts=p["clock_in"],
                             amount=round(p["minutes_added"] / 60 * rate, 2), severity=sev,
                             title=(f"{emp} edited their own timecard" if self_edit else
                                    f"{p['edited_by']} added {p['minutes_added']:.0f} paid minutes to {emp}'s {p['clock_in'][:10]} shift")
                                   + f" ({len(recent)} edits, +{total / 60:.1f} h in 30 days; {n_top} by {top})",
                             edits=len(recent), minutes_added=round(p["minutes_added"]), minutes_30d=round(total), editors=dict(editors),
                             self_edit=self_edit, note=p.get("edit_note") or ""))
    return out


PAYROLL_RULE_FUNCS = {
    "buddy_punch": rule_buddy_punch,
    "ghost_employee": rule_ghost_employee,
    "clocked_out_activity": rule_clocked_out_activity,
    "clock_padding": rule_clock_padding,
    "timecard_edit": rule_timecard_edit,
}
