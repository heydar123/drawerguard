"""Machine learning layer: isolation forest (DG-030) and model monitoring.

Isolation forest (Liu, Ting & Zhou, 2008) isolates points with random splits;
anomalies need fewer splits, so a short average path length = an outlier.
It is a second, independent model next to the robust-z behaviour score (DG-020):
the z-score looks at one feature at a time, the forest at *combinations*
(e.g. slightly more refunds AND slightly less cash AND a small shortage).

Fraud is one-sided: a cashier with unusually FEW refunds is not suspicious. So
each feature is robust-scaled (median / MAD per store) and clipped to its
suspicious direction before the forest sees it. Explanations come from which
features the isolating splits used, weighted by how early they happened.

Model monitoring: population stability index (PSI) per feature, recent days vs
the baseline, plus alert-volume drift and agreement between the two models.

Pure Python and deterministic (seeded), so results are reproducible in tests.
"""
import math
import random
import statistics
from collections import defaultdict

from .ai import FEATURES, day_profiles
from .rules import alert

EULER = 0.5772156649


def _c(n: int) -> float:
    """Average path length of an unsuccessful BST search: the normaliser in the iForest paper."""
    if n <= 1:
        return 0.0
    if n == 2:
        return 1.0
    return 2 * (math.log(n - 1) + EULER) - 2 * (n - 1) / n


class IsolationForest:
    def __init__(self, n_trees=150, sample=128, seed=42):
        self.n_trees, self.sample, self.seed = n_trees, sample, seed
        self.trees, self.psi = [], 128

    def fit(self, X: list[list[float]]):
        # deterministic sampling for a model, not security
        rnd = random.Random(self.seed)  # noqa: S311  # nosec B311
        self.psi = min(self.sample, len(X))
        limit = math.ceil(math.log2(max(self.psi, 2)))
        self.trees = [self._grow(rnd.sample(X, self.psi), 0, limit, rnd) for _ in range(self.n_trees)]
        return self

    def _grow(self, X, depth, limit, rnd):
        if depth >= limit or len(X) <= 1:
            return ("leaf", len(X))
        dims = [d for d in range(len(X[0])) if min(x[d] for x in X) < max(x[d] for x in X)]
        if not dims:
            return ("leaf", len(X))
        d = rnd.choice(dims)
        lo, hi = min(x[d] for x in X), max(x[d] for x in X)
        split = rnd.uniform(lo, hi)
        left = [x for x in X if x[d] < split]
        right = [x for x in X if x[d] >= split]
        return ("node", d, split, self._grow(left, depth + 1, limit, rnd), self._grow(right, depth + 1, limit, rnd))

    def _path(self, x, node, depth, contrib):
        if node[0] == "leaf":
            return depth + _c(node[1])
        _, d, split, left, right = node
        contrib[d] += 1.0 / (depth + 1)                 # early splits isolate the most
        return self._path(x, left if x[d] < split else right, depth + 1, contrib)

    def score(self, x) -> tuple[float, list[float]]:
        contrib = [0.0] * len(x)
        avg = sum(self._path(x, t, 0, contrib) for t in self.trees) / len(self.trees)
        return 2 ** (-avg / _c(self.psi)), contrib


KEYS = list(FEATURES)


def _scalers(profiles: list[dict]) -> dict:
    out = {}
    for k, (_, _direction, floor, _) in FEATURES.items():
        vals = [p[k] for p in profiles]
        med = statistics.median(vals)
        mad = statistics.median([abs(v - med) for v in vals]) * 1.4826
        out[k] = (med, max(mad, floor))
    return out


def _vector(p: dict, sc: dict) -> list[float]:
    """One-sided robust z: only the suspicious direction counts; capped so one wild day can't dominate."""
    return [min(8.0, max(0.0, FEATURES[k][1] * (p[k] - sc[k][0]) / sc[k][1])) for k in KEYS]


def score_days_iforest(ctx, cfg) -> list[dict]:
    prof = {k: v for k, v in day_profiles(ctx).items() if v["sales"] >= cfg["min_sales"]}
    if len(prof) < 30:
        return []
    keys = sorted(prof)
    sc = _scalers([prof[k] for k in keys])
    X = [_vector(prof[k], sc) for k in keys]
    forest = IsolationForest(cfg["trees"], cfg["sample"]).fit(X)
    out = []
    for key, x in zip(keys, X, strict=True):
        s, contrib = forest.score(x)
        total = sum(c * v for c, v in zip(contrib, x, strict=True)) or 1
        drivers = sorted(((KEYS[i], contrib[i] * x[i] / total) for i in range(len(KEYS)) if x[i] > 1.0), key=lambda kv: -kv[1])
        out.append({"cashier": key[0], "day": key[1], "score": round(s, 3), "sales": int(prof[key]["sales"]),
                    "drivers": [{"feature": k, "label": FEATURES[k][0], "share": round(w, 2), "value": round(prof[key][k], 1),
                                 "usual": round(sc[k][0], 1), "unit": FEATURES[k][3]} for k, w in drivers[:3]]})
    return out


def rule_iforest(ctx, cfg) -> list[dict]:
    out = []
    for r in score_days_iforest(ctx, cfg):
        if r["score"] < cfg["min_score"] or not r["drivers"]:
            continue
        why = ", ".join(f"{d['label']} {d['value']:g}{'' if d['unit'] == '$' else ' ' + d['unit']} (usual {d['usual']:g})"
                        for d in r["drivers"][:2])
        out.append(alert("iforest_anomaly", cfg, fp=f"{r['cashier']}:{r['day']}", cashier=r["cashier"], ts=f"{r['day']}T23:58:00",
                         severity=min(5, cfg["severity"] + (1 if r["score"] >= cfg["min_score"] + 0.08 else 0)),
                         title=f"ML: {r['cashier']}'s shift on {r['day']} is an isolation-forest outlier "
                               f"(score {r['score']:.2f}) — {why}",
                         score=r["score"], drivers=r["drivers"], sales=r["sales"]))
    return out


# ------------------------------------------------------------------ model monitoring

def psi(base: list[float], recent: list[float], bins: int = 10) -> float:
    """Population stability index with quantile bins from the baseline.
    < 0.10 stable · 0.10–0.25 watch · > 0.25 significant shift."""
    if len(base) < 20 or len(recent) < 5:
        return 0.0
    b = sorted(base)
    edges = sorted({b[int(len(b) * i / bins)] for i in range(1, bins)})

    def dist(vals):
        counts = [0] * (len(edges) + 1)
        for v in vals:
            counts[sum(1 for e in edges if v > e)] += 1
        return [(c + 0.5) / (len(vals) + 0.5 * len(counts)) for c in counts]
    p, q = dist(base), dist(recent)
    return round(sum((qi - pi) * math.log(qi / pi) for pi, qi in zip(p, q, strict=True)), 4)


def model_health(conn, store: str, ctx, rules: dict, recent_days: int = 14) -> dict:
    prof = {k: v for k, v in day_profiles(ctx).items() if v["sales"] >= rules["ai_anomaly"]["min_sales"]}
    days = sorted({d for _, d in prof})
    if len(days) < recent_days + 7:
        return {"store": store, "ready": False, "days": len(days), "needed": recent_days + 7}
    cut = days[-recent_days]
    base = [v for (c, d), v in prof.items() if d < cut]
    recent = [v for (c, d), v in prof.items() if d >= cut]
    feats = []
    for k, (label, _direction, _, unit) in FEATURES.items():
        val = psi([x[k] for x in base], [x[k] for x in recent])
        bm, rm = statistics.median(x[k] for x in base), statistics.median(x[k] for x in recent)
        feats.append({"feature": k, "label": label, "unit": unit, "psi": val, "baseline_median": round(bm, 2), "recent_median": round(rm, 2),
                      "status": "drift" if val > 0.25 else "watch" if val > 0.10 else "stable"})
    feats.sort(key=lambda f: -f["psi"])

    # alert volume per day: baseline vs recent
    vol = defaultdict(int)
    for r in conn.execute("SELECT substr(ts,1,10) d, COUNT(*) n FROM alerts WHERE store=? AND rule NOT IN "
                          "('peer_outlier','low_cash_ratio','approver_concentration') GROUP BY d", (store,)):
        vol[r["d"]] = r["n"]
    bvol = [vol.get(d, 0) for d in days if d < cut]
    rvol = [vol.get(d, 0) for d in days if d >= cut]
    b_avg, r_avg = (sum(bvol) / len(bvol) if bvol else 0), (sum(rvol) / len(rvol) if rvol else 0)

    # agreement between the two models (top-decile cashier-days)
    z = {(r["cashier"], r["day"]): r["score"] for r in conn.execute("SELECT cashier, day, score FROM shift_anomaly WHERE store=?", (store,))}
    iso = {(r["cashier"], r["day"]): r["score"] for r in score_days_iforest(ctx, rules["iforest_anomaly"])}
    common = [k for k in iso if k in z]
    agree = None
    hist = [0] * 10
    if common:
        n = max(1, len(common) // 10)
        top_z = set(sorted(common, key=lambda k: -z[k])[:n])
        top_i = set(sorted(common, key=lambda k: -iso[k])[:n])
        agree = round(len(top_z & top_i) / len(top_z | top_i), 3)
        for k in common:
            hist[min(9, int(iso[k] * 10))] += 1
    rank = sorted(common, key=lambda k: -(iso[k] + z.get(k, 0) / 100))[:8]
    worst = max((f["psi"] for f in feats), default=0)
    return {
        "store": store, "ready": True, "baseline_days": len([d for d in days if d < cut]), "recent_days": recent_days,
        "rows": {"baseline": len(base), "recent": len(recent)}, "features": feats,
        "status": "drift" if worst > 0.25 else "watch" if worst > 0.10 else "stable",
        "alert_volume": {"baseline_per_day": round(b_avg, 2), "recent_per_day": round(r_avg, 2),
                         "change_pct": round((r_avg - b_avg) / b_avg * 100, 1) if b_avg else None},
        "agreement": agree, "iforest_histogram": hist,
        "both_models_top": [{"cashier": k[0], "day": k[1], "iforest": iso[k], "zscore": z.get(k)} for k in rank],
        "model_card": {
            "models": [{"id": "DG-020", "name": "Robust z-score vs self + team", "type": "statistical", "features": len(FEATURES)},
                       {"id": "DG-030", "name": "Isolation forest", "type": "unsupervised ensemble",
                        "trees": rules["iforest_anomaly"]["trees"], "sample": rules["iforest_anomaly"]["sample"],
                        "threshold": rules["iforest_anomaly"]["min_score"]}],
            "features": [{"key": k, "label": v[0], "direction": "higher is riskier" if v[1] > 0 else "lower is riskier", "unit": v[3]}
                         for k, v in FEATURES.items()],
            "training": "Unsupervised; refit on every detection run per store. No labels, no personal data beyond cashier name.",
            "limits": "Needs ≥30 cashier-days with ≥15 sales. Seasonal events and new menus shift the baseline (watch PSI).",
        },
    }
