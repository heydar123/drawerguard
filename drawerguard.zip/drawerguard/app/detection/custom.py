"""Custom detections: a small, safe rule language built in the UI (no code, no eval).

Definition (JSON):
{
  "match": [                                   # all conditions must be true (AND)
    {"field": "txn_type", "op": "in", "value": ["refund"]},
    {"field": "amount",   "op": ">=", "value": 50},
    {"field": "hour",     "op": "between", "value": [21, 23]}
  ],
  "aggregate": {"by": ["cashier", "day"], "count_gte": 3}    # optional; or "sum_gte": 100
}
Without "aggregate" every matching transaction becomes an alert. With it, one alert per
group that reaches the threshold. Everything is validated against allow-lists first.
"""
from collections import defaultdict

from .rules import alert

TYPES = ["sale", "refund", "void", "no_sale", "discount", "paid_out", "cancel"]
FIELDS = {
    "txn_type": "enum", "payment_method": "enum", "amount": "number", "discount_amount": "number",
    "hour": "number", "weekday": "number", "cashier": "text", "register": "text", "approved_by": "text",
    "note": "text", "order_id": "text",
}
ENUMS = {"txn_type": TYPES, "payment_method": ["cash", "card", "other", ""]}
OPS = {
    "number": {"==", "!=", ">", ">=", "<", "<=", "between", "in", "not_in"},
    "enum": {"==", "!=", "in", "not_in"},
    "text": {"==", "!=", "in", "not_in", "contains", "not_contains", "is_empty", "not_empty"},
}
GROUP_KEYS = {"cashier", "register", "day", "hour"}
MAX_CONDITIONS, MAX_ALERTS_PER_RUN = 12, 2000


class RuleError(ValueError):
    pass


def validate(defn: dict) -> dict:
    """Return a cleaned copy of the definition or raise RuleError with a friendly message."""
    if not isinstance(defn, dict):
        raise RuleError("Definition must be an object")
    match = defn.get("match") or []
    if not isinstance(match, list) or not match:
        raise RuleError("Add at least one condition")
    if len(match) > MAX_CONDITIONS:
        raise RuleError(f"At most {MAX_CONDITIONS} conditions")
    clean = []
    for c in match:
        f, op, v = c.get("field"), c.get("op"), c.get("value")
        if f not in FIELDS:
            raise RuleError(f"Unknown field: {f!r}")
        kind = FIELDS[f]
        if op not in OPS[kind]:
            raise RuleError(f"Operator {op!r} can't be used with {f}")
        if op in ("is_empty", "not_empty"):
            v = None
        elif op in ("in", "not_in"):
            if not isinstance(v, list) or not v or len(v) > 50:
                raise RuleError(f"{f} {op}: give a list of 1–50 values")
            v = [float(x) for x in v] if kind == "number" else [str(x)[:100] for x in v]
        elif op == "between":
            if not isinstance(v, list) or len(v) != 2:
                raise RuleError(f"{f} between: give [low, high]")
            v = sorted(float(x) for x in v)
        elif kind == "number":
            try:
                v = float(v)
            except (TypeError, ValueError):
                raise RuleError(f"{f} needs a number") from None
        else:
            v = str(v or "")[:100]
        if kind == "enum":
            vals = v if isinstance(v, list) else [v]
            bad = [x for x in vals if x not in ENUMS[f]]
            if bad:
                raise RuleError(f"{f} can only be one of {ENUMS[f]}")
        clean.append({"field": f, "op": op, "value": v})
    agg = defn.get("aggregate")
    if agg:
        by = [k for k in (agg.get("by") or []) if k in GROUP_KEYS]
        if "day" not in by and "hour" not in by:
            raise RuleError("Group by must include 'day' (thresholds are per day)")
        if "cashier" not in by and "register" not in by:
            by = ["cashier", *by]
        cnt, tot = agg.get("count_gte"), agg.get("sum_gte")
        if not cnt and not tot:
            raise RuleError("Set a count or a $ total threshold")
        agg = {"by": by, "count_gte": int(cnt) if cnt else None, "sum_gte": float(tot) if tot else None}
        if agg["count_gte"] is not None and agg["count_gte"] < 1:
            raise RuleError("Count threshold must be at least 1")
    return {"match": clean, "aggregate": agg or None}


def _value(t: dict, field: str):
    if field == "hour":
        return t["_dt"].hour
    if field == "weekday":
        return t["_dt"].weekday()
    return t.get(field) if t.get(field) is not None else ""


def _test(c: dict, t: dict) -> bool:
    x, op, v = _value(t, c["field"]), c["op"], c["value"]
    if FIELDS[c["field"]] == "text":
        x = str(x).lower()
        v = [s.lower() for s in v] if isinstance(v, list) else (v.lower() if isinstance(v, str) else v)
    if op == "==":
        return x == v
    if op == "!=":
        return x != v
    if op == ">":
        return x > v
    if op == ">=":
        return x >= v
    if op == "<":
        return x < v
    if op == "<=":
        return x <= v
    if op == "between":
        return v[0] <= x <= v[1]
    if op == "in":
        return x in v
    if op == "not_in":
        return x not in v
    if op == "contains":
        return v in x
    if op == "not_contains":
        return v not in x
    if op == "is_empty":
        return x in ("", None)
    if op == "not_empty":
        return x not in ("", None)
    return False


def evaluate(ctx, rule: dict) -> list[dict]:
    """rule = {"id", "name", "severity", "definition"(validated)}"""
    d = rule["definition"]
    key = f"custom:{rule['id']}"
    cfg = {"severity": int(rule.get("severity") or 3)}
    hits = [t for t in ctx.txns if all(_test(c, t) for c in d["match"])]
    out = []
    if not d.get("aggregate"):
        for t in hits[-MAX_ALERTS_PER_RUN:]:
            what = t["txn_type"].replace("_", " ")
            out.append(alert(key, cfg, fp=t["id"], cashier=t["cashier"], register=t["register"], ts=t["ts"], txn_id=t["id"],
                             amount=t["amount"], title=f"{rule['name']}: {what} ${t['amount']:,.2f} by {t['cashier']}",
                             custom_rule=rule["name"]))
        return out
    agg = d["aggregate"]
    groups = defaultdict(list)
    for t in hits:
        k = tuple(t["ts"][:10] if g == "day" else t["_dt"].hour if g == "hour" else t.get(g, "") for g in agg["by"])
        groups[k].append(t)
    for k, items in groups.items():
        total = sum(x["amount"] for x in items)
        if (agg["count_gte"] and len(items) < agg["count_gte"]) or (agg["sum_gte"] and total < agg["sum_gte"]):
            continue
        label = ", ".join(f"{g} {v}" for g, v in zip(agg["by"], k, strict=True))
        who = dict(zip(agg["by"], k, strict=True))
        out.append(alert(key, cfg, fp=":".join(map(str, k)), cashier=who.get("cashier") or items[0]["cashier"],
                         register=who.get("register") or items[0]["register"], ts=items[-1]["ts"], amount=total,
                         title=f"{rule['name']}: {len(items)} matching events (${total:,.2f}) for {label}",
                         custom_rule=rule["name"], count=len(items), receipts=[x["id"] for x in items[:20]]))
    return out[:MAX_ALERTS_PER_RUN]


def describe(defn: dict) -> str:
    """Plain-English summary, e.g. for the rules list and Sigma descriptions."""
    parts = []
    for c in defn["match"]:
        v = c["value"]
        v = " and ".join(map(str, v)) if c["op"] == "between" else (", ".join(map(str, v)) if isinstance(v, list) else v)
        parts.append(f"{c['field']} {c['op'].replace('_', ' ')} {'' if v is None else v}".strip())
    s = "Every transaction where " + " AND ".join(parts)
    a = defn.get("aggregate")
    if a:
        th = [f"at least {a['count_gte']} events" if a.get("count_gte") else "", f"total ≥ ${a['sum_gte']:,.0f}" if a.get("sum_gte") else ""]
        s = f"{s}, grouped by {' + '.join(a['by'])}, alert when {' and '.join(x for x in th if x)}"
    return s
