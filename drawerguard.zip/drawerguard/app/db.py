"""SQLite storage layer for DrawerGuard (schema v6: multi-store, users, cases, evidence, cameras, timeclock, deception)."""
import hashlib
import json
import os
import sqlite3
import threading
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = os.environ.get("DRAWERGUARD_DB", str(ROOT / "drawerguard.db"))
DATA_DIR = Path(os.environ.get("DRAWERGUARD_DATA", str(Path(DB_PATH).resolve().parent / "data")))
SCHEMA_VERSION = 6
_audit_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS stores (
    id          TEXT PRIMARY KEY,            -- short slug, e.g. 'main', 'harbor'
    name        TEXT NOT NULL,
    address     TEXT DEFAULT '',
    open_hour   INTEGER,                     -- overrides off-hours rule for this store
    close_hour  INTEGER,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transactions (
    store           TEXT NOT NULL DEFAULT 'main',
    id              TEXT NOT NULL,
    ts              TEXT NOT NULL,
    cashier         TEXT NOT NULL,
    register        TEXT DEFAULT '',
    txn_type        TEXT NOT NULL,           -- sale | refund | void | no_sale | discount | paid_out | cancel
    amount          REAL DEFAULT 0,
    payment_method  TEXT DEFAULT '',
    order_id        TEXT DEFAULT '',
    original_txn_id TEXT DEFAULT '',
    discount_amount REAL DEFAULT 0,
    approved_by     TEXT DEFAULT '',
    sent_to_kitchen INTEGER DEFAULT 0,
    note            TEXT DEFAULT '',
    source          TEXT DEFAULT 'csv',
    imported_at     TEXT DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (store, id)
);
CREATE INDEX IF NOT EXISTS ix_txn_ts ON transactions(ts);
CREATE INDEX IF NOT EXISTS ix_txn_cashier ON transactions(cashier);
CREATE INDEX IF NOT EXISTS ix_txn_order ON transactions(store, order_id);

CREATE TABLE IF NOT EXISTS shifts (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    store          TEXT NOT NULL DEFAULT 'main',
    cashier        TEXT NOT NULL,
    register       TEXT DEFAULT '',
    start_ts       TEXT NOT NULL,
    end_ts         TEXT NOT NULL,
    opening_float  REAL DEFAULT 0,
    expected_cash  REAL,
    counted_cash   REAL,
    UNIQUE(store, cashier, register, start_ts)
);

CREATE TABLE IF NOT EXISTS alerts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    fingerprint TEXT UNIQUE NOT NULL,
    store       TEXT NOT NULL DEFAULT 'main',
    rule        TEXT NOT NULL,
    severity    INTEGER NOT NULL,
    cashier     TEXT,
    register    TEXT,
    ts          TEXT,
    txn_id      TEXT,
    amount      REAL DEFAULT 0,
    title       TEXT NOT NULL,
    details     TEXT DEFAULT '{}',
    status      TEXT DEFAULT 'open',         -- open | investigating | dismissed | confirmed
    notes       TEXT DEFAULT '',
    case_id     INTEGER,
    assigned_to TEXT,                        -- analyst who owns the alert
    due_at      TEXT,                        -- SLA deadline (UTC), from severity
    acked_at    TEXT,                        -- first moved out of 'open'
    resolved_at TEXT,                        -- confirmed or dismissed
    suppressed_by INTEGER,                   -- suppression rule that auto-closed it
    tags        TEXT DEFAULT '',
    notified    INTEGER DEFAULT 0,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_alert_cashier ON alerts(cashier);
CREATE INDEX IF NOT EXISTS ix_alert_status ON alerts(status);
CREATE INDEX IF NOT EXISTS ix_alert_store ON alerts(store);
CREATE INDEX IF NOT EXISTS ix_alert_assignee ON alerts(assigned_to);

CREATE TABLE IF NOT EXISTS alert_history (       -- every change to an alert (who, what, when)
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id   INTEGER NOT NULL,
    actor      TEXT,
    field      TEXT,                              -- status | assigned_to | notes | case | tag
    old        TEXT,
    new        TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_hist_alert ON alert_history(alert_id);

CREATE TABLE IF NOT EXISTS suppressions (        -- allow-list / tuning exceptions with expiry
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    store      TEXT DEFAULT '*',
    rule       TEXT DEFAULT '*',
    cashier    TEXT DEFAULT '*',
    register   TEXT DEFAULT '*',
    reason     TEXT NOT NULL,
    expires_at TEXT,                              -- YYYY-MM-DD (inclusive); NULL = never
    active     INTEGER DEFAULT 1,
    hits       INTEGER DEFAULT 0,
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS automations (         -- SOAR-lite playbooks run on every new alert
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    enabled    INTEGER DEFAULT 1,
    conditions TEXT NOT NULL,                     -- JSON {rules, min_severity, stores, cashiers}
    actions    TEXT NOT NULL,                     -- JSON {assign_to, set_status, add_to_case, notify, tag}
    runs       INTEGER DEFAULT 0,
    last_run   TEXT,
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS custom_rules (        -- no-code detections built in the UI
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    description TEXT DEFAULT '',
    enabled    INTEGER DEFAULT 1,
    severity   INTEGER DEFAULT 3,
    definition TEXT NOT NULL,                     -- JSON DSL (validated, never eval'd)
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS hunts (               -- saved threat-hunting queries
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    description TEXT DEFAULT '',
    sql         TEXT NOT NULL,
    created_by  TEXT,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    last_run    TEXT,
    last_rows   INTEGER
);

CREATE TABLE IF NOT EXISTS login_events (        -- authentication telemetry for the Security center
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT,
    ip          TEXT,
    user_agent  TEXT,
    success     INTEGER,
    reason      TEXT DEFAULT '',
    new_device  INTEGER DEFAULT 0,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS ix_login_user ON login_events(username);

CREATE TABLE IF NOT EXISTS api_keys (            -- machine access (ingest / read), stored hashed
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    prefix     TEXT NOT NULL,
    key_hash   TEXT NOT NULL,
    scopes     TEXT DEFAULT '["ingest"]',
    stores     TEXT DEFAULT '["*"]',
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    last_used  TEXT,
    uses       INTEGER DEFAULT 0,
    revoked    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS shift_anomaly (       -- AI score per cashier per day
    store    TEXT NOT NULL,
    cashier  TEXT NOT NULL,
    day      TEXT NOT NULL,
    score    REAL NOT NULL,
    drivers  TEXT DEFAULT '[]',
    PRIMARY KEY (store, cashier, day)
);

CREATE TABLE IF NOT EXISTS users (
    username    TEXT PRIMARY KEY,
    pw_hash     TEXT NOT NULL,
    role        TEXT NOT NULL,                -- owner | manager | auditor
    stores      TEXT DEFAULT '["*"]',         -- JSON list of store ids, or ["*"]
    full_name   TEXT DEFAULT '',
    totp_secret TEXT,                         -- base32; set when 2FA is turned on
    totp_last   INTEGER DEFAULT 0,            -- last accepted time-step (blocks code replay)
    session_epoch INTEGER DEFAULT 0,          -- bump to sign out every device
    active      INTEGER DEFAULT 1,
    last_login  TEXT,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cameras (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    store          TEXT NOT NULL,
    register       TEXT DEFAULT '',           -- till this camera covers ('' = whole store)
    name           TEXT NOT NULL,
    url_template   TEXT DEFAULT '',           -- DVR/NVR playback link with {start} {end} ...
    offset_seconds INTEGER DEFAULT 0          -- DVR clock minus POS clock
);

CREATE TABLE IF NOT EXISTS cases (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    store       TEXT NOT NULL,
    cashier     TEXT NOT NULL,
    title       TEXT NOT NULL,
    status      TEXT DEFAULT 'open',          -- open | closed_theft | closed_cleared
    phase       TEXT DEFAULT 'detection',     -- NIST 800-61: detection | containment | eradication | recovery | post_incident
    ir          TEXT DEFAULT '{}',            -- incident-response record: checklist, root cause, lessons, phase times
    outcome     TEXT DEFAULT '',
    loss_amount REAL DEFAULT 0,
    recovered   REAL DEFAULT 0,
    created_by  TEXT,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS case_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id    INTEGER NOT NULL,
    author     TEXT,
    kind       TEXT DEFAULT 'note',           -- note | status | alert | evidence
    body       TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evidence (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    alert_id    INTEGER,
    case_id     INTEGER,
    filename    TEXT NOT NULL,
    stored_name TEXT NOT NULL,
    mime        TEXT,
    size        INTEGER,
    note        TEXT DEFAULT '',
    uploaded_by TEXT,
    sha256      TEXT,                         -- chain of custody: hash taken at upload
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    kind         TEXT,                        -- daily | weekly | custom
    store        TEXT DEFAULT '',
    period_start TEXT,
    period_end   TEXT,
    file         TEXT,
    headline     TEXT DEFAULT '',
    emailed      INTEGER DEFAULT 0,
    created_by   TEXT,
    created_at   TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS timeclock (            -- staff clock-in / clock-out punches (payroll fraud)
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    store         TEXT NOT NULL DEFAULT 'main',
    employee      TEXT NOT NULL,
    clock_in      TEXT NOT NULL,
    clock_out     TEXT,
    device        TEXT DEFAULT '',            -- time clock / terminal used for the punch
    method        TEXT DEFAULT '',            -- pin | badge | manager | app
    edited_by     TEXT DEFAULT '',            -- who manually changed the punch
    edit_note     TEXT DEFAULT '',
    minutes_added REAL DEFAULT 0,             -- paid minutes added by the edit
    hourly_rate   REAL,
    source        TEXT DEFAULT 'csv',
    UNIQUE(store, employee, clock_in)
);
CREATE INDEX IF NOT EXISTS ix_tc_store ON timeclock(store, clock_in);

CREATE TABLE IF NOT EXISTS canaries (             -- honeytokens: values nobody should ever use
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    store      TEXT DEFAULT '',                   -- '' = every store
    kind       TEXT NOT NULL,                     -- approver | employee | order | till | note
    value      TEXT NOT NULL,
    note       TEXT DEFAULT '',                   -- where it was planted
    enabled    INTEGER DEFAULT 1,
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(store, kind, value)
);

CREATE TABLE IF NOT EXISTS watchlist (             -- cashiers under closer watch (containment)
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    store      TEXT NOT NULL,
    cashier    TEXT NOT NULL,
    reason     TEXT NOT NULL,
    until      TEXT,                              -- YYYY-MM-DD, NULL = until removed
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(store, cashier)
);

CREATE TABLE IF NOT EXISTS external_refs (         -- tickets / alerts created in TheHive, Jira ...
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    system     TEXT NOT NULL,
    kind       TEXT NOT NULL,                     -- case | alert
    local_id   INTEGER NOT NULL,
    external_id TEXT,
    url        TEXT DEFAULT '',
    status     TEXT DEFAULT 'sent',
    detail     TEXT DEFAULT '',
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purple_runs (          -- purple-team simulation results
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    store      TEXT NOT NULL,
    created_by TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    params     TEXT DEFAULT '{}',
    results    TEXT DEFAULT '[]',
    coverage   REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS import_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    store       TEXT DEFAULT 'main',
    filename    TEXT,
    kind        TEXT,
    rows_read   INTEGER,
    rows_added  INTEGER,
    errors      TEXT DEFAULT '[]',
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_log (           -- tamper-evident: each row hashes the previous one
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    actor      TEXT,
    action     TEXT,
    target     TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    prev_hash  TEXT,
    hash       TEXT
);
"""


def connect(path: str | None = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


class ThreadLocalConnection:
    """One SQLite connection per thread behind a single shared object.

    FastAPI runs sync endpoints in a thread pool, and the dashboard fires several
    requests at once. Sharing one sqlite3 connection between threads can fail with
    "bad parameter or other API misuse"; giving every thread its own connection
    (WAL mode: many readers, one writer, busy timeout for the writer) is safe and
    keeps the `conn.execute(...)` style everywhere unchanged."""

    def __init__(self, path: str | None = None):
        self._path = path or DB_PATH
        self._local = threading.local()

    def _get(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = self._local.conn = connect(self._path)
        return c

    def __getattr__(self, name):
        return getattr(self._get(), name)


def _cols(conn, table) -> set[str]:
    return {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}


def _migrate_v1(conn) -> None:
    """Upgrade a v1 database (single store) in place, keeping all data."""
    tables = {r["name"] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "alerts" in tables and "store" not in _cols(conn, "alerts"):
        conn.execute("ALTER TABLE alerts ADD COLUMN store TEXT NOT NULL DEFAULT 'main'")
        conn.execute("UPDATE alerts SET fingerprint = 'main|' || fingerprint")   # v2 fingerprints are store-scoped
    if "alerts" in tables and "case_id" not in _cols(conn, "alerts"):
        conn.execute("ALTER TABLE alerts ADD COLUMN case_id INTEGER")
    for table, col, ddl in (("users", "totp_secret", "TEXT"), ("users", "totp_last", "INTEGER DEFAULT 0"),
                            ("users", "session_epoch", "INTEGER DEFAULT 0"),
                            ("audit_log", "prev_hash", "TEXT"), ("audit_log", "hash", "TEXT"),
                            ("alerts", "assigned_to", "TEXT"), ("alerts", "due_at", "TEXT"), ("alerts", "acked_at", "TEXT"),
                            ("alerts", "resolved_at", "TEXT"), ("alerts", "suppressed_by", "INTEGER"),
                            ("alerts", "tags", "TEXT DEFAULT ''"), ("evidence", "sha256", "TEXT"),
                            ("cases", "phase", "TEXT DEFAULT 'detection'"), ("cases", "ir", "TEXT DEFAULT '{}'")):
        if table in tables and col not in _cols(conn, table):
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    if "import_log" in tables and "store" not in _cols(conn, "import_log"):
        conn.execute("ALTER TABLE import_log ADD COLUMN store TEXT DEFAULT 'main'")
    if "transactions" in tables and "store" not in _cols(conn, "transactions"):
        conn.executescript("""
            ALTER TABLE transactions RENAME TO transactions_v1;
            ALTER TABLE shifts RENAME TO shifts_v1;
            DROP INDEX IF EXISTS ix_txn_ts; DROP INDEX IF EXISTS ix_txn_cashier; DROP INDEX IF EXISTS ix_txn_order;
        """)
        conn.executescript(SCHEMA)
        conn.executescript("""
            INSERT INTO transactions(store,id,ts,cashier,register,txn_type,amount,payment_method,order_id,original_txn_id,
                discount_amount,approved_by,sent_to_kitchen,note,source,imported_at)
              SELECT 'main',id,ts,cashier,register,txn_type,amount,payment_method,order_id,original_txn_id,
                discount_amount,approved_by,sent_to_kitchen,note,source,imported_at FROM transactions_v1;
            INSERT INTO shifts(store,cashier,register,start_ts,end_ts,opening_float,expected_cash,counted_cash)
              SELECT 'main',cashier,register,start_ts,end_ts,opening_float,expected_cash,counted_cash FROM shifts_v1;
            DROP TABLE transactions_v1; DROP TABLE shifts_v1;
        """)
    conn.commit()


def init_db(conn: sqlite3.Connection) -> None:
    _migrate_v1(conn)
    conn.executescript(SCHEMA)
    if not conn.execute("SELECT 1 FROM stores").fetchone():
        conn.execute("INSERT INTO stores(id, name) VALUES('main', 'Main store')")
    conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES('schema_version', ?)", (json.dumps(SCHEMA_VERSION),))
    conn.commit()
    backfill_audit_chain(conn)
    for sub in ("evidence", "reports", "backups"):
        (DATA_DIR / sub).mkdir(parents=True, exist_ok=True)


@contextmanager
def tx(conn: sqlite3.Connection):
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def rows(cur) -> list[dict]:
    return [dict(r) for r in cur.fetchall()]


def get_setting(conn, key: str, default=None):
    r = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(r["value"]) if r else default


def set_setting(conn, key: str, value) -> None:
    conn.execute(
        "INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(value)),
    )
    conn.commit()


GENESIS = "0" * 64


def _row_hash(prev: str, r) -> str:
    msg = "|".join(str(x if x is not None else "") for x in (prev, r["id"], r["created_at"], r["actor"], r["action"], r["target"]))
    return hashlib.sha256(msg.encode()).hexdigest()


def audit(conn, actor: str, action: str, target: str = "") -> None:
    """Append to the audit log. Every row stores the hash of the previous row, so
    any later edit or deletion breaks the chain and is caught by verify_audit()."""
    with _audit_lock:
        last = conn.execute("SELECT hash FROM audit_log WHERE hash IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()
        prev = last["hash"] if last else GENESIS
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        cur = conn.execute("INSERT INTO audit_log(actor, action, target, created_at, prev_hash) VALUES(?,?,?,?,?)",
                           (actor, action, (target or "")[:500], now, prev))
        r = conn.execute("SELECT * FROM audit_log WHERE id=?", (cur.lastrowid,)).fetchone()
        conn.execute("UPDATE audit_log SET hash=? WHERE id=?", (_row_hash(prev, r), r["id"]))
        conn.commit()


def backfill_audit_chain(conn) -> None:
    """Hash any rows written before the chain existed (upgrade from older versions)."""
    rows_ = conn.execute("SELECT * FROM audit_log ORDER BY id").fetchall()
    if not rows_ or all(r["hash"] for r in rows_):
        return
    prev = GENESIS
    for r in rows_:
        h = _row_hash(prev, r)
        conn.execute("UPDATE audit_log SET prev_hash=?, hash=? WHERE id=?", (prev, h, r["id"]))
        prev = h
    conn.commit()


def verify_audit(conn) -> dict:
    prev, n = GENESIS, 0
    for r in conn.execute("SELECT * FROM audit_log ORDER BY id"):
        n += 1
        if r["prev_hash"] != prev or r["hash"] != _row_hash(prev, r):
            return {"ok": False, "entries": n, "broken_at": r["id"],
                    "message": f"Audit log entry #{r['id']} was changed, or an entry before it was deleted."}
        prev = r["hash"]
    return {"ok": True, "entries": n, "head": prev, "message": f"All {n} entries verified. The chain is intact."}
