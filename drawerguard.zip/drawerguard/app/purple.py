"""Purple-team simulator: attack your own detections.

Like Atomic Red Team, but for a till. Each scenario is a known POS or payroll fraud
technique. The simulator:

  1. clones a low-risk cashier from the real store data into a synthetic
     "Red Team" cashier (own till, same habits: a realistic baseline),
  2. runs detection on the clone with no attack (control run) to learn its noise,
  3. injects the attack into the clone's last N days at the chosen intensity,
  4. runs detection again and keeps only alerts that are NEW versus the control.

Everything happens in memory: nothing is written to the transactions or alerts
tables, so it is safe to run on live data. The result is a coverage matrix
(scenario × detection), time to detect, simulated loss, and the gaps: the
detections that should have fired and didn't.
"""
import random
from collections import defaultdict
from datetime import datetime, timedelta

from .config import merged_rules
from .db import get_setting, rows
from .detection.catalog import ACFE, meta
from .detection.engine import cashier_scores, detect_store, load_custom_rules, store_rules
from .detection.rules import Context

ATK = "Red Team"
ACCOMPLICE = "RT Manager"


class Sim:
    def __init__(self, txns, shifts, punches, days, rng, k, close_hour):
        self.txns, self.shifts, self.punches = txns, shifts, punches
        self.days, self.r, self.k, self.close_hour = days, rng, k, close_hour
        self.loss, self.events, self.n = 0.0, 0, 0
        self.window = days
        self.others: list[dict] = []          # timeclock rows of other staff (for payroll scenarios)
        self.canaries: list[dict] = []        # planted honeytokens (for the deception scenario)
        self.day_reg = {}
        for t in txns:
            if t["cashier"] == ATK:
                self.day_reg.setdefault(t["ts"][:10], t["register"])

    def on(self, day, typ=None, cash=None):
        return [t for t in self.txns if t["ts"][:10] == day and t["cashier"] == ATK and (typ is None or t["txn_type"] == typ)
                and (cash is None or (t["payment_method"] == "cash") == cash)]

    def n_per_day(self, base):
        x = base * self.k
        return int(x) + (1 if self.r.random() < x - int(x) else 0)

    def add(self, ts, typ, amount=0.0, pay="", order="", orig="", appr="", disc=0.0, kitchen=0, note="", register=None):
        self.n += 1
        t = {"store": "", "id": f"RTX{self.n}", "ts": ts, "cashier": ATK, "register": register or self.day_reg.get(ts[:10], "RT Till"),
             "txn_type": typ,
             "amount": round(amount, 2), "payment_method": pay, "order_id": order, "original_txn_id": orig,
             "discount_amount": round(disc, 2), "approved_by": appr, "sent_to_kitchen": kitchen, "note": note}
        self.txns.append(t)
        self.events += 1
        return t

    def shift(self, day):
        return next((s for s in self.shifts if s["cashier"] == ATK and s["start_ts"][:10] == day), None)

    def punch(self, day):
        return next((p for p in self.punches if p["employee"] == ATK and p["clock_in"][:10] == day), None)

    def short(self, day, amount):
        s = self.shift(day)
        if s and s.get("counted_cash") is not None:
            s["counted_cash"] = round(s["counted_cash"] - amount, 2)

    @staticmethod
    def later(ts, seconds):
        return (datetime.fromisoformat(ts) + timedelta(seconds=seconds)).isoformat(timespec="seconds")


# ------------------------------------------------------------------ techniques

def skim_unrung(s: Sim):
    for d in s.days:
        cash = s.on(d, "sale", True)
        for t in s.r.sample(cash, min(len(cash), s.n_per_day(2))):
            s.txns.remove(t)
            s.loss += t["amount"]
            if s.r.random() < 0.6:
                s.add(t["ts"], "no_sale")


def nosale_after_cash(s: Sim):
    for d in s.days:
        cash = s.on(d, "sale", True)
        for t in s.r.sample(cash, min(len(cash), s.n_per_day(2))):
            s.add(s.later(t["ts"], s.r.randint(20, 90)), "no_sale")
            s.short(d, 10)
            s.loss += 10


def drawer_grab(s: Sim):
    for d in s.days:
        sh = s.shift(d)
        if not sh:
            continue
        start, end = datetime.fromisoformat(sh["start_ts"]), datetime.fromisoformat(sh["end_ts"])
        busy = sorted([start] + [datetime.fromisoformat(t["ts"]) for t in s.on(d)] + [end])
        gaps = sorted(((b - a, a) for a, b in zip(busy, busy[1:], strict=False)), reverse=True)
        for gap, a in gaps[:s.n_per_day(1)]:           # the quietest moments of the shift
            s.add((a + gap / 2).isoformat(timespec="seconds"), "no_sale")
        amt = 20 * max(1, round(s.k))
        s.short(d, amt)
        s.loss += amt


def blind_refund(s: Sim):
    for d in s.days:
        sales = s.on(d, "sale")
        for t in s.r.sample(sales, min(len(sales), s.n_per_day(1))):
            v = s.r.choice([15, 20, 25, 30])
            s.add(s.later(t["ts"], 90), "refund", v, "cash", note="Customer complaint")
            s.loss += v


def card_to_cash(s: Sim):
    for d in s.days:
        cards = [t for t in s.on(d, "sale", False) if t["amount"] > 8]
        for t in s.r.sample(cards, min(len(cards), s.n_per_day(1))):
            s.add(s.later(t["ts"], s.r.randint(600, 3600)), "refund", t["amount"], "cash", t["order_id"], t["id"], appr=ACCOMPLICE)
            s.loss += t["amount"]


def refund_own_sale(s: Sim):
    for d in s.days:
        cash = s.on(d, "sale", True)
        for t in s.r.sample(cash, min(len(cash), s.n_per_day(1))):
            s.add(s.later(t["ts"], s.r.randint(180, 600)), "refund", t["amount"], "cash", t["order_id"], t["id"], appr="Sam (Manager)")
            s.loss += t["amount"]


def post_payment_void(s: Sim):
    for d in s.days:
        cash = [t for t in s.on(d, "sale", True) if t["amount"] >= 10]
        for t in s.r.sample(cash, min(len(cash), s.n_per_day(1))):
            v = round(t["amount"] * s.r.uniform(0.5, 0.9), 2)
            s.add(s.later(t["ts"], s.r.randint(120, 480)), "void", v, order=t["order_id"], note="Wrong item")
            s.loss += v


def sweetheart(s: Sim):
    for d in s.days:
        sales = [t for t in s.on(d, "sale") if t["amount"] > 8]
        for t in s.r.sample(sales, min(len(sales), s.n_per_day(2))):
            disc = round(t["amount"] * s.r.choice([0.6, 0.8, 1.0]), 2)
            t["discount_amount"], t["amount"], t["approved_by"] = disc, round(t["amount"] - disc, 2), ""
            s.loss += disc
            s.events += 1


def kitchen_cancel(s: Sim):
    for d in s.days:
        sales = s.on(d, "sale")
        for t in s.r.sample(sales, min(len(sales), s.n_per_day(1))):
            v = round(s.r.uniform(9, 30), 2)
            s.add(s.later(t["ts"], 420), "cancel", v, order=f"{t['order_id']}X", kitchen=1, note="Customer left")
            s.loss += v


def fake_paid_out(s: Sim):
    for i, d in enumerate(s.days):
        if i % 2:
            continue
        for t in s.on(d, "sale")[:s.n_per_day(1)]:
            s.add(s.later(t["ts"], 120), "paid_out", 40, "cash", note="Supplies")
            s.loss += 40


def after_hours(s: Sim):
    for i, d in enumerate(s.days):
        if i % 2 == 0:
            for _ in range(s.n_per_day(1)):
                s.add(f"{d}T{min(s.close_hour, 23):02d}:{s.r.randint(10, 50):02d}:00", "no_sale")
                s.loss += 20


def skip_count(s: Sim):
    for d in s.days:
        sh = s.shift(d)
        if sh and s.r.random() < min(1.0, 0.5 * s.k):
            sh["counted_cash"] = None
            s.loss += 25
            s.events += 1


def self_approve(s: Sim):
    for d in s.days:
        cash = s.on(d, "sale", True)
        for t in s.r.sample(cash, min(len(cash), s.n_per_day(1))):
            s.add(s.later(t["ts"], 300), "refund", t["amount"], "cash", t["order_id"], t["id"], appr=ATK)
            s.loss += t["amount"]


def collusion(s: Sim):
    for d in s.days:
        cash = [t for t in s.on(d, "sale", True) if t["amount"] > 6]
        if len(cash) < 4:
            continue
        for t in s.r.sample(cash[:-2], min(len(cash) - 2, s.n_per_day(2))):
            s.add(s.later(t["ts"], s.r.randint(2400, 5400)), "refund", t["amount"], "cash", t["order_id"], t["id"], appr=ACCOMPLICE,
                  note="Cold food")
            s.loss += t["amount"]


def low_and_slow(s: Sim):
    for i, d in enumerate(s.days):
        if i % 2:
            continue
        cash = [t for t in s.on(d, "sale", True) if t["amount"] < 7]
        if cash:
            t = s.r.choice(cash)
            s.txns.remove(t)
            s.loss += t["amount"]
            s.events += 1


def buddy_punch(s: Sim):
    work = defaultdict(set)
    for p in s.others:
        work[p["employee"]].add(p["clock_in"][:10])
    buddy = max(sorted(work), key=lambda e: len(work[e] & set(s.days)), default=None)   # the colleague they share most days with
    for d in s.days:
        me = s.punch(d)
        if not me or not buddy:
            continue
        mates = [p for p in s.others if p["clock_in"][:10] == d and p["employee"] == buddy]
        if mates:
            m = mates[0]
            late = s.r.randint(20, 45)
            m["clock_in"] = s.later(me["clock_in"], s.r.randint(5, 25))
            m["device"] = me["device"]
            s.loss += late / 60 * (m.get("hourly_rate") or 16)
            s.events += 1


def shared_login(s: Sim):
    for d in s.days:
        p = s.punch(d)
        if p and p.get("clock_out") and s.r.random() < min(1.0, 0.6 * s.k):
            p["clock_out"] = s.later(p["clock_out"], -s.r.randint(80, 120) * 60)
            s.events += 1


def ghost(s: Sim):
    for d in s.window:                      # the ghost "works" every weekday, not just the attacker's days
        if datetime.fromisoformat(d).weekday() >= 5:
            continue
        cin = f"{d}T10:0{s.r.randint(0, 9)}:00"
        s.punches.append({"store": "", "employee": "RT Ghost", "clock_in": cin, "clock_out": s.later(cin, 6.5 * 3600),
                          "device": "Office PC", "method": "manager", "edited_by": ACCOMPLICE, "edit_note": "", "minutes_added": 0,
                          "hourly_rate": 17.0})
        s.loss += 6.5 * 17
        s.events += 1


def timecard_inflation(s: Sim):
    for d in s.days:
        p = s.punch(d)
        if p and p.get("clock_out") and s.r.random() < min(1.0, 0.5 * s.k):
            add = s.r.randint(30, 75)
            p["clock_out"] = s.later(p["clock_out"], add * 60)
            p["edited_by"], p["edit_note"], p["minutes_added"] = ACCOMPLICE, "Forgot to clock out", add
            s.loss += add / 60 * (p.get("hourly_rate") or 16)
            s.events += 1


def canary_probe(s: Sim):
    """Insider reconnaissance: someone found the 'manager code' planted under the till and tries it."""
    c = next((x for x in s.canaries if x["kind"] == "approver"), None) or next((x for x in s.canaries if x["kind"] == "note"), None)
    for d in s.days[:2]:
        cash = s.on(d, "sale", True)
        if not cash or not c:
            continue
        t = cash[0]
        if c["kind"] == "approver":
            s.add(s.later(t["ts"], 600), "refund", t["amount"], "cash", t["order_id"], t["id"], appr=c["value"], note="Customer complaint")
        else:
            s.add(s.later(t["ts"], 600), "refund", t["amount"], "cash", t["order_id"], t["id"], appr="Sam (Manager)", note=c["value"])
        s.loss += t["amount"]


SCENARIOS = [
    # id, name, ACFE scheme key, what the attacker does, expected detections, needs timeclock
    ("T01", "Skim: unrung cash sale", "skim_unrecorded", skim_unrung,
     "Takes cash for a sale, never rings it, opens the drawer with No Sale.", ["no_sale_excess", "ai_anomaly", "iforest_anomaly"], False),
    ("T02", "Skim: No Sale after cash sale", "skim_unrecorded", nosale_after_cash,
     "Rings the sale, then re-opens the drawer seconds later to take the cash.", ["no_sale_after_cash"], False),
    ("T03", "Larceny: drawer grab", "larceny", drawer_grab,
     "Opens the drawer in the quietest moment of the shift and takes cash; drawer short at cash-up.",
     ["cash_shortage", "repeat_shortage"], False),
    ("T04", "False refund: no receipt", "false_refund", blind_refund,
     "Rings round-amount cash refunds with no original sale and no approval.", ["unmatched_refund", "round_amount_refund"], False),
    ("T05", "False refund: card sale refunded in cash", "false_refund", card_to_cash,
     "Customer paid by card; refund given in cash (to the cashier's pocket).", ["cash_refund_on_card_sale"], False),
    ("T06", "False refund: own sale", "false_refund", refund_own_sale,
     "Refunds their own cash sale minutes after the customer left.", ["refund_own_sale_quick"], False),
    ("T07", "False void: void after cash payment", "false_void", post_payment_void,
     "Customer pays cash in full; items are voided afterwards and the difference pocketed.", ["post_payment_void"], False),
    ("T08", "Sweethearting: big comps for friends", "skim_understated", sweetheart,
     "Gives 60–100% discounts to friends with no manager approval.", ["excess_discount"], False),
    ("T09", "Kitchen cancel after cooking", "skim_unrecorded", kitchen_cancel,
     "Order goes to the kitchen, is served and paid in cash, then cancelled.", ["cancel_after_kitchen"], False),
    ("T10", "Fake paid-out", "larceny", fake_paid_out,
     "Records a $40 'supplies' paid-out with no receipt and no approval.", ["paid_out", "unapproved_override"], False),
    ("T11", "After-hours drawer access", "larceny", after_hours,
     "Comes back after closing and opens the drawer.", ["off_hours"], False),
    ("T12", "Conceal: skip the cash count", "control", skip_count,
     "Closes shifts without counting the drawer so shortages don't show.", ["missing_count"], False),
    ("T13", "Control override: self-approved refunds", "control", self_approve,
     "Uses their own manager code to approve their refunds.", ["self_approved"], False),
    ("T14", "Collusion with a manager", "collusion", collusion,
     "Refunds earlier cash sales, always approved by the same complicit manager.", ["approver_concentration"], False),
    ("T15", "Low-and-slow skim", "skim_unrecorded", low_and_slow,
     "Skips ringing one small cash sale every other day. Designed to stay under thresholds.", [], False),
    ("T16", "Payroll: buddy punching", "payroll_hours", buddy_punch,
     "Clocks in a late colleague seconds after their own punch.", ["buddy_punch"], True),
    ("T17", "Access: shared login after clock-out", "access", shared_login,
     "Clocks out early; a colleague keeps selling under their login.", ["clocked_out_activity"], True),
    ("T18", "Payroll: ghost employee", "payroll_ghost", ghost,
     "A manager adds a fake employee and punches them in every weekday.", ["ghost_employee"], True),
    ("T19", "Payroll: timecard inflation", "payroll_hours", timecard_inflation,
     "A manager edits the attacker's clock-outs to add paid time.", ["timecard_edit"], True),
    ("T20", "Recon: tries the planted manager code", "deception", canary_probe,
     "Finds the 'manager override code' left under the till (a canary) and uses it to approve a refund.", ["canary"], "canary"),
]
BY_ID = {s[0]: s for s in SCENARIOS}


def catalog() -> list[dict]:
    return [{"id": sid, "name": name, "scheme": scheme, "acfe": ACFE.get(scheme, ""), "description": desc,
             "expected": [{"rule": r, "id": meta(r).get("id")} for r in exp], "needs_timeclock": tc is True,
             "needs_canary": tc == "canary"}
            for sid, name, scheme, _fn, desc, exp, tc in SCENARIOS]



def _host(conn, store):
    scores = [s for s in cashier_scores(conn, 0, [store]) if s["metrics"].get("txns", 0) >= 150]
    if not scores:
        raise ValueError("Need at least one cashier with 150+ transactions in this store to clone")
    scores.sort(key=lambda s: (s.get("payroll_alerts", 0) > 0, s["score"], -s["metrics"]["txns"]))   # cleanest baseline first
    return scores[0]["cashier"]


def _load(conn, store, days):
    latest = conn.execute("SELECT MAX(ts) m FROM transactions WHERE store=?", (store,)).fetchone()["m"]
    if not latest:
        raise ValueError("No transactions in this store")
    since = (datetime.fromisoformat(latest) - timedelta(days=days + 35)).isoformat()
    txns = rows(conn.execute("SELECT * FROM transactions WHERE store=? AND ts>=?", (store, since)))
    shifts = rows(conn.execute("SELECT * FROM shifts WHERE store=? AND start_ts>=?", (store, since)))
    tc = rows(conn.execute("SELECT * FROM timeclock WHERE store=? AND clock_in>=?", (store, since)))
    return latest, txns, shifts, tc


def _clone(host, txns, shifts, tc):
    ct = []
    for t in txns:
        if t["cashier"] == host:
            c = dict(t, cashier=ATK, id=f"RT-{t['id']}", register=f"RT {t['register'] or 'Till'}",
                     order_id=f"RT{t['order_id']}" if t["order_id"] else "", original_txn_id=f"RT-{t['original_txn_id']}" if t["original_txn_id"] else "")
            if c["approved_by"] == host:
                c["approved_by"] = ATK
            ct.append(c)
    cs = [dict(s, cashier=ATK, register=f"RT {s['register'] or 'Till'}") for s in shifts if s["cashier"] == host]
    cp = []
    for p in tc:
        if p["employee"] == host and not p.get("edited_by"):
            shift = timedelta(minutes=7)
            cp.append(dict(p, employee=ATK, clock_in=(datetime.fromisoformat(p["clock_in"]) - shift).isoformat(timespec="seconds"),
                           clock_out=(datetime.fromisoformat(p["clock_out"]) + shift).isoformat(timespec="seconds") if p["clock_out"] else None))
    return ct, cs, cp


def _ctx(txns, shifts, tc):
    return Context([dict(t) for t in txns], [dict(s) for s in shifts], [dict(p) for p in tc])


def run(conn, store: str, scenario_ids: list[str] | None = None, intensity: float = 1.0, days: int = 14, seed: int = 7) -> dict:
    st = conn.execute("SELECT * FROM stores WHERE id=?", (store,)).fetchone()
    rules = store_rules(merged_rules(get_setting(conn, "rules", {})), dict(st) if st else {})
    custom = load_custom_rules(conn)
    host = _host(conn, store)
    latest, txns, shifts, tc = _load(conn, store, days)
    ct, cs, cp = _clone(host, txns, shifts, tc)
    base_t, base_s, base_p = txns + ct, shifts + cs, tc + cp
    cutoff = (datetime.fromisoformat(latest) - timedelta(days=days)).strftime("%Y-%m-%d")
    attack_days = sorted({t["ts"][:10] for t in ct if t["ts"][:10] > cutoff})
    window = sorted({t["ts"][:10] for t in txns if t["ts"][:10] > cutoff})
    if not attack_days:
        raise ValueError(f"{host} has no shifts in the last {days} days to attack")

    def atk_alerts(ctx):
        return {a["fingerprint"]: a for a in detect_store(conn, store, rules, custom, persist_ai=False, ctx=ctx)
                if a.get("cashier") in (ATK, "RT Ghost") or (a.get("details") and '"partner": "Red Team"' in a["details"])}

    from .detection.deception import load_canaries
    canaries = load_canaries(conn, store)
    control = atk_alerts(_ctx(base_t, base_s, base_p))
    results = []
    for sid in scenario_ids or [s[0] for s in SCENARIOS]:
        if sid not in BY_ID:
            continue
        _, name, scheme, fn, desc, expected, needs_tc = BY_ID[sid]
        res = {"id": sid, "name": name, "scheme": scheme, "description": desc,
               "expected": [{"rule": r, "id": meta(r).get("id")} for r in expected]}
        if needs_tc is True and not cp:
            results.append({**res, "status": "skipped", "reason": "No timeclock data for this store"})
            continue
        if needs_tc == "canary" and not canaries:
            results.append({**res, "status": "skipped", "reason": "No canaries configured (add one on the Canaries & watchlist page)"})
            continue
        t2 = [dict(t) for t in base_t]
        s2 = [dict(s) for s in base_s]
        p2 = [dict(p) for p in base_p]
        # reproducible simulation, not security
        rng = random.Random(f"{seed}:{sid}")  # noqa: S311  # nosec B311
        sim = Sim(t2, s2, p2, attack_days, rng, intensity, rules["off_hours"]["close_hour"])
        sim.others = [p for p in p2 if p["employee"] != ATK]
        sim.canaries = canaries
        sim.window = window
        fn(sim)
        new = [a for fp, a in atk_alerts(Context(t2, s2, p2)).items() if fp not in control]
        fired = defaultdict(lambda: {"count": 0, "max_severity": 0, "first": None})
        for a in new:
            f = fired[a["rule"]]
            f["count"] += 1
            f["max_severity"] = max(f["max_severity"], a["severity"])
            f["first"] = min(f["first"] or "9999", (a["ts"] or "9999")[:10])
        strong = [a for a in new if a["severity"] >= 3]
        first = min(((a["ts"] or "")[:10] for a in strong if a["rule"] not in ("peer_outlier", "low_cash_ratio")),
                    default=None)
        ttd = (datetime.fromisoformat(first) - datetime.fromisoformat(attack_days[0])).days if first else None
        exp_ids = set(expected)
        results.append({**res, "status": "detected" if strong else "weak" if new else "missed",
                        "fired": [{"rule": r, "id": meta(r).get("id"), **v, "expected": r in exp_ids} for r, v in
                                  sorted(fired.items(), key=lambda kv: meta(kv[0]).get("id", ""))],
                        "missing_expected": [{"rule": r, "id": meta(r).get("id")} for r in expected if r not in fired],
                        "alerts": len(new), "days_to_detect": ttd, "events": sim.events, "simulated_loss": round(sim.loss, 2)})
    ran = [r for r in results if r["status"] != "skipped"]
    detected = sum(1 for r in ran if r["status"] == "detected")
    exp_total = sum(len(r["expected"]) for r in ran)
    exp_hit = sum(len(r["expected"]) - len(r["missing_expected"]) for r in ran)
    caught_loss = sum(r["simulated_loss"] for r in ran if r["status"] == "detected")
    total_loss = sum(r["simulated_loss"] for r in ran)
    ttds = sorted(r["days_to_detect"] for r in ran if r["days_to_detect"] is not None)
    return {
        "store": store, "host": host, "attacker": ATK, "days": days, "intensity": intensity, "attack_days": len(attack_days),
        "window": [attack_days[0], attack_days[-1]], "control_alerts": len(control),
        "summary": {"scenarios": len(ran), "detected": detected, "weak": sum(1 for r in ran if r["status"] == "weak"),
                    "missed": sum(1 for r in ran if r["status"] == "missed"),
                    "coverage": round(detected / len(ran), 3) if ran else 0,
                    "expected_coverage": round(exp_hit / exp_total, 3) if exp_total else 0,
                    "loss_simulated": round(total_loss, 2), "loss_in_detected": round(caught_loss, 2),
                    "median_days_to_detect": ttds[len(ttds) // 2] if ttds else None},
        "results": results,
    }


def sweep(conn, store: str, scenario_id: str, days: int = 14) -> list[dict]:
    """Run one scenario at increasing intensity to find the smallest attack that gets caught."""
    out = []
    for k in (0.25, 0.5, 1.0, 2.0):
        r = run(conn, store, [scenario_id], k, days)["results"][0]
        out.append({"intensity": k, "status": r["status"], "alerts": r.get("alerts", 0), "loss": r.get("simulated_loss", 0),
                    "loss_per_week": round(r.get("simulated_loss", 0) / max(days, 1) * 7, 2), "days_to_detect": r.get("days_to_detect")})
    return out
