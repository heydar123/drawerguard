"""Forensic accounting analytics used by fraud examiners:

* Benford's law first-digit test (Nigrini MAD conformity thresholds), against Benford and
  against the rest of the team, which matters more for menu-priced data
* round-number and repeated-amount analysis (made-up refunds tend to be round and repeated)
* when risky events happen (cashier × hour)
* approver ↔ cashier network for spotting collusion
* team risk heatmap (cashier × day) from AI scores and high-severity alerts
"""
import math
import statistics
from collections import Counter, defaultdict

BENFORD = {d: math.log10(1 + 1 / d) for d in range(1, 10)}
# Nigrini (2012), first-digit test: mean absolute deviation thresholds
NIGRINI = [(0.006, "close conformity"), (0.012, "acceptable conformity"), (0.015, "marginal conformity"), (9e9, "nonconformity")]
TYPES = ("refund", "void", "paid_out", "discount", "sale", "cancel")


def first_digit(x: float) -> int | None:
    x = abs(float(x or 0))
    if x <= 0 or math.isinf(x) or math.isnan(x):
        return None
    while x < 1:
        x *= 10
    while x >= 10:
        x /= 10
    return int(x)


def digit_dist(values) -> tuple[dict[int, int], int]:
    c = Counter(d for d in (first_digit(v) for v in values) if d)
    return {d: c.get(d, 0) for d in range(1, 10)}, sum(c.values())


def mad(counts: dict[int, int], n: int, expected: dict[int, float]) -> float | None:
    if not n:
        return None
    return sum(abs(counts[d] / n - expected[d]) for d in range(1, 10)) / 9


def conformity(m: float | None) -> str:
    if m is None:
        return "not enough data"
    return next(label for lim, label in NIGRINI if m <= lim)


def chi_square(counts, n, expected) -> float:
    return sum((counts[d] - n * expected[d]) ** 2 / (n * expected[d]) for d in range(1, 10) if expected[d] > 0) if n else 0.0


def _amounts(conn, stores, since, txn_type):
    q = f"SELECT cashier, amount, discount_amount, txn_type FROM transactions WHERE store IN ({','.join('?' * len(stores))})"
    p = list(stores)
    if since:
        q += " AND ts >= ?"
        p.append(since)
    by = defaultdict(list)
    for r in conn.execute(q, p):
        if txn_type == "discount":
            v = r["amount"] if r["txn_type"] == "discount" else (r["discount_amount"] if r["txn_type"] == "sale" else 0)
        else:
            v = r["amount"] if r["txn_type"] == txn_type else 0
        if v and v > 0:
            by[r["cashier"]].append(round(v, 2))
    return by


def benford(conn, stores, since, txn_type: str = "refund", min_n: int = 20) -> dict:
    by = _amounts(conn, stores, since, txn_type)
    all_vals = [v for vs in by.values() for v in vs]
    counts, n = digit_dist(all_vals)
    overall_mad = mad(counts, n, BENFORD)
    cashiers = []
    for c, vals in by.items():
        cc, cn = digit_dist(vals)
        if cn < min_n:
            continue
        others = [v for k, vs in by.items() if k != c for v in vs]
        oc, on = digit_dist(others)
        team_exp = {d: (oc[d] + 0.5) / (on + 4.5) for d in range(1, 10)} if on else BENFORD   # smoothed team distribution
        m_b, m_t = mad(cc, cn, BENFORD), mad(cc, cn, team_exp)
        cashiers.append({"cashier": c, "n": cn, "mad_benford": round(m_b, 4), "conformity": conformity(m_b),
                         "mad_team": round(m_t, 4), "chi2_team": round(chi_square(cc, cn, team_exp), 1),
                         "dist": {d: round(cc[d] / cn, 4) for d in range(1, 10)}})
    cashiers.sort(key=lambda x: -x["mad_team"])
    if len(cashiers) >= 3:
        vals = [x["mad_team"] for x in cashiers]
        med = statistics.median(vals)
        spread = statistics.median(abs(v - med) for v in vals) * 1.4826 or 0.01
        for x in cashiers:
            x["outlier"] = (x["mad_team"] - med) / spread >= 3 and x["n"] >= 30
    return {"type": txn_type, "n": n, "counts": counts, "expected": {d: round(p, 4) for d, p in BENFORD.items()},
            "observed": {d: round(counts[d] / n, 4) if n else 0 for d in range(1, 10)},
            "mad": None if overall_mad is None else round(overall_mad, 4), "conformity": conformity(overall_mad),
            "chi2": round(chi_square(counts, n, BENFORD), 1), "chi2_critical_05": 15.507, "cashiers": cashiers,
            "note": "Benford's law fits amounts that span several orders of magnitude. Menu prices often don't, so the "
                    "comparison between cashiers (MAD vs team) is usually more meaningful than conformity to Benford."}


def rounding(conn, stores, since, txn_type: str = "refund") -> dict:
    by = _amounts(conn, stores, since, txn_type)

    def stats(vals):
        n = len(vals)
        whole = sum(1 for v in vals if abs(v - round(v)) < 0.005)
        five = sum(1 for v in vals if abs(v / 5 - round(v / 5)) < 0.001)
        return {"n": n, "whole_pct": round(whole / n * 100, 1) if n else 0, "mult5_pct": round(five / n * 100, 1) if n else 0,
                "whole": whole}
    team = stats([v for vs in by.values() for v in vs])
    rows = []
    for c, vals in by.items():
        s = stats(vals)
        o = [v for k, vs in by.items() if k != c for v in vs]
        so = stats(o)
        z = None
        if s["n"] >= 5 and so["n"] >= 5:
            p1, p2 = s["whole"] / s["n"], so["whole"] / so["n"]
            pool = (s["whole"] + so["whole"]) / (s["n"] + so["n"])
            if 0 < pool < 1:
                z = round((p1 - p2) / math.sqrt(pool * (1 - pool) * (1 / s["n"] + 1 / so["n"])), 2)
        top = Counter(vals).most_common(3)
        rows.append({"cashier": c, **s, "z_vs_team": z, "repeats": [(a, k) for a, k in top if k >= 3]})
    rows.sort(key=lambda x: -(x["z_vs_team"] or -99))
    return {"type": txn_type, "team": team, "cashiers": rows}


def hour_profile(conn, stores, since, txn_types=("no_sale", "void", "refund")) -> dict:
    q = f"SELECT cashier, CAST(substr(ts,12,2) AS INTEGER) h, txn_type FROM transactions WHERE store IN ({','.join('?' * len(stores))})"
    p = list(stores)
    if since:
        q += " AND ts >= ?"
        p.append(since)
    risky, sales = defaultdict(lambda: [0] * 24), defaultdict(lambda: [0] * 24)
    for r in conn.execute(q, p):
        if r["txn_type"] in txn_types:
            risky[r["cashier"]][r["h"]] += 1
        elif r["txn_type"] == "sale":
            sales[r["cashier"]][r["h"]] += 1
    out = [{"cashier": c, "risky": risky[c], "sales": sales[c], "total": sum(risky[c])} for c in set(risky) | set(sales)]
    out.sort(key=lambda x: -x["total"])
    return {"types": list(txn_types), "cashiers": out}


def approval_network(conn, stores, since, min_approvals: int = 8, min_share: float = 0.6, z_thr: float = 3.0) -> dict:
    q = f"""SELECT store, cashier, approved_by, txn_type, amount, discount_amount FROM transactions
            WHERE store IN ({','.join('?' * len(stores))}) AND approved_by != '' AND lower(approved_by) != lower(cashier)
            AND (txn_type IN ('refund','void','paid_out','discount','cancel') OR (txn_type='sale' AND discount_amount > 0))"""
    p = list(stores)
    if since:
        q += " AND ts >= ?"
        p.append(since)
    pairs = defaultdict(lambda: defaultdict(lambda: [0, 0.0]))
    for r in conn.execute(q, p):
        cell = pairs[(r["store"], r["cashier"])][r["approved_by"]]
        cell[0] += 1
        cell[1] += r["amount"] if r["txn_type"] != "sale" else r["discount_amount"]
    edges = []
    for (store, cashier), aps in pairs.items():
        n_c = sum(v[0] for v in aps.values())
        peers = [(ap2, sum(v[0] for v in ap2.values())) for (s2, c2), ap2 in pairs.items()
                 if s2 == store and c2 != cashier and sum(v[0] for v in ap2.values()) >= 3]
        for appr, (k, amount) in aps.items():
            exp = statistics.median(ap2.get(appr, [0])[0] / n2 for ap2, n2 in peers) if len(peers) >= 2 else None
            z = None
            if exp is not None:
                pe = min(max(exp, 0.02), 0.98)
                z = round((k - n_c * pe) / math.sqrt(n_c * pe * (1 - pe)), 2)
            share = k / n_c
            edges.append({"store": store, "approver": appr, "cashier": cashier, "approvals": k, "amount": round(amount, 2),
                          "share": round(share, 3), "expected": None if exp is None else round(exp, 3), "z": z,
                          "flagged": bool(z is not None and z >= z_thr and share >= min_share and n_c >= min_approvals)})
    edges.sort(key=lambda e: (-int(e["flagged"]), -e["approvals"]))
    return {"edges": edges, "approvers": sorted({e["approver"] for e in edges}), "cashiers": sorted({e["cashier"] for e in edges})}


def heatmap(conn, stores, since) -> dict:
    ph = ",".join("?" * len(stores))
    p = list(stores) + ([since[:10]] if since else [])
    cells = defaultdict(lambda: {"ai": 0.0, "high": 0, "sales": 0})
    for r in conn.execute(f"SELECT cashier, day, MAX(score) s FROM shift_anomaly WHERE store IN ({ph})"
                          + (" AND day >= ?" if since else "") + " GROUP BY cashier, day", p):
        cells[(r["cashier"], r["day"])]["ai"] = round(r["s"], 1)
    for r in conn.execute(f"""SELECT cashier, substr(ts,1,10) day, COUNT(*) n FROM alerts WHERE store IN ({ph}) AND severity >= 4
                              AND status != 'dismissed' AND rule NOT IN ('peer_outlier','low_cash_ratio','approver_concentration')"""
                          + (" AND ts >= ?" if since else "") + " GROUP BY cashier, day", p):
        cells[(r["cashier"], r["day"])]["high"] = r["n"]
    for r in conn.execute(f"SELECT cashier, substr(ts,1,10) day, COUNT(*) n FROM transactions WHERE store IN ({ph}) AND txn_type='sale'"
                          + (" AND ts >= ?" if since else "") + " GROUP BY cashier, day", p):
        cells[(r["cashier"], r["day"])]["sales"] = r["n"]
    days = sorted({d for _, d in cells})
    totals = defaultdict(float)
    for (c, _d), v in cells.items():
        totals[c] += v["ai"] + v["high"] * 10
    cashiers = sorted({c for c, _ in cells}, key=lambda c: -totals[c])
    return {"days": days, "cashiers": cashiers,
            "cells": [{"cashier": c, "day": d, **v} for (c, d), v in cells.items() if v["sales"] or v["high"]]}
