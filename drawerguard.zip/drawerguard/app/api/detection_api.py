"""Detection engineering API: custom rules (no-code), backtesting, Sigma export."""
import json
from collections import Counter, defaultdict

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from ..auth import User
from ..config import DEFAULT_RULES, merged_rules
from ..db import audit, get_setting, rows
from ..deps import after_import, conn, current_user, need, scope
from ..detection.custom import FIELDS, OPS, TYPES, RuleError, describe, evaluate, validate
from ..detection.engine import detect_store, load_context, load_custom_rules, store_rules, window_since
from ..detection.sigma import export as sigma_export

router = APIRouter(prefix="/api", tags=["Detection engineering"])


class CustomRuleIn(BaseModel):
    name: str
    description: str = ""
    severity: int = 3
    enabled: bool = True
    definition: dict


def _clean(body: CustomRuleIn) -> dict:
    if not body.name.strip():
        raise HTTPException(400, "Give the detection a name")
    if not 1 <= body.severity <= 5:
        raise HTTPException(400, "Severity must be 1–5")
    try:
        return validate(body.definition)
    except RuleError as e:
        raise HTTPException(400, str(e)) from None


@router.get("/custom-rules/schema")
def custom_schema(user: User = Depends(current_user)):
    return {"fields": FIELDS, "ops": {k: sorted(v) for k, v in OPS.items()}, "types": TYPES,
            "payment_methods": ["cash", "card", "other"], "group_keys": ["cashier", "register", "day", "hour"]}


@router.get("/custom-rules")
def list_custom(user: User = Depends(current_user)):
    out = []
    for r in rows(conn.execute("SELECT * FROM custom_rules ORDER BY id")):
        r["definition"] = json.loads(r["definition"])
        try:
            r["summary"] = describe(validate(r["definition"]))
        except RuleError as e:
            r["summary"] = f"⚠️ invalid: {e}"
        r["alerts"] = conn.execute("SELECT COUNT(*) n FROM alerts WHERE rule=?", (f"custom:{r['id']}",)).fetchone()["n"]
        out.append(r)
    return out


@router.post("/custom-rules/test")
def test_custom(body: CustomRuleIn, days: int = 0, store: str = "", user: User = Depends(current_user)):
    """Dry-run a rule on existing data without saving it."""
    defn = _clean(body)
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    found = []
    for sid in st:
        ctx = load_context(conn, [sid], since)
        for a in evaluate(ctx, {"id": 0, "name": body.name, "severity": body.severity, "definition": defn}):
            a["store"] = sid
            found.append(a)
    by_cashier = Counter(a["cashier"] for a in found)
    return {"matches": len(found), "summary": describe(defn), "by_cashier": by_cashier.most_common(10),
            "sample": [{k: a[k] for k in ("store", "ts", "cashier", "title", "amount")} for a in found[-15:]]}


@router.post("/custom-rules")
def create_custom(body: CustomRuleIn, user: User = Depends(need("admin"))):
    defn = _clean(body)
    cur = conn.execute("INSERT INTO custom_rules(name, description, enabled, severity, definition, created_by) VALUES(?,?,?,?,?,?)",
                       (body.name.strip()[:80], body.description[:300], int(body.enabled), body.severity, json.dumps(defn), user.name))
    conn.commit()
    audit(conn, user.name, "created custom detection", body.name[:80])
    det = after_import()
    return {"id": cur.lastrowid, "new_alerts": det["new_count"]}


@router.put("/custom-rules/{rid}")
def update_custom(rid: int, body: CustomRuleIn, user: User = Depends(need("admin"))):
    defn = _clean(body)
    conn.execute("UPDATE custom_rules SET name=?, description=?, enabled=?, severity=?, definition=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
                 (body.name.strip()[:80], body.description[:300], int(body.enabled), body.severity, json.dumps(defn), rid))
    conn.commit()
    audit(conn, user.name, "updated custom detection", body.name[:80])
    det = after_import()
    return {"ok": True, "new_alerts": det["new_count"]}


@router.delete("/custom-rules/{rid}")
def delete_custom(rid: int, user: User = Depends(need("admin"))):
    r = conn.execute("SELECT name FROM custom_rules WHERE id=?", (rid,)).fetchone()
    conn.execute("DELETE FROM custom_rules WHERE id=?", (rid,))
    conn.commit()
    audit(conn, user.name, "deleted custom detection", r["name"] if r else str(rid))
    return {"ok": True}


# ------------------------------------------------------------------ backtesting

@router.post("/settings/rules/backtest")
def backtest(body: dict, store: str = "", user: User = Depends(current_user)):
    """Re-run detection on stored data with proposed thresholds (not saved) and compare
    with the current configuration: how many alerts each change would add or remove."""
    st = scope(user, store)
    current = get_setting(conn, "rules", {})
    proposed = json.loads(json.dumps(current))
    for k, v in body.items():
        if k in DEFAULT_RULES and isinstance(v, dict):
            proposed.setdefault(k, {}).update({kk: vv for kk, vv in v.items() if kk in DEFAULT_RULES[k] and kk != "label"})
    cur_cfg, new_cfg = merged_rules(current), merged_rules(proposed)
    custom = load_custom_rules(conn)
    stores = {r["id"]: dict(r) for r in conn.execute("SELECT * FROM stores")}
    a_cnt, b_cnt = Counter(), Counter()
    a_c, b_c = defaultdict(Counter), defaultdict(Counter)
    for sid in st:
        ctx = load_context(conn, [sid])
        if not ctx.txns:
            continue
        for cfg, cnt, per in ((cur_cfg, a_cnt, a_c), (new_cfg, b_cnt, b_c)):
            for a in detect_store(conn, sid, store_rules(cfg, stores.get(sid, {})), custom, persist_ai=False, ctx=ctx):
                cnt[a["rule"]] += 1
                per[a["rule"]][a["cashier"]] += 1
    out = []
    for k in sorted(set(a_cnt) | set(b_cnt) | set(DEFAULT_RULES)):
        if k.startswith("custom:"):
            continue
        delta = b_cnt[k] - a_cnt[k]
        changes = Counter(b_c[k])
        changes.subtract(a_c[k])
        out.append({"rule": k, "label": DEFAULT_RULES.get(k, {}).get("label", k), "current": a_cnt[k], "proposed": b_cnt[k], "delta": delta,
                    "enabled": new_cfg.get(k, {}).get("enabled", True),
                    "cashiers": [(c, n) for c, n in sorted(changes.items(), key=lambda kv: -abs(kv[1])) if n][:5]})
    out.sort(key=lambda x: -abs(x["delta"]))
    return {"rules": out, "total_current": sum(a_cnt.values()), "total_proposed": sum(b_cnt.values())}


# ------------------------------------------------------------------ Sigma

@router.get("/detections/sigma", response_class=PlainTextResponse)
def sigma(user: User = Depends(current_user)):
    rules_cfg = merged_rules(get_setting(conn, "rules", {}))
    txt = sigma_export(rules_cfg, load_custom_rules(conn, only_enabled=False))
    audit(conn, user.name, "exported Sigma rules")
    return PlainTextResponse(txt, media_type="application/x-yaml",
                             headers={"Content-Disposition": "attachment; filename=drawerguard_sigma.yml"})


# ------------------------------------------------------------------ detection-as-code

_DAC_CACHE: dict = {}


@router.get("/detections/tests")
def detection_tests(refresh: bool = False, user: User = Depends(current_user)):
    """Run every detection's own tests (detections/*.toml). Cached; ?refresh=1 to re-run."""
    from ..detection.dac import load_all, run_all, validate
    if refresh or "res" not in _DAC_CACHE:
        items = load_all()
        problems = validate(items)
        _DAC_CACHE["res"] = {**run_all(items), "validation": problems}
    return _DAC_CACHE["res"]


@router.get("/detections/{rid}/source", response_class=PlainTextResponse)
def detection_source(rid: str, user: User = Depends(current_user)):
    """The detection-as-code file for one detection (read-only)."""
    from ..detection.dac import DETECTIONS_DIR
    if not rid.replace("-", "").isalnum():
        raise HTTPException(400, "Bad id")
    files = [p for p in DETECTIONS_DIR.glob(f"{rid}_*.toml")]
    if not files:
        raise HTTPException(404, "No detection file for that id")
    return files[0].read_text()


@router.get("/import/vendors")
def import_vendors(user: User = Depends(current_user)):
    from ..ingest.adapters import SIGNATURES
    return [{"vendor": "splitpos", "name": "SplitPOS (SplitAbility)", "exports": ["Transactions report", "Cash-up / shift report", "Timeclock"]},
            {"vendor": "square", "name": "Square", "exports": ["Transactions", "Cash drawer report"], "signatures": len(SIGNATURES["square"])},
            {"vendor": "toast", "name": "Toast", "exports": ["PaymentDetails.csv", "CashEntries.csv"], "signatures": len(SIGNATURES["toast"])},
            {"vendor": "clover", "name": "Clover", "exports": ["Payments / Transactions", "Cash log"], "signatures": len(SIGNATURES["clover"])}]
