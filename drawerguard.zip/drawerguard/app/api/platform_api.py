"""Platform API: security center, API keys + machine ingest, evidence integrity, backups,
data retention, data-source health and global search."""
import hashlib
import io
import json
import time
import zipfile
from collections import defaultdict
from datetime import datetime, timezone

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from .. import maintenance, security, siem
from ..auth import User, hash_api_key, new_api_key
from ..db import DATA_DIR, audit, rows
from ..deps import after_import, client_ip, conn, current_user, file_sha256, get_case, need, scope
from ..detection.ai import anomaly_series, build_summary
from ..detection.engine import cashier_scores
from ..ingest.csv_importer import ensure_stores, map_payment, map_type, parse_dt, slug, store_shifts, store_transactions
from ..reports import build_case_file

router = APIRouter(prefix="/api", tags=["Platform & security"])


# ================================================================== security center

@router.get("/security/overview")
def security_overview(user: User = Depends(need("admin"))):
    return security.overview(conn)


# ================================================================== API keys

SCOPES = ("ingest", "read")


class ApiKeyIn(BaseModel):
    name: str
    scopes: list[str] = ["ingest"]
    stores: list[str] = ["*"]


@router.get("/apikeys")
def list_keys(user: User = Depends(need("admin"))):
    return [{k: v for k, v in r.items() if k != "key_hash"} | {"scopes": json.loads(r["scopes"]), "stores": json.loads(r["stores"])}
            for r in rows(conn.execute("SELECT * FROM api_keys ORDER BY revoked, id DESC"))]


@router.post("/apikeys")
def create_key(body: ApiKeyIn, user: User = Depends(need("admin"))):
    scopes = [s for s in body.scopes if s in SCOPES]
    if not scopes or not body.name.strip():
        raise HTTPException(400, "Name the key and pick at least one scope (ingest, read)")
    stores = ["*"] if "*" in body.stores or not body.stores else [scope(user, s)[0] for s in body.stores]
    key, prefix, digest = new_api_key()
    cur = conn.execute("INSERT INTO api_keys(name, prefix, key_hash, scopes, stores, created_by) VALUES(?,?,?,?,?,?)",
                       (body.name.strip()[:60], prefix, digest, json.dumps(scopes), json.dumps(stores), user.name))
    conn.commit()
    audit(conn, user.name, "created API key", f"{body.name[:60]} (dg_{prefix}_…) scopes={','.join(scopes)}")
    return {"id": cur.lastrowid, "key": key, "prefix": prefix, "note": "Copy it now: it is stored only as a hash and can't be shown again."}


@router.delete("/apikeys/{kid}")
def revoke_key(kid: int, user: User = Depends(need("admin"))):
    conn.execute("UPDATE api_keys SET revoked=1 WHERE id=?", (kid,))
    conn.commit()
    audit(conn, user.name, "revoked API key", f"#{kid}")
    return {"ok": True}


_key_hits: dict[int, list[float]] = defaultdict(list)


def api_key(required: str):
    def dep(request: Request, x_api_key: str = Header(default=""), authorization: str = Header(default="")) -> dict:
        key = x_api_key or authorization.removeprefix("Bearer ").strip()
        if not key.startswith("dg_"):
            raise HTTPException(401, "Missing API key (X-API-Key header)")
        r = conn.execute("SELECT * FROM api_keys WHERE key_hash=? AND revoked=0", (hash_api_key(key),)).fetchone()
        if not r:
            security.record_login(conn, f"apikey:{key[:11]}…", client_ip(request), request.headers.get("user-agent", ""), False, "bad API key")
            raise HTTPException(401, "Invalid or revoked API key")
        if required not in json.loads(r["scopes"]):
            raise HTTPException(403, f"This key lacks the '{required}' scope")
        now = time.time()
        _key_hits[r["id"]] = [t for t in _key_hits[r["id"]] if now - t < 60] + [now]
        if len(_key_hits[r["id"]]) > 120:
            raise HTTPException(429, "Rate limit: 120 requests per minute per key")
        conn.execute("UPDATE api_keys SET last_used=CURRENT_TIMESTAMP, uses=uses+1 WHERE id=?", (r["id"],))
        conn.commit()
        return dict(r) | {"stores": json.loads(r["stores"])}
    return dep


def _key_store(k: dict, store: str) -> str:
    sid = slug(store or "main")
    if "*" not in k["stores"] and sid not in k["stores"]:
        raise HTTPException(403, f"This key can't write to store {sid}")
    return sid


TXN_FIELDS = ("id", "ts", "cashier", "register", "type", "amount", "payment_method", "order_id", "original_id", "discount",
              "approved_by", "sent_to_kitchen", "note")


@router.post("/v1/transactions", tags=["Machine API"])
def ingest_transactions(store: str = "main", payload: dict = Body(...), k: dict = Depends(api_key("ingest"))):
    """Push transactions in real time (e.g. from a POS webhook or a scheduled script).
    Body: {"transactions": [{"id","ts","cashier","register","type","amount","payment_method",...}]}"""
    sid = _key_store(k, store)
    items = payload.get("transactions")
    if not isinstance(items, list) or not items or len(items) > 5000:
        raise HTTPException(400, "Send 1–5000 transactions in a 'transactions' list")
    recs, errors = [], []
    for i, x in enumerate(items):
        if not isinstance(x, dict):
            errors.append(f"#{i}: not an object")
            continue
        ts = parse_dt(x.get("ts"))
        if not ts or not x.get("id") or not x.get("cashier"):
            errors.append(f"#{i}: needs id, ts and cashier")
            continue
        try:
            amount = abs(float(x.get("amount") or 0))
            discount = abs(float(x.get("discount") or 0))
        except (TypeError, ValueError):
            errors.append(f"#{i}: amount must be a number")
            continue
        recs.append({"store": sid, "id": str(x["id"])[:64], "ts": ts, "cashier": str(x["cashier"])[:60], "register": str(x.get("register") or "")[:40],
                     "txn_type": map_type(str(x.get("type") or "sale")), "amount": amount, "payment_method": map_payment(x.get("payment_method") or ""),
                     "order_id": str(x.get("order_id") or "")[:64], "original_txn_id": str(x.get("original_id") or "")[:64],
                     "discount_amount": discount, "approved_by": str(x.get("approved_by") or "")[:60],
                     "sent_to_kitchen": 1 if x.get("sent_to_kitchen") in (1, True, "1", "yes", "true") else 0, "note": str(x.get("note") or "")[:500]})
    added = store_transactions(conn, recs, source="api") if recs else 0
    conn.execute("INSERT INTO import_log(store, filename, kind, rows_read, rows_added, errors) VALUES(?,?,?,?,?,?)",
                 (sid, f"API key {k['name']}", "transactions", len(items), added, json.dumps(errors[:50])))
    conn.commit()
    det = after_import([sid]) if added else {"new_count": 0}
    return {"store": sid, "received": len(items), "added": added, "rejected": errors[:50], "new_alerts": det["new_count"]}


@router.post("/v1/shifts", tags=["Machine API"])
def ingest_shifts(store: str = "main", payload: dict = Body(...), k: dict = Depends(api_key("ingest"))):
    sid = _key_store(k, store)
    items = payload.get("shifts")
    if not isinstance(items, list) or not items or len(items) > 2000:
        raise HTTPException(400, "Send 1–2000 shifts in a 'shifts' list")
    recs = []
    for x in items:
        st, en = parse_dt(x.get("start")), parse_dt(x.get("end"))
        if not st or not x.get("cashier"):
            continue
        num = (lambda v: None if v in (None, "") else float(v))
        recs.append({"store": sid, "cashier": str(x["cashier"])[:60], "register": str(x.get("register") or "")[:40], "start_ts": st,
                     "end_ts": en or st, "opening_float": num(x.get("float")) or 0.0, "expected_cash": num(x.get("expected_cash")),
                     "counted_cash": num(x.get("counted_cash"))})
    ensure_stores(conn, [sid])
    added = store_shifts(conn, recs) if recs else 0
    det = after_import([sid]) if added else {"new_count": 0}
    return {"store": sid, "received": len(items), "stored": added, "new_alerts": det["new_count"]}


@router.get("/v1/alerts", tags=["Machine API"])
def read_alerts(since: str = "", min_severity: int = 1, limit: int = 500, k: dict = Depends(api_key("read"))):
    """For SOAR tools / scripts: alerts as ECS JSON (oldest first after `since` = created_at)."""
    q, p = "SELECT * FROM alerts WHERE severity >= ?", [min_severity]
    if "*" not in k["stores"]:
        q += f" AND store IN ({','.join('?' * len(k['stores']))})"
        p += k["stores"]
    if since:
        q += " AND created_at > ?"
        p.append(since)
    q += " ORDER BY created_at, id LIMIT ?"
    p.append(min(max(limit, 1), 2000))
    items = rows(conn.execute(q, p))
    return {"alerts": [siem.to_ecs(a) | {"created_at": a["created_at"]} for a in items],
            "next_since": items[-1]["created_at"] if items else since}


# ================================================================== evidence integrity

@router.get("/evidence/{eid}/verify")
def verify_evidence(eid: int, user: User = Depends(current_user)):
    e = conn.execute("SELECT * FROM evidence WHERE id=?", (eid,)).fetchone()
    if not e:
        raise HTTPException(404)
    if e["case_id"]:
        get_case(e["case_id"], user)
    p = DATA_DIR / "evidence" / e["stored_name"]
    if not p.exists():
        return {"ok": False, "status": "missing", "message": "The file is missing from the evidence store."}
    now = file_sha256(p)
    if not e["sha256"]:
        conn.execute("UPDATE evidence SET sha256=? WHERE id=?", (now, eid))
        conn.commit()
        return {"ok": True, "status": "fingerprinted", "sha256": now, "message": "No earlier fingerprint existed; one was recorded now."}
    ok = now == e["sha256"]
    audit(conn, user.name, "verified evidence" if ok else "EVIDENCE INTEGRITY FAILURE", f"#{eid} {e['filename']}")
    return {"ok": ok, "status": "intact" if ok else "MODIFIED", "sha256": e["sha256"], "current": now,
            "message": "Unchanged since upload." if ok else "The file has changed since it was uploaded!"}


@router.get("/cases/{cid}/package")
def case_package(cid: int, user: User = Depends(current_user)):
    """Evidence package for HR / police: case file + original evidence + SHA-256 manifest."""
    c = get_case(cid, user)
    summary = None
    sc = next((x for x in cashier_scores(conn, 0, [c["store"]]) if x["cashier"] == c["cashier"]), None)
    if sc:
        al = rows(conn.execute("SELECT * FROM alerts WHERE cashier=? AND store=?", (c["cashier"], c["store"])))
        summary = build_summary(sc, al, anomaly_series(conn, [c["store"]], c["cashier"], None), [])
    html = build_case_file(conn, cid, summary)
    ev = rows(conn.execute("SELECT * FROM evidence WHERE case_id=? OR alert_id IN (SELECT id FROM alerts WHERE case_id=?) ORDER BY id", (cid, cid)))
    buf = io.BytesIO()
    manifest = {"case": cid, "title": c["title"], "cashier": c["cashier"], "store": c["store"], "status": c["status"],
                "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "generated_by": user.name, "files": []}
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("case_file.html", html)
        manifest["files"].append({"name": "case_file.html", "sha256": hashlib.sha256(html.encode()).hexdigest(), "kind": "report"})
        for e in ev:
            p = DATA_DIR / "evidence" / e["stored_name"]
            if not p.exists():
                manifest["files"].append({"name": e["filename"], "missing": True})
                continue
            arc = f"evidence/{e['id']:04d}_{e['filename']}"
            z.write(p, arc)
            cur = file_sha256(p)
            manifest["files"].append({"name": arc, "sha256": cur, "sha256_at_upload": e["sha256"], "intact": e["sha256"] in (None, cur),
                                      "size": e["size"], "uploaded_by": e["uploaded_by"], "uploaded_at": e["created_at"], "note": e["note"]})
        mjson = json.dumps(manifest, indent=2)
        z.writestr("manifest.json", mjson)
        z.writestr("manifest.sha256", hashlib.sha256(mjson.encode()).hexdigest() + "  manifest.json\n")
        z.writestr("README.txt", "DrawerGuard evidence package\n\nVerify a file:  sha256sum <file>  (Windows: certutil -hashfile <file> SHA256)\n"
                                 "and compare with manifest.json. manifest.sha256 protects the manifest itself.\n")
    audit(conn, user.name, "exported evidence package", f"case #{cid}")
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f"attachment; filename=drawerguard_case_{cid}_evidence.zip"})


# ================================================================== backups & retention & data health

@router.post("/admin/backup")
def make_backup(user: User = Depends(need("admin"))):
    b = maintenance.backup(conn)
    audit(conn, user.name, "created backup", b["name"])
    return b


@router.get("/admin/backups")
def backups(user: User = Depends(need("admin"))):
    return maintenance.list_backups()


@router.get("/admin/backups/{name}")
def download_backup(name: str, user: User = Depends(need("admin"))):
    p = maintenance.backup_path(name)
    if not p:
        raise HTTPException(404, "No such backup")
    audit(conn, user.name, "downloaded backup", name)
    return FileResponse(p, media_type="application/octet-stream", filename=name)


class RetentionIn(BaseModel):
    days: int
    dry_run: bool = True


@router.post("/admin/retention")
def retention(body: RetentionIn, user: User = Depends(need("admin"))):
    try:
        res = maintenance.retention(conn, body.days, body.dry_run)
    except ValueError as e:
        raise HTTPException(400, str(e)) from None
    if not body.dry_run:
        audit(conn, user.name, "applied data retention", json.dumps(res))
    return res


@router.get("/health/data")
def data_health(user: User = Depends(current_user)):
    return maintenance.data_health(conn, user.store_ids(conn))


# ================================================================== global search

@router.get("/search")
def search(q: str, user: User = Depends(current_user)):
    q = q.strip()
    if len(q) < 2:
        return {"cashiers": [], "alerts": [], "cases": [], "receipts": []}
    st = user.store_ids(conn) or ["-"]
    ph = ",".join("?" * len(st))
    like = f"%{q}%"
    out = {
        "cashiers": [r["cashier"] for r in conn.execute(f"SELECT DISTINCT cashier FROM transactions WHERE store IN ({ph}) AND cashier LIKE ? LIMIT 6", [*st, like])],
        "receipts": rows(conn.execute(f"SELECT store, id, ts, cashier, txn_type, amount FROM transactions WHERE store IN ({ph}) AND (id = ? OR id LIKE ? OR order_id = ?) LIMIT 6",
                                      [*st, q, q + "%", q])),
        "alerts": rows(conn.execute(f"SELECT id, title, severity, cashier, status FROM alerts WHERE store IN ({ph}) AND (CAST(id AS TEXT) = ? OR title LIKE ? OR txn_id = ?) ORDER BY ts DESC LIMIT 6",
                                    [*st, q.lstrip("#"), like, q])),
        "cases": rows(conn.execute(f"SELECT id, title, cashier, status FROM cases WHERE store IN ({ph}) AND (CAST(id AS TEXT) = ? OR title LIKE ? OR cashier LIKE ?) LIMIT 6",
                                   [*st, q.lstrip("#"), like, like])),
    }
    return out
