"""Model monitoring API: drift (PSI), alert-volume drift, agreement between DG-020 and DG-030."""
from fastapi import APIRouter, Depends

from ..auth import User
from ..config import merged_rules
from ..db import get_setting
from ..deps import conn, current_user, scope
from ..detection.engine import load_context
from ..detection.ml import model_health

router = APIRouter(prefix="/api/ml", tags=["Machine learning"])


@router.get("/health")
def ml_health(store: str = "", recent_days: int = 14, user: User = Depends(current_user)):
    rules = merged_rules(get_setting(conn, "rules", {}))
    out = []
    for sid in scope(user, store):
        out.append(model_health(conn, sid, load_context(conn, [sid]), rules, max(7, min(recent_days, 60))))
    return {"stores": out}
