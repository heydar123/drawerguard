"""Forensic analytics API (all roles, store-scoped)."""
from fastapi import APIRouter, Depends, HTTPException

from .. import forensics
from ..auth import User
from ..deps import conn, current_user, scope
from ..detection.engine import window_since

router = APIRouter(prefix="/api/forensics", tags=["Forensic analytics"])


def _window(user, store, days):
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    return st, since


@router.get("/benford")
def benford(type: str = "refund", days: int = 0, store: str = "", user: User = Depends(current_user)):
    if type not in forensics.TYPES:
        raise HTTPException(400, "Unknown transaction type")
    st, since = _window(user, store, days)
    return forensics.benford(conn, st, since, type)


@router.get("/rounding")
def rounding(type: str = "refund", days: int = 0, store: str = "", user: User = Depends(current_user)):
    if type not in forensics.TYPES:
        raise HTTPException(400, "Unknown transaction type")
    st, since = _window(user, store, days)
    return forensics.rounding(conn, st, since, type)


@router.get("/hours")
def hours(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st, since = _window(user, store, days)
    return forensics.hour_profile(conn, st, since)


@router.get("/approvals")
def approvals(days: int = 0, store: str = "", user: User = Depends(current_user)):
    st, since = _window(user, store, days)
    return forensics.approval_network(conn, st, since)


@router.get("/heatmap")
def heatmap(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st, since = _window(user, store, days)
    return forensics.heatmap(conn, st, since)
