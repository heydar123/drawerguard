"""Push cases and alerts to TheHive and Jira."""
import json
import urllib.error

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import integrations
from ..auth import User
from ..db import audit, rows
from ..deps import conn, current_user, get_case, need, scope

router = APIRouter(prefix="/api", tags=["Integrations"])


@router.get("/integrations")
def status(user: User = Depends(current_user)):
    st = scope(user)
    refs = rows(conn.execute(f"""SELECT r.* FROM external_refs r LEFT JOIN cases c ON r.kind='case' AND c.id=r.local_id
                                 LEFT JOIN alerts a ON r.kind='alert' AND a.id=r.local_id
                                 WHERE COALESCE(c.store, a.store) IN ({','.join('?' * len(st))}) ORDER BY r.id DESC LIMIT 50""", st))
    return {"configured": integrations.configured(), "recent": refs}


class PushIn(BaseModel):
    system: str


@router.post("/cases/{cid}/push")
def push_case(cid: int, body: PushIn, user: User = Depends(need("cases"))):
    case = get_case(cid, user)
    if body.system not in ("thehive", "jira"):
        raise HTTPException(400, "system must be thehive or jira")
    if not integrations.configured()[body.system]:
        raise HTTPException(400, f"{body.system} is not configured (see .env.example)")
    alerts = rows(conn.execute("SELECT * FROM alerts WHERE case_id=?", (cid,)))
    try:
        res = integrations.push_case(body.system, case, alerts)
    except (urllib.error.URLError, OSError, ValueError) as e:
        conn.execute("INSERT INTO external_refs(system, kind, local_id, status, detail, created_by) VALUES(?,?,?,?,?,?)",
                     (body.system, "case", cid, "error", str(e)[:300], user.name))
        conn.commit()
        raise HTTPException(502, f"{body.system} rejected the request: {e}") from e
    conn.execute("INSERT INTO external_refs(system, kind, local_id, external_id, url, created_by) VALUES(?,?,?,?,?,?)",
                 (body.system, "case", cid, res["external_id"], res["url"], user.name))
    conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)",
                 (cid, user.name, "ir", f"Sent to {body.system}: {res['external_id']} {res['url']}"))
    conn.commit()
    audit(conn, user.name, f"pushed case to {body.system}", json.dumps({"case": cid, **res}))
    return res
