"""Threat-hunting API: guided pivots (all roles, store-scoped), sandboxed SQL and saved hunts (owner)."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import hunt
from ..auth import User
from ..db import audit, rows
from ..deps import conn, current_user, need, scope
from ..detection.engine import window_since

router = APIRouter(prefix="/api/hunt", tags=["Threat hunting"])


@router.get("/library")
def library(user: User = Depends(current_user)):
    return {"library": hunt.LIBRARY, "schema": hunt.SCHEMA_DOC, "readable": sorted(hunt.READABLE),
            "saved": rows(conn.execute("SELECT * FROM hunts ORDER BY id DESC"))}


class Query_(BaseModel):
    sql: str
    hunt_id: int = 0


@router.post("/run")
def run_query(body: Query_, user: User = Depends(need("admin"))):
    """Owner only: raw SQL sees every store. Managers use the store-scoped pivot builder."""
    try:
        res = hunt.run(body.sql)
    except hunt.HuntError as e:
        raise HTTPException(400, str(e)) from None
    if body.hunt_id:
        conn.execute("UPDATE hunts SET last_run=CURRENT_TIMESTAMP, last_rows=? WHERE id=?", (res["row_count"], body.hunt_id))
        conn.commit()
    audit(conn, user.name, "ran hunt query", body.sql[:200].replace("\n", " "))
    return res


class SavedHunt(BaseModel):
    name: str
    description: str = ""
    sql: str


@router.post("/saved")
def save_hunt(body: SavedHunt, user: User = Depends(need("admin"))):
    try:
        hunt.run(body.sql, max_rows=1)                 # must at least be a valid, allowed query
    except hunt.HuntError as e:
        raise HTTPException(400, str(e)) from None
    cur = conn.execute("INSERT INTO hunts(name, description, sql, created_by) VALUES(?,?,?,?)",
                       (body.name.strip()[:80] or "Untitled hunt", body.description[:300], body.sql[:8000], user.name))
    conn.commit()
    audit(conn, user.name, "saved hunt", body.name[:80])
    return {"id": cur.lastrowid}


@router.delete("/saved/{hid}")
def delete_hunt(hid: int, user: User = Depends(need("admin"))):
    conn.execute("DELETE FROM hunts WHERE id=?", (hid,))
    conn.commit()
    return {"ok": True}


class Ask(BaseModel):
    question: str


@router.post("/ask")
def ask(body: Ask, user: User = Depends(need("admin"))):
    try:
        out = hunt.ask_claude(body.question)
    except hunt.HuntError as e:
        raise HTTPException(400, str(e)) from None
    audit(conn, user.name, "asked AI for a hunt query", body.question[:200])
    return out


@router.get("/pivot")
def pivot(group_by: str = "cashier", group_by2: str = "", metric: str = "count", type: str = "", payment: str = "",
          cashier: str = "", min_amount: float = 0, days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    try:
        return hunt.pivot(conn, st, since, group_by, group_by2, metric, type, payment, cashier, min_amount)
    except hunt.HuntError as e:
        raise HTTPException(400, str(e)) from None
