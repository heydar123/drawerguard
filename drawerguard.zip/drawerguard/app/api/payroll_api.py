"""Payroll & timeclock API: hours, wages, edits and payroll-fraud alerts per employee."""
from collections import defaultdict
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends

from ..auth import User
from ..config import PAYROLL_RULES
from ..deps import conn, current_user, scope

router = APIRouter(prefix="/api/payroll", tags=["Payroll & timeclock"])


def _in(xs):
    return f"({','.join('?' * len(xs))})"


def _h(p):
    if not p["clock_out"]:
        return 0.0
    return max(0.0, (datetime.fromisoformat(p["clock_out"]) - datetime.fromisoformat(p["clock_in"])).total_seconds() / 3600)


@router.get("/overview")
def overview(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    latest = conn.execute(f"SELECT MAX(clock_in) m FROM timeclock WHERE store IN {_in(st)}", st).fetchone()["m"]
    if not latest:
        return {"has_data": False, "employees": [], "daily": [], "alerts": [], "totals": {}}
    since = (datetime.fromisoformat(latest) - timedelta(days=days)).isoformat() if days else "0000"
    punches = [dict(r) for r in conn.execute(f"SELECT * FROM timeclock WHERE store IN {_in(st)} AND clock_in>=? ORDER BY clock_in",
                                             [*st, since])]
    pos = defaultdict(int)
    for r in conn.execute(f"SELECT cashier, COUNT(*) n FROM transactions WHERE store IN {_in(st)} AND ts>=? GROUP BY cashier", [*st, since]):
        pos[r["cashier"]] = r["n"]
    appr = {r["approved_by"] for r in conn.execute(f"SELECT DISTINCT approved_by FROM transactions WHERE store IN {_in(st)} AND ts>=?",
                                                   [*st, since]) if r["approved_by"]}
    alerts = defaultdict(list)
    alert_rows = []
    for r in conn.execute(f"SELECT id, store, rule, severity, cashier, ts, amount, title, status FROM alerts WHERE store IN {_in(st)} "
                          f"AND rule IN {_in(PAYROLL_RULES)} AND ts>=? AND status!='dismissed' ORDER BY severity DESC, ts DESC",
                          [*st, *PAYROLL_RULES, since]):
        alerts[r["cashier"]].append(r["rule"])
        alert_rows.append(dict(r))
    emp = defaultdict(lambda: {"hours": 0.0, "shifts": 0, "wages": 0.0, "edits": 0, "minutes_added": 0.0, "devices": set(),
                               "manager_punches": 0, "weeks": defaultdict(float), "rate": None})
    daily = defaultdict(float)
    for p in punches:
        e = emp[p["employee"]]
        h = _h(p)
        e["hours"] += h
        e["shifts"] += 1
        e["rate"] = p["hourly_rate"] or e["rate"]
        e["wages"] += h * (p["hourly_rate"] or 0)
        e["devices"].add(p["device"] or "?")
        if p["edited_by"] and (p["minutes_added"] or 0) > 0:
            e["edits"] += 1
            e["minutes_added"] += p["minutes_added"]
        if p["method"] == "manager":
            e["manager_punches"] += 1
        wk = datetime.fromisoformat(p["clock_in"]).isocalendar()
        e["weeks"][f"{wk[0]}-W{wk[1]:02d}"] += h
        daily[p["clock_in"][:10]] += h
    out = []
    for name, e in emp.items():
        overtime = sum(max(0.0, h - 40) for h in e["weeks"].values())
        flags = sorted(set(alerts.get(name, [])))
        out.append({"employee": name, "hours": round(e["hours"], 1), "shifts": e["shifts"], "wages": round(e["wages"], 2),
                    "rate": e["rate"], "overtime_hours": round(overtime, 1), "edits": e["edits"],
                    "hours_added": round(e["minutes_added"] / 60, 1), "pos_txns": pos.get(name, 0), "approver": name in appr,
                    "manager_punches": e["manager_punches"], "devices": sorted(e["devices"]), "alerts": len(alerts.get(name, [])),
                    "flags": flags, "risk": "high" if any(f in ("ghost_employee", "buddy_punch", "clocked_out_activity") for f in flags)
                    else "medium" if flags else "low"})
    out.sort(key=lambda x: ({"high": 0, "medium": 1, "low": 2}[x["risk"]], -x["alerts"], x["employee"]))
    total_wages = sum(x["wages"] for x in out)
    at_risk = sum(a["amount"] or 0 for a in alert_rows)
    return {"has_data": True, "since": since[:10], "latest": latest[:10], "employees": out,
            "daily": [{"x": d, "v": round(h, 1)} for d, h in sorted(daily.items())],
            "alerts": alert_rows[:200],
            "totals": {"employees": len(out), "hours": round(sum(x["hours"] for x in out), 1), "wages": round(total_wages, 2),
                       "overtime_hours": round(sum(x["overtime_hours"] for x in out), 1),
                       "hours_added_by_edits": round(sum(x["hours_added"] for x in out), 1), "flagged": sum(1 for x in out if x["flags"]),
                       "wages_at_risk": round(at_risk, 2)}}
