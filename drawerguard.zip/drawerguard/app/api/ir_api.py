"""Incident-response API for cases (NIST SP 800-61 lifecycle)."""
import json
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from .. import ir
from ..auth import User
from ..db import audit
from ..deps import conn, current_user, get_case, need

router = APIRouter(prefix="/api/cases", tags=["Incident response"])


@router.get("/{cid}/ir")
def get_ir(cid: int, user: User = Depends(current_user)):
    return ir.view(conn, get_case(cid, user))


class IRUpdate(BaseModel):
    phase: str | None = None
    check: str | None = None          # checklist key, e.g. "containment.reset_pins"
    done: bool = True
    root_cause: str | None = None
    lessons: str | None = None
    controls: list[str] | None = None


@router.patch("/{cid}/ir")
def update_ir(cid: int, body: IRUpdate, user: User = Depends(need("cases"))):
    case = get_case(cid, user)
    data = ir.load_ir(case)
    events = []
    if body.phase:
        if body.phase not in ir.PHASE_KEYS:
            raise HTTPException(400, "Unknown phase")
        if body.phase != case.get("phase"):
            data["phase_times"].setdefault(body.phase, ir.now())
            events.append(f"Phase → {dict(ir.PHASES)[body.phase]}")
    if body.check:
        ph, _, key = body.check.partition(".")
        if ph not in ir.CHECKLIST or key not in dict(ir.CHECKLIST[ph]):
            raise HTTPException(400, "Unknown checklist item")
        data["checklist"][body.check] = {"done": body.done, "by": user.name, "at": ir.now()}
        events.append(f"{'✔' if body.done else '✗'} {dict(ir.CHECKLIST[ph])[key]}")
        if body.check == "containment.watchlist" and body.done:      # containment → tighter detection on this cashier
            until = (date.today() + timedelta(days=30)).isoformat()
            conn.execute("""INSERT INTO watchlist(store, cashier, reason, until, created_by) VALUES(?,?,?,?,?)
                            ON CONFLICT(store, cashier) DO UPDATE SET reason=excluded.reason, until=excluded.until""",
                         (case["store"], case["cashier"], f"Case #{cid}: {case['title']}"[:300], until, user.name))
            events.append(f"👁 {case['cashier']} added to the watchlist until {until}")
    if body.root_cause is not None:
        data["root_cause"] = body.root_cause[:4000]
        events.append("Root cause updated")
    if body.lessons is not None:
        data["lessons"] = body.lessons[:4000]
        events.append("Lessons learned updated")
    if body.controls is not None:
        data["controls"] = [c[:300] for c in body.controls[:30]]
        events.append(f"{len(data['controls'])} control(s) adopted")
    conn.execute("UPDATE cases SET ir=?, phase=COALESCE(?, phase), updated_at=CURRENT_TIMESTAMP WHERE id=?",
                 (json.dumps(data), body.phase, cid))
    for e in events:
        conn.execute("INSERT INTO case_events(case_id, author, kind, body) VALUES(?,?,?,?)", (cid, user.name, "ir", e))
    conn.commit()
    audit(conn, user.name, "updated incident response", f"case {cid}: {'; '.join(events)[:200]}")
    return ir.view(conn, get_case(cid, user))


@router.get("/{cid}/ir-report", response_class=HTMLResponse)
def ir_report(cid: int, user: User = Depends(current_user)):
    case = get_case(cid, user)
    audit(conn, user.name, "exported incident report", str(cid))
    return ir.report_html(conn, case, user.name)
