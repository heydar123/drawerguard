"""Purple-team simulator API: attack scenarios run in memory against the real detections."""
import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import purple
from ..auth import User
from ..db import audit, rows
from ..deps import conn, current_user, need, scope

router = APIRouter(prefix="/api/purple", tags=["Purple team"])


class RunIn(BaseModel):
    store: str
    scenarios: list[str] = []
    intensity: float = 1.0
    days: int = 14


@router.get("/scenarios")
def scenarios(user: User = Depends(current_user)):
    return purple.catalog()


@router.post("/run")
def run(body: RunIn, user: User = Depends(need("admin"))):
    scope(user, body.store)
    if not 0.1 <= body.intensity <= 5 or not 7 <= body.days <= 60:
        raise HTTPException(400, "Intensity 0.1–5 and days 7–60")
    try:
        res = purple.run(conn, body.store, body.scenarios or None, body.intensity, body.days)
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
    cur = conn.execute("INSERT INTO purple_runs(store, created_by, params, results, coverage) VALUES(?,?,?,?,?)",
                       (body.store, user.name, json.dumps(body.model_dump()), json.dumps(res), res["summary"]["coverage"]))
    conn.commit()
    audit(conn, user.name, "ran purple-team simulation", f"{body.store} coverage={res['summary']['coverage']:.0%}")
    return {"id": cur.lastrowid, **res}


@router.get("/runs")
def runs(store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    q = f"SELECT id, store, created_by, created_at, params, coverage FROM purple_runs WHERE store IN ({','.join('?' * len(st))}) ORDER BY id DESC LIMIT 30"
    out = rows(conn.execute(q, st))
    for r in out:
        r["params"] = json.loads(r["params"] or "{}")
    return out


@router.get("/runs/{rid}")
def get_run(rid: int, user: User = Depends(current_user)):
    r = conn.execute("SELECT * FROM purple_runs WHERE id=?", (rid,)).fetchone()
    if not r:
        raise HTTPException(404)
    scope(user, r["store"])
    return {"id": r["id"], "created_by": r["created_by"], "created_at": r["created_at"], **json.loads(r["results"])}


class SweepIn(BaseModel):
    store: str
    scenario: str
    days: int = 14


@router.post("/sweep")
def sweep(body: SweepIn, user: User = Depends(need("admin"))):
    scope(user, body.store)
    if body.scenario not in purple.BY_ID:
        raise HTTPException(400, "Unknown scenario")
    try:
        return {"scenario": body.scenario, "steps": purple.sweep(conn, body.store, body.scenario, body.days)}
    except ValueError as e:
        raise HTTPException(400, str(e)) from e
