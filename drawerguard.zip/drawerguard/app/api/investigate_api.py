"""Incident queue (grouped alerts) and the investigation graph."""
from fastapi import APIRouter, Depends

from .. import investigate
from ..auth import User
from ..deps import conn, current_user, rule_labels, scope
from ..detection.engine import window_since

router = APIRouter(prefix="/api", tags=["Investigation"])


@router.get("/incidents")
def incidents(days: int = 30, store: str = "", closed: bool = False, user: User = Depends(current_user)):
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    return investigate.incidents(conn, st, since, closed, rule_labels())


@router.get("/graph")
def graph(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    return investigate.graph(conn, st, since, days)
