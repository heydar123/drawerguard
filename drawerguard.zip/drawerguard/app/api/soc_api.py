"""SOC operations API: suppressions (allow-list), playbook automations, SOC metrics."""
import json
import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import soc
from ..auth import User
from ..config import DEFAULT_RULES
from ..db import audit, rows
from ..deps import conn, current_user, need, scope
from ..detection.engine import window_since

router = APIRouter(prefix="/api", tags=["SOC operations"])


# ------------------------------------------------------------------ metrics

@router.get("/soc/metrics")
def soc_metrics(days: int = 30, store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    since, _ = window_since(conn, st, days)
    m = soc.metrics(conn, st, since)
    labels = {k: v["label"] for k, v in DEFAULT_RULES.items()}
    for r in conn.execute("SELECT id, name FROM custom_rules"):
        labels[f"custom:{r['id']}"] = f"🧩 {r['name']}"
    for r in m["rules"]:
        r["label"] = labels.get(r["rule"], r["rule"])
    m["sla_hours"] = soc.sla_hours()
    return m


# ------------------------------------------------------------------ suppressions

class SuppressionIn(BaseModel):
    store: str = "*"
    rule: str = "*"
    cashier: str = "*"
    register: str = "*"
    reason: str
    expires_at: str | None = None        # YYYY-MM-DD
    apply_existing: bool = False


@router.get("/suppressions")
def list_suppressions(user: User = Depends(current_user)):
    return rows(conn.execute("SELECT * FROM suppressions ORDER BY active DESC, id DESC"))


@router.post("/suppressions")
def add_suppression(body: SuppressionIn, user: User = Depends(need("admin"))):
    if len(body.reason.strip()) < 5:
        raise HTTPException(400, "Write a reason (it's kept for audit)")
    if body.expires_at and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", body.expires_at):
        raise HTTPException(400, "Expiry must be YYYY-MM-DD")
    if body.store != "*":
        scope(user, body.store)
    if all(x in ("*", "") for x in (body.store, body.rule, body.cashier, body.register)):
        raise HTTPException(400, "Too broad: pick at least a detection, cashier, store or till")
    cur = conn.execute("INSERT INTO suppressions(store, rule, cashier, register, reason, expires_at, created_by) VALUES(?,?,?,?,?,?,?)",
                       (body.store or "*", body.rule or "*", body.cashier or "*", body.register or "*", body.reason.strip()[:300],
                        body.expires_at, user.name))
    conn.commit()
    sid = cur.lastrowid
    closed = 0
    if body.apply_existing:
        closed = soc.apply_suppression_to_existing(conn, dict(conn.execute("SELECT * FROM suppressions WHERE id=?", (sid,)).fetchone()), user.name)
    audit(conn, user.name, "created suppression", f"#{sid} {body.rule}/{body.cashier}: {body.reason[:80]}")
    return {"id": sid, "closed_existing": closed}


@router.delete("/suppressions/{sid}")
def disable_suppression(sid: int, user: User = Depends(need("admin"))):
    conn.execute("UPDATE suppressions SET active=0 WHERE id=?", (sid,))
    conn.commit()
    audit(conn, user.name, "disabled suppression", f"#{sid}")
    return {"ok": True}


# ------------------------------------------------------------------ automations (playbooks)

class AutomationIn(BaseModel):
    name: str
    enabled: bool = True
    rules: list[str] = []
    min_severity: int = 1
    stores: list[str] = []
    cashiers: list[str] = []
    assign_to: str = ""
    set_status: str = ""
    add_to_case: bool = False
    notify: bool = False
    tag: str = ""


def _auto_payload(body: AutomationIn):
    if not body.name.strip():
        raise HTTPException(400, "Name the playbook")
    if body.set_status and body.set_status not in soc.STATUSES:
        raise HTTPException(400, "Bad status")
    if body.set_status in ("dismissed",):
        raise HTTPException(400, "Playbooks can't auto-dismiss alerts; use a suppression (it requires a reason and is audited)")
    if body.assign_to and not conn.execute("SELECT 1 FROM users WHERE username=? AND active=1", (body.assign_to,)).fetchone():
        raise HTTPException(400, "Unknown user")
    if not any([body.assign_to, body.set_status, body.add_to_case, body.notify, body.tag]):
        raise HTTPException(400, "Choose at least one action")
    cond = {"rules": body.rules, "min_severity": max(1, min(5, body.min_severity)), "stores": body.stores, "cashiers": body.cashiers}
    act = {"assign_to": body.assign_to, "set_status": body.set_status, "add_to_case": body.add_to_case, "notify": body.notify,
           "tag": re.sub(r"[^\w\- ]", "", body.tag)[:40]}
    return json.dumps(cond), json.dumps(act)


@router.get("/automations")
def list_automations(user: User = Depends(current_user)):
    return [dict(r) | {"conditions": json.loads(r["conditions"]), "actions": json.loads(r["actions"])}
            for r in conn.execute("SELECT * FROM automations ORDER BY id")]


@router.post("/automations")
def add_automation(body: AutomationIn, user: User = Depends(need("admin"))):
    cond, act = _auto_payload(body)
    cur = conn.execute("INSERT INTO automations(name, enabled, conditions, actions, created_by) VALUES(?,?,?,?,?)",
                       (body.name.strip()[:80], int(body.enabled), cond, act, user.name))
    conn.commit()
    audit(conn, user.name, "created playbook", body.name[:80])
    return {"id": cur.lastrowid}


@router.put("/automations/{aid}")
def edit_automation(aid: int, body: AutomationIn, user: User = Depends(need("admin"))):
    cond, act = _auto_payload(body)
    conn.execute("UPDATE automations SET name=?, enabled=?, conditions=?, actions=? WHERE id=?",
                 (body.name.strip()[:80], int(body.enabled), cond, act, aid))
    conn.commit()
    audit(conn, user.name, "updated playbook", body.name[:80])
    return {"ok": True}


@router.delete("/automations/{aid}")
def del_automation(aid: int, user: User = Depends(need("admin"))):
    conn.execute("DELETE FROM automations WHERE id=?", (aid,))
    conn.commit()
    audit(conn, user.name, "deleted playbook", f"#{aid}")
    return {"ok": True}
