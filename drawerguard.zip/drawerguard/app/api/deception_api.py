"""Canaries (honeytokens) and the watchlist."""
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..auth import User
from ..db import audit, rows
from ..deps import after_import, conn, current_user, need, scope
from ..detection.deception import CANARY_KINDS, KIND_LABEL

router = APIRouter(prefix="/api", tags=["Deception & watchlist"])


def _in(xs):
    return f"({','.join('?' * len(xs))})"


class CanaryIn(BaseModel):
    store: str = ""
    kind: str
    value: str = Field(min_length=2, max_length=80)
    note: str = Field(default="", max_length=300)


@router.get("/canaries")
def list_canaries(user: User = Depends(current_user)):
    st = scope(user)
    out = rows(conn.execute(f"SELECT * FROM canaries WHERE store='' OR store IN {_in(st)} ORDER BY id DESC", st))
    for c in out:
        c["hits"] = conn.execute(f"SELECT COUNT(*) n FROM alerts WHERE rule='canary' AND store IN {_in(st)} AND details LIKE ?",
                                 [*st, f'%"canary": "{c["value"]}"%']).fetchone()["n"]
        c["kind_label"] = KIND_LABEL.get(c["kind"], c["kind"])
    return {"canaries": out, "kinds": KIND_LABEL}


@router.post("/canaries")
def add_canary(body: CanaryIn, user: User = Depends(need("admin"))):
    if body.kind not in CANARY_KINDS:
        raise HTTPException(400, f"kind must be one of {', '.join(CANARY_KINDS)}")
    if body.store:
        scope(user, body.store)
    field = CANARY_KINDS[body.kind]
    st = [body.store] if body.store else scope(user)
    used = conn.execute(f"SELECT COUNT(*) n FROM transactions WHERE store IN {_in(st)} AND lower({field}) = lower(?)",
                        [*st, body.value.strip()]).fetchone()["n"] if body.kind != "note" else 0
    if used:
        raise HTTPException(400, f"'{body.value}' already appears in {used} real transactions: pick a value nobody uses")
    try:
        cur = conn.execute("INSERT INTO canaries(store, kind, value, note, created_by) VALUES(?,?,?,?,?)",
                           (body.store, body.kind, body.value.strip(), body.note, user.name))
    except Exception as e:
        raise HTTPException(400, "That canary already exists") from e
    conn.commit()
    audit(conn, user.name, "planted canary", f"{body.kind}:{body.value} ({body.store or 'all stores'})")
    res = after_import(None if not body.store else [body.store])        # catch earlier use as well
    return {"id": cur.lastrowid, "new_alerts": res["new_count"]}


@router.patch("/canaries/{cid}")
def toggle_canary(cid: int, enabled: bool, user: User = Depends(need("admin"))):
    conn.execute("UPDATE canaries SET enabled=? WHERE id=?", (1 if enabled else 0, cid))
    conn.commit()
    audit(conn, user.name, "enabled canary" if enabled else "disabled canary", str(cid))
    return {"ok": True}


@router.delete("/canaries/{cid}")
def delete_canary(cid: int, user: User = Depends(need("admin"))):
    conn.execute("DELETE FROM canaries WHERE id=?", (cid,))
    conn.commit()
    audit(conn, user.name, "deleted canary", str(cid))
    return {"ok": True}


class WatchIn(BaseModel):
    store: str
    cashier: str = Field(min_length=1, max_length=120)
    reason: str = Field(min_length=3, max_length=300)
    days: int = Field(default=30, ge=0, le=365)          # 0 = until removed


@router.get("/watchlist")
def list_watch(store: str = "", user: User = Depends(current_user)):
    st = scope(user, store)
    out = rows(conn.execute(f"SELECT * FROM watchlist WHERE store IN {_in(st)} ORDER BY created_at DESC", st))
    today = date.today().isoformat()
    for w in out:
        w["active"] = not w["until"] or w["until"] >= today
        w["alerts_since"] = conn.execute("SELECT COUNT(*) n FROM alerts WHERE store=? AND cashier=? AND created_at>=?",
                                         (w["store"], w["cashier"], w["created_at"])).fetchone()["n"]
    return out


@router.post("/watchlist")
def add_watch(body: WatchIn, user: User = Depends(need("review"))):
    scope(user, body.store)
    until = (date.today() + timedelta(days=body.days)).isoformat() if body.days else None
    conn.execute("""INSERT INTO watchlist(store, cashier, reason, until, created_by) VALUES(?,?,?,?,?)
                    ON CONFLICT(store, cashier) DO UPDATE SET reason=excluded.reason, until=excluded.until,
                    created_by=excluded.created_by, created_at=CURRENT_TIMESTAMP""",
                 (body.store, body.cashier, body.reason, until, user.name))
    conn.commit()
    audit(conn, user.name, "added to watchlist", f"{body.cashier} ({body.store}) until {until or 'removed'}: {body.reason}")
    return {"ok": True, "until": until}


@router.delete("/watchlist/{wid}")
def del_watch(wid: int, user: User = Depends(need("review"))):
    w = conn.execute("SELECT * FROM watchlist WHERE id=?", (wid,)).fetchone()
    if not w:
        raise HTTPException(404)
    scope(user, w["store"])
    conn.execute("DELETE FROM watchlist WHERE id=?", (wid,))
    conn.commit()
    audit(conn, user.name, "removed from watchlist", f"{w['cashier']} ({w['store']})")
    return {"ok": True}
