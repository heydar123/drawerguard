"""Continuous control monitoring (PCI DSS v4.0.1, NIST CSF 2.0, CIS Controls v8)."""
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse

from .. import compliance
from ..auth import User
from ..db import audit
from ..deps import conn, current_user, scope

router = APIRouter(prefix="/api/compliance", tags=["Compliance"])


@router.get("")
def assess(user: User = Depends(current_user)):
    return compliance.assess(conn, scope(user))


@router.get("/report", response_class=HTMLResponse)
def report(user: User = Depends(current_user)):
    audit(conn, user.name, "exported control evidence report")
    return compliance.report_html(compliance.assess(conn, scope(user)), user.name)
