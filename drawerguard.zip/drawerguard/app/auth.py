"""Users, roles and sessions.

Roles
  owner    – everything: all stores, users, stores/cameras, detection rules
  manager  – their stores: review alerts, run cases, upload evidence, import data, reports
  auditor  – their stores: read-only
"""
import base64
import hashlib
import hmac
import json
import os
import secrets
import struct
import time
import urllib.parse

ROLES = ("owner", "manager", "auditor")
PERMS = {
    "owner": {"view", "review", "import", "cases", "reports", "admin"},
    "manager": {"view", "review", "import", "cases", "reports"},
    "auditor": {"view"},
}
ITER = 200_000


def hash_pw(pw: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), ITER).hex()
    return f"pbkdf2${ITER}${salt}${h}"


def check_pw(pw: str, stored: str) -> bool:
    try:
        _, it, salt, h = stored.split("$")
        calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), int(it)).hex()
        return hmac.compare_digest(calc, h)
    except ValueError:
        return False


def ensure_owner(conn, default_password: str) -> None:
    if not conn.execute("SELECT 1 FROM users").fetchone():
        conn.execute("INSERT INTO users(username, pw_hash, role, stores, full_name) VALUES(?,?,?,?,?)",
                     ("owner", hash_pw(default_password), "owner", '["*"]', "Owner"))
        conn.commit()


# ------------------------------------------------------------------ TOTP 2FA (RFC 6238, works with any authenticator app)

def totp_new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _hotp(secret: str, counter: int, digits: int = 6) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    h = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return str((struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 10 ** digits).zfill(digits)


def totp_now(secret: str, at: float | None = None) -> str:
    return _hotp(secret, int((at or time.time()) // 30))


def totp_check(secret: str, code: str, last_step: int = 0, at: float | None = None) -> int | None:
    """Return the accepted time-step, or None. Allows ±1 step of clock drift and
    refuses steps at or before last_step (no replay)."""
    code = "".join(ch for ch in str(code or "") if ch.isdigit())
    if len(code) != 6:
        return None
    step = int((at or time.time()) // 30)
    for s in (step - 1, step, step + 1):
        if s > (last_step or 0) and hmac.compare_digest(_hotp(secret, s), code):
            return s
    return None


def totp_uri(secret: str, username: str, issuer: str = "DrawerGuard") -> str:
    return (f"otpauth://totp/{urllib.parse.quote(issuer)}:{urllib.parse.quote(username)}"
            f"?secret={secret}&issuer={urllib.parse.quote(issuer)}&digits=6&period=30")


# ------------------------------------------------------------------ sessions

def pw_stamp(pw_hash: str, epoch: int = 0) -> str:
    """Fingerprint of (password hash, session epoch) baked into every token: changing the
    password or pressing "sign out everywhere" (epoch + 1) invalidates all older sessions."""
    return hashlib.sha256(f"{pw_hash}|{epoch or 0}".encode()).hexdigest()[:12]


def user_stamp(user) -> str:
    return pw_stamp(user["pw_hash"], user["session_epoch"] if "session_epoch" in user.keys() else 0)


def new_api_key() -> tuple[str, str, str]:
    """Return (plaintext key, prefix, sha256). Only the hash is stored; keys have 256 bits of
    entropy so a fast hash is appropriate (no password-style stretching needed)."""
    prefix = secrets.token_hex(4)
    key = f"dg_{prefix}_{secrets.token_urlsafe(32)}"
    return key, prefix, hashlib.sha256(key.encode()).hexdigest()


def hash_api_key(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


class Sessions:
    def __init__(self, secret: str | None = None, hours: int = 12):
        self.secret = secret or os.environ.get("DRAWERGUARD_SECRET") or secrets.token_hex(32)
        self.hours = hours

    def make(self, username: str, stamp: str = "") -> str:
        exp = int(time.time()) + self.hours * 3600
        msg = f"{username}|{stamp}|{exp}"
        sig = hmac.new(self.secret.encode(), msg.encode(), hashlib.sha256).hexdigest()
        return f"{msg}|{sig}"

    def verify(self, token: str) -> tuple[str, str] | None:
        try:
            username, stamp, exp, sig = token.rsplit("|", 3)
        except ValueError:
            return None
        good = hmac.new(self.secret.encode(), f"{username}|{stamp}|{exp}".encode(), hashlib.sha256).hexdigest()
        if hmac.compare_digest(sig, good) and int(exp) > time.time():
            return username, stamp
        return None


class User(dict):
    @property
    def name(self) -> str:
        return self["username"]

    @property
    def role(self) -> str:
        return self["role"]

    def can(self, perm: str) -> bool:
        return perm in PERMS.get(self.role, set())

    def store_ids(self, conn) -> list[str]:
        allowed = json.loads(self.get("stores") or '["*"]')
        all_ids = [r["id"] for r in conn.execute("SELECT id FROM stores ORDER BY name")]
        return all_ids if "*" in allowed or self.role == "owner" else [s for s in all_ids if s in allowed]


def load_user(conn, username: str) -> User | None:
    r = conn.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
    return User(dict(r)) if r else None
