"""Owner notifications.

Channels (configure in .env; anything left blank is skipped):
  * Phone push via ntfy  – install the free "ntfy" app, subscribe to your NTFY_TOPIC. Easiest option.
  * Telegram bot         – TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID
  * Email (SMTP)         – also used for scheduled reports
  * SMS (Twilio)
  * Webhook              – Slack / Teams / Discord
Only alerts at or above NOTIFY_MIN_SEVERITY are sent, bundled into one message.
"""
import base64
import json
import logging
import os
import smtplib
import urllib.parse
import urllib.request
from email.message import EmailMessage

log = logging.getLogger("drawerguard.notify")
SEV_NAME = {1: "Info", 2: "Low", 3: "Medium", 4: "High", 5: "CRITICAL"}


def _env(k, d=""):
    return os.environ.get(k, d).strip()


def channels_status() -> dict:
    return {
        "push (ntfy)": bool(_env("NTFY_TOPIC")),
        "telegram": bool(_env("TELEGRAM_BOT_TOKEN") and _env("TELEGRAM_CHAT_ID")),
        "email": bool(_env("SMTP_HOST") and _env("ALERT_EMAIL_TO")),
        "sms": bool(_env("TWILIO_SID") and _env("ALERT_SMS_TO")),
        "webhook": bool(_env("ALERT_WEBHOOK_URL")),
    }


def format_digest(alerts: list[dict], dashboard_url: str = "") -> tuple[str, str]:
    alerts = sorted(alerts, key=lambda a: (-a["severity"], a.get("ts") or ""))
    subject = f"DrawerGuard: {len(alerts)} suspicious event(s)"
    if alerts and alerts[0]["severity"] >= 5:
        subject = "🚨 " + subject
    lines = []
    for a in alerts[:25]:
        when = (a.get("ts") or "")[:16].replace("T", " ")
        store = f"[{a['store']}] " if a.get("store") and a["store"] != "main" else ""
        lines.append(f"[{SEV_NAME.get(a['severity'], a['severity'])}] {store}{when} · {a.get('cashier') or '-'} · {a['title']}")
    if len(alerts) > 25:
        lines.append(f"…and {len(alerts) - 25} more")
    if dashboard_url:
        lines.append(f"\nReview: {dashboard_url}")
    return subject, "\n".join(lines)


def send_email(subject, body, html_body: str | None = None, attachment: tuple[str, bytes] | None = None):
    host, to = _env("SMTP_HOST"), _env("ALERT_EMAIL_TO")
    if not host or not to:
        return False
    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, _env("SMTP_FROM", _env("SMTP_USER")), to
    msg.set_content(body)
    if html_body:
        msg.add_alternative(html_body, subtype="html")
    if attachment:
        msg.add_attachment(attachment[1], maintype="text", subtype="html", filename=attachment[0])
    with smtplib.SMTP(host, int(_env("SMTP_PORT", "587")), timeout=20) as s:
        s.starttls()
        if _env("SMTP_USER"):
            s.login(_env("SMTP_USER"), _env("SMTP_PASSWORD"))
        s.send_message(msg)
    return True


def send_ntfy(subject, body, priority="high", click=""):
    topic = _env("NTFY_TOPIC")
    if not topic:
        return False
    url = _env("NTFY_SERVER", "https://ntfy.sh").rstrip("/") + "/" + urllib.parse.quote(topic)
    headers = {"Title": subject.encode("ascii", "ignore").decode() or "DrawerGuard", "Priority": priority, "Tags": "rotating_light"}
    if click:
        headers["Click"] = click
    if _env("NTFY_TOKEN"):
        headers["Authorization"] = "Bearer " + _env("NTFY_TOKEN")
    urllib.request.urlopen(urllib.request.Request(url, data=body[:3900].encode(), headers=headers), timeout=20)
    return True


def send_telegram(subject, body):
    tok, chat = _env("TELEGRAM_BOT_TOKEN"), _env("TELEGRAM_CHAT_ID")
    if not tok or not chat:
        return False
    data = urllib.parse.urlencode({"chat_id": chat, "text": f"{subject}\n\n{body}"[:4000]}).encode()
    urllib.request.urlopen(f"https://api.telegram.org/bot{tok}/sendMessage", data=data, timeout=20)
    return True


def send_sms(body):
    sid, token, frm, to = _env("TWILIO_SID"), _env("TWILIO_TOKEN"), _env("TWILIO_FROM"), _env("ALERT_SMS_TO")
    if not all([sid, token, frm, to]):
        return False
    data = urllib.parse.urlencode({"From": frm, "To": to, "Body": body[:1500]}).encode()
    req = urllib.request.Request(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json", data=data)
    req.add_header("Authorization", "Basic " + base64.b64encode(f"{sid}:{token}".encode()).decode())
    urllib.request.urlopen(req, timeout=20)
    return True


def send_webhook(subject, body):
    url = _env("ALERT_WEBHOOK_URL")
    if not url:
        return False
    payload = json.dumps({"text": f"*{subject}*\n{body}"}).encode()
    urllib.request.urlopen(urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"}), timeout=20)
    return True


def broadcast(subject: str, body: str, priority="high") -> dict:
    sent = {}
    for name, fn in (("push (ntfy)", lambda: send_ntfy(subject, body, priority, _env("DASHBOARD_URL"))),
                     ("telegram", lambda: send_telegram(subject, body)),
                     ("email", lambda: send_email(subject, body)),
                     ("sms", lambda: send_sms(subject + "\n" + body)),
                     ("webhook", lambda: send_webhook(subject, body))):
        try:
            sent[name] = fn()
        except Exception as e:
            log.error("Notification via %s failed: %s", name, e)
            sent[name] = f"error: {e}"
    return sent


def notify(conn, alerts: list[dict]) -> dict:
    min_sev = int(_env("NOTIFY_MIN_SEVERITY", "4"))
    due = [a for a in alerts if a["severity"] >= min_sev]
    if not due:
        return {"sent": 0}
    subject, body = format_digest(due, _env("DASHBOARD_URL"))
    sent = broadcast(subject, body, "urgent" if any(a["severity"] >= 5 for a in due) else "high")
    conn.executemany("UPDATE alerts SET notified=1 WHERE fingerprint=?", [(a["fingerprint"],) for a in due])
    conn.commit()
    return {"sent": len(due), "channels": sent}


def email_report(title: str, html_page: str) -> bool:
    try:
        return send_email(title, "Your DrawerGuard report is attached. Open it in a browser and press Ctrl+P to save as PDF.",
                          html_page, (title.replace(" ", "_").replace("—", "-")[:80] + ".html", html_page.encode()))
    except Exception as e:
        log.error("Report email failed: %s", e)
        return False
