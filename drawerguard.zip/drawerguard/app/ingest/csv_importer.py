"""Import SplitPOS (SplitAbility) report exports — CSV or Excel — into DrawerGuard.

The importer auto-detects columns by header name (see config.DEFAULT_COLUMN_MAP),
cleans money values like "$1,234.50" or "(12.00)", understands many date formats,
and maps free-text transaction types ("Open Drawer", "Item Void", "Comp") to
canonical types. Re-importing the same file is safe: rows are de-duplicated by id.
"""
import csv
import hashlib
import io
import re
from datetime import datetime

from ..config import DEFAULT_COLUMN_MAP, PAYMENT_ALIASES, SHIFT_COLUMN_MAP, TIMECLOCK_COLUMN_MAP, TYPE_ALIASES

DATE_FORMATS = [
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M",
    "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M",
    "%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %I:%M %p", "%d/%m/%Y %I:%M %p", "%d/%m/%Y %I:%M:%S %p",
    "%d-%m-%Y %H:%M", "%d.%m.%Y %H:%M", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M",
    "%b %d, %Y %I:%M %p", "%d %b %Y %H:%M", "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y",
]


def _norm(s: str) -> str:
    return re.sub(r"[\s_\-./]+", "", str(s or "").strip().lower())


def detect_columns(headers: list[str], column_map: dict) -> dict:
    """Return {canonical_field: actual_header} for headers that match."""
    normed = {_norm(h): h for h in headers}
    found = {}
    for field, aliases in column_map.items():
        for alias in [field] + aliases:
            if _norm(alias) in normed:
                found[field] = normed[_norm(alias)]
                break
    return found


def parse_money(v) -> float:
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if not s:
        return 0.0
    neg = s.startswith("(") and s.endswith(")") or s.startswith("-") or s.endswith("-")
    s = re.sub(r"[^\d.,]", "", s)
    if s.count(",") and s.count(".") == 0 and len(s.split(",")[-1]) == 2:
        s = s.replace(",", ".")          # European decimal comma
    s = s.replace(",", "")
    try:
        val = float(s) if s else 0.0
    except ValueError:
        val = 0.0
    return -val if neg else val


def detect_dayfirst(values) -> bool:
    """Look at a column of dates like 03/11/2026 to decide day-first vs month-first.
    Defaults to month-first (US) when ambiguous."""
    for v in values:
        m = re.match(r"\s*(\d{1,2})[/.\-](\d{1,2})[/.\-]\d{2,4}", str(v or ""))
        if m:
            a, b = int(m.group(1)), int(m.group(2))
            if a > 12:
                return True
            if b > 12:
                return False
    return False


def parse_dt(v, time_part=None, dayfirst_hint: bool | None = None) -> str | None:
    if v is None or str(v).strip() == "":
        return None
    if isinstance(v, datetime):
        dt = v
    else:
        s = str(v).strip()
        if time_part:
            s = f"{s} {str(time_part).strip()}"
        dt = None
        fmts = DATE_FORMATS
        if dayfirst_hint is not True:
            fmts = [f for f in DATE_FORMATS if not f.startswith("%d/")] + [f for f in DATE_FORMATS if f.startswith("%d/")]
        for fmt in fmts:
            try:
                dt = datetime.strptime(s, fmt)
                break
            except ValueError:
                continue
        if dt is None:
            try:
                dt = datetime.fromisoformat(s.replace("Z", ""))
            except ValueError:
                return None
    return dt.replace(microsecond=0).isoformat()


def _alias_lookup(value: str, aliases: dict, default: str) -> str:
    n = _norm(value)
    if not n:
        return default
    for canon, names in aliases.items():
        if n in (_norm(x) for x in names):
            return canon
    for canon, names in aliases.items():      # substring fallback ("Item Void - Wrong order")
        if any(_norm(x) and _norm(x) in n for x in names):
            return canon
    return default


def map_type(value: str) -> str:
    return _alias_lookup(value, TYPE_ALIASES, "sale")


def map_payment(value: str) -> str:
    if not str(value or "").strip():
        return ""
    return _alias_lookup(value, PAYMENT_ALIASES, "other")


def _truthy(v) -> int:
    return 1 if str(v or "").strip().lower() in ("1", "y", "yes", "true", "sent", "printed", "fired", "x") else 0


def read_table(content: bytes, filename: str) -> tuple[list[str], list[dict]]:
    """Read CSV/TSV/XLSX bytes into (headers, list of row dicts)."""
    if filename.lower().endswith((".xlsx", ".xlsm")):
        try:
            import openpyxl
        except ImportError as e:
            raise ValueError("Excel import needs openpyxl: pip install openpyxl") from e
        wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
        ws = wb.active
        it = ws.iter_rows(values_only=True)
        headers = [str(h or "").strip() for h in next(it)]
        data = [dict(zip(headers, r, strict=False)) for r in it if any(c not in (None, "") for c in r)]
        return headers, data
    text = content.decode("utf-8-sig", errors="replace")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    headers = [h.strip() for h in (reader.fieldnames or [])]
    data = []
    for r in reader:
        clean = {(k or "").strip(): v for k, v in r.items()}
        if any((v or "").strip() for v in clean.values() if isinstance(v, str)):
            data.append(clean)
    return headers, data


def looks_like_shifts(headers: list[str]) -> bool:
    cols = detect_columns(headers, SHIFT_COLUMN_MAP)
    return "counted_cash" in cols or ("expected_cash" in cols and "start_ts" in cols)


def looks_like_timeclock(headers: list[str]) -> bool:
    cols = detect_columns(headers, TIMECLOCK_COLUMN_MAP)
    shift = detect_columns(headers, SHIFT_COLUMN_MAP)
    return "clock_in" in cols and "clock_out" in cols and "employee" in cols \
        and "counted_cash" not in shift and "expected_cash" not in shift and not any(_norm(h) in ("type", "total", "amount") for h in headers)


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(name or "").strip().lower()).strip("-") or "main"


def normalize_transactions(headers, data, column_map=None, store="main") -> tuple[list[dict], list[str]]:
    cmap = detect_columns(headers, column_map or DEFAULT_COLUMN_MAP)
    errors = []
    if "ts" not in cmap:
        raise ValueError(f"Could not find a date/time column. Headers seen: {headers}")
    if "cashier" not in cmap:
        raise ValueError(f"Could not find a cashier/employee column. Headers seen: {headers}")
    out = []
    dayfirst = detect_dayfirst(r.get(cmap["ts"]) for r in data[:500])
    for i, r in enumerate(data, start=2):
        g = lambda f, r=r: r.get(cmap[f]) if f in cmap else None  # noqa: E731
        ts = parse_dt(g("ts"), g("time") if "time" in cmap and cmap["time"] != cmap["ts"] else None, dayfirst)
        if not ts:
            errors.append(f"row {i}: bad date '{g('ts')}'")
            continue
        amount = parse_money(g("amount"))
        ttype = map_type(g("txn_type") or "")
        if ttype == "sale" and amount < 0:
            ttype = "refund"
        rec = {
            "store": slug(g("store")) if g("store") else store,
            "ts": ts,
            "cashier": str(g("cashier") or "").strip() or "UNKNOWN",
            "register": str(g("register") or "").strip(),
            "txn_type": ttype,
            "amount": abs(amount),
            "payment_method": map_payment(g("payment_method")),
            "order_id": str(g("order_id") or "").strip(),
            "original_txn_id": str(g("original_txn_id") or "").strip(),
            "discount_amount": abs(parse_money(g("discount_amount"))),
            "approved_by": str(g("approved_by") or "").strip(),
            "sent_to_kitchen": _truthy(g("sent_to_kitchen")),
            "note": str(g("note") or "").strip()[:500],
        }
        rid = str(g("id") or "").strip()
        if not rid:
            raw = "|".join(str(r.get(h, "")) for h in headers)
            rid = "h" + hashlib.sha1(raw.encode(), usedforsecurity=False).hexdigest()[:16]
        rec["id"] = rid
        out.append(rec)
    return out, errors


def normalize_shifts(headers, data, store="main") -> tuple[list[dict], list[str]]:
    cmap = detect_columns(headers, SHIFT_COLUMN_MAP)
    errors, out = [], []
    dayfirst = detect_dayfirst(r.get(cmap.get("start_ts", ""), "") for r in data[:500])
    for i, r in enumerate(data, start=2):
        g = lambda f, r=r: r.get(cmap[f]) if f in cmap else None  # noqa: E731
        start, end = parse_dt(g("start_ts"), None, dayfirst), parse_dt(g("end_ts"), None, dayfirst)
        if not start:
            errors.append(f"row {i}: bad shift start")
            continue
        out.append({
            "store": slug(g("store")) if g("store") else store,
            "cashier": str(g("cashier") or "").strip() or "UNKNOWN",
            "register": str(g("register") or "").strip(),
            "start_ts": start,
            "end_ts": end or start,
            "opening_float": parse_money(g("opening_float")),
            "expected_cash": parse_money(g("expected_cash")) if g("expected_cash") not in (None, "") else None,
            "counted_cash": parse_money(g("counted_cash")) if g("counted_cash") not in (None, "") else None,
        })
    return out, errors


def normalize_timeclock(headers, data, store="main") -> tuple[list[dict], list[str]]:
    """Timeclock / attendance export: one row per punch pair. When the export carries the
    original (pre-edit) times, the paid minutes added by a manual edit are computed."""
    cmap = detect_columns(headers, TIMECLOCK_COLUMN_MAP)
    errors, out = [], []
    dayfirst = detect_dayfirst(r.get(cmap.get("clock_in", ""), "") for r in data[:500])
    for i, r in enumerate(data, start=2):
        g = lambda f, r=r: r.get(cmap[f]) if f in cmap else None  # noqa: E731
        cin, cout = parse_dt(g("clock_in"), None, dayfirst), parse_dt(g("clock_out"), None, dayfirst)
        if not cin:
            errors.append(f"row {i}: bad clock-in '{g('clock_in')}'")
            continue
        added = 0.0
        oin, oout = parse_dt(g("orig_in"), None, dayfirst), parse_dt(g("orig_out"), None, dayfirst)
        if oin:
            added += (datetime.fromisoformat(oin) - datetime.fromisoformat(cin)).total_seconds() / 60
        if oout and cout:
            added += (datetime.fromisoformat(cout) - datetime.fromisoformat(oout)).total_seconds() / 60
        rate = g("hourly_rate")
        out.append({
            "store": slug(g("store")) if g("store") else store,
            "employee": str(g("employee") or "").strip() or "UNKNOWN",
            "clock_in": cin, "clock_out": cout,
            "device": str(g("device") or "").strip(), "method": str(g("method") or "").strip().lower(),
            "edited_by": str(g("edited_by") or "").strip(), "edit_note": str(g("edit_note") or "").strip()[:300],
            "minutes_added": round(added, 1),
            "hourly_rate": parse_money(rate) if rate not in (None, "") else None,
        })
    return out, errors


TC_COLS = ["store", "employee", "clock_in", "clock_out", "device", "method", "edited_by", "edit_note", "minutes_added", "hourly_rate"]


def store_timeclock(conn, recs: list[dict], source="csv") -> int:
    ensure_stores(conn, (r["store"] for r in recs))
    before = conn.total_changes
    conn.executemany(
        f"""INSERT INTO timeclock({','.join(TC_COLS)}, source) VALUES({','.join('?' * len(TC_COLS))}, ?)
            ON CONFLICT(store, employee, clock_in) DO UPDATE SET clock_out=excluded.clock_out, device=excluded.device,
              method=excluded.method, edited_by=excluded.edited_by, edit_note=excluded.edit_note,
              minutes_added=excluded.minutes_added, hourly_rate=excluded.hourly_rate""",
        [tuple(r[c] for c in TC_COLS) + (source,) for r in recs],
    )
    conn.commit()
    return conn.total_changes - before


TXN_COLS = ["store", "id", "ts", "cashier", "register", "txn_type", "amount", "payment_method", "order_id",
            "original_txn_id", "discount_amount", "approved_by", "sent_to_kitchen", "note"]
SHIFT_COLS = ["store", "cashier", "register", "start_ts", "end_ts", "opening_float", "expected_cash", "counted_cash"]


def ensure_stores(conn, ids) -> None:
    for sid in set(ids):
        conn.execute("INSERT OR IGNORE INTO stores(id, name) VALUES(?, ?)", (sid, sid.replace("-", " ").title()))


PAN_RE = re.compile(r"(?<![\d])(?:\d[ -]?){12,18}\d(?![\d])")


def luhn_ok(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d = d * 2 - 9 if d > 4 else d * 2
        total += d
        alt = not alt
    return total % 10 == 0


def find_pans(text: str) -> list[str]:
    """Card-number-like strings: 13-19 digits (spaces/dashes allowed), a card-brand first digit and a valid Luhn check."""
    out = []
    for m in PAN_RE.finditer(str(text or "")):
        digits = re.sub(r"\D", "", m.group(0))
        if 13 <= len(digits) <= 19 and digits[0] in "3456" and luhn_ok(digits):
            out.append(m.group(0))
    return out


def mask_pans(text: str) -> tuple[str, int]:
    """Mask card numbers typed into free-text fields (PCI DSS 3.4/3.5: don't keep readable PANs). Keeps the last 4."""
    text = str(text or "")
    found = find_pans(text)
    for f in found:
        digits = re.sub(r"\D", "", f)
        text = text.replace(f, "*" * (len(digits) - 4) + digits[-4:])
    return text, len(found)


def store_transactions(conn, recs: list[dict], source="csv") -> int:
    masked = 0
    for r in recs:
        if r.get("note"):
            r["note"], n = mask_pans(r["note"])
            masked += n
    if masked:
        from ..db import audit
        audit(conn, "system", "masked card numbers on import", f"{masked} PAN(s) in notes ({source})")
    ensure_stores(conn, (r["store"] for r in recs))
    before = conn.total_changes
    conn.executemany(
        f"INSERT OR IGNORE INTO transactions({','.join(TXN_COLS)}, source) VALUES({','.join('?' * len(TXN_COLS))}, ?)",
        [tuple(r[c] for c in TXN_COLS) + (source,) for r in recs],
    )
    conn.commit()
    return conn.total_changes - before


def store_shifts(conn, recs: list[dict]) -> int:
    ensure_stores(conn, (r["store"] for r in recs))
    before = conn.total_changes
    conn.executemany(
        f"""INSERT INTO shifts({','.join(SHIFT_COLS)}) VALUES({','.join('?' * len(SHIFT_COLS))})
            ON CONFLICT(store, cashier, register, start_ts) DO UPDATE SET
              end_ts=excluded.end_ts, opening_float=excluded.opening_float,
              expected_cash=excluded.expected_cash, counted_cash=excluded.counted_cash""",
        [tuple(r[c] for c in SHIFT_COLS) for r in recs],
    )
    conn.commit()
    return conn.total_changes - before


def import_file(conn, content: bytes, filename: str, kind: str = "auto", column_map=None, store: str = "main") -> dict:
    import json
    from .adapters import convert as vendor_convert, detect_vendor
    headers, data = read_table(content, filename)
    vendor = None
    if kind in ("square", "toast", "clover"):
        vendor, kind = kind, "transactions"
    elif kind == "auto":
        vendor = detect_vendor(headers)
        kind = "timeclock" if looks_like_timeclock(headers) else "shifts" if looks_like_shifts(headers) else "transactions"
        if vendor:
            kind = "transactions"
    cmap_used = SHIFT_COLUMN_MAP if kind == "shifts" else TIMECLOCK_COLUMN_MAP if kind == "timeclock" else (column_map or DEFAULT_COLUMN_MAP)
    if vendor:
        recs, errors = vendor_convert(vendor, headers, data, store)
        added = store_transactions(conn, recs, source=vendor)
    elif kind == "timeclock":
        recs, errors = normalize_timeclock(headers, data, store)
        added = store_timeclock(conn, recs)
    elif kind == "shifts":
        recs, errors = normalize_shifts(headers, data, store)
        added = store_shifts(conn, recs)
    else:
        recs, errors = normalize_transactions(headers, data, column_map, store)
        added = store_transactions(conn, recs)
    conn.execute(
        "INSERT INTO import_log(store, filename, kind, rows_read, rows_added, errors) VALUES(?,?,?,?,?,?)",
        (store, filename, f"{kind} ({vendor})" if vendor else kind, len(data), added, json.dumps(errors[:50])),
    )
    conn.commit()
    return {"filename": filename, "kind": kind, "vendor": vendor or "splitpos", "store": store, "stores": sorted({r["store"] for r in recs}), "rows_read": len(data), "rows_added": added,
            "columns_detected": {} if vendor else detect_columns(headers, cmap_used),
            "errors": errors[:50]}
