"""Data connectors.

1. InboxWatcher  — watches a folder; any CSV/XLSX export you drop there (or that
   a scheduled email-to-folder rule saves there) is imported automatically.
2. SplitPOSApiConnector — ready for when SplitAbility gives you API access.
   Fill in base URL / key in .env and adjust `_map()` to their JSON fields.
"""
import json
import logging
import os
import shutil
import threading
import time
import urllib.request
from pathlib import Path

from .csv_importer import import_file, map_payment, map_type, parse_dt, store_transactions

log = logging.getLogger("drawerguard.connectors")


class InboxWatcher:
    def __init__(self, conn_factory, inbox: str, on_import=None, interval: int = 30):
        """Files in a sub-folder named after a store id (inbox/harbor/...) go to that store."""
        self.conn_factory = conn_factory
        self.inbox = Path(inbox)
        self.done = self.inbox / "imported"
        self.interval = interval
        self.on_import = on_import
        self._stop = threading.Event()

    def scan_once(self) -> list[dict]:
        self.inbox.mkdir(parents=True, exist_ok=True)
        self.done.mkdir(exist_ok=True)
        results = []
        files = [(f, "main") for f in self.inbox.iterdir()]
        for d in self.inbox.iterdir():
            if d.is_dir() and d.name != "imported":
                files += [(f, d.name) for f in d.iterdir()]
        for f, store in sorted(files):
            if f.is_file() and f.suffix.lower() in (".csv", ".tsv", ".txt", ".xlsx"):
                conn = self.conn_factory()
                try:
                    res = import_file(conn, f.read_bytes(), f.name, store=store)
                    results.append(res)
                    log.info("Imported %s: %s rows added", f.name, res["rows_added"])
                    shutil.move(str(f), str(self.done / f"{int(time.time())}_{f.name}"))
                except Exception as e:  # keep watching even if one file is bad
                    log.error("Failed to import %s: %s", f.name, e)
                    f.rename(f.with_suffix(f.suffix + ".failed"))
        if results and self.on_import:
            self.on_import()
        return results

    def run_forever(self):
        while not self._stop.is_set():
            try:
                self.scan_once()
            except Exception as e:
                log.exception("Inbox scan error: %s", e)
            self._stop.wait(self.interval)

    def start(self):
        threading.Thread(target=self.run_forever, daemon=True, name="inbox-watcher").start()

    def stop(self):
        self._stop.set()


class SplitPOSApiConnector:
    """Pulls transactions from a SplitPOS / SplitAbility API, if your plan includes one.

    SplitAbility has no public API documentation, so endpoint and field names below
    are placeholders. Ask SplitAbility support for: an API key, the transactions /
    audit-log endpoint, and webhook support. Then edit ENDPOINT and _map().
    """
    ENDPOINT = "/transactions?since={since}"

    def __init__(self, base_url: str | None = None, api_key: str | None = None):
        self.base_url = (base_url or os.environ.get("SPLITPOS_API_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("SPLITPOS_API_KEY", "")

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key)

    def fetch(self, since_iso: str) -> list[dict]:
        url = self.base_url + self.ENDPOINT.format(since=since_iso)
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {self.api_key}", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            payload = json.loads(r.read())
        items = payload.get("data", payload) if isinstance(payload, dict) else payload
        return [self._map(x) for x in items]

    @staticmethod
    def _map(x: dict) -> dict:
        return {
            "store": str(x.get("store") or x.get("location") or "main"),
            "id": str(x.get("id") or x.get("receipt_no")),
            "ts": parse_dt(x.get("timestamp") or x.get("created_at")),
            "cashier": str(x.get("staff") or x.get("employee") or "UNKNOWN"),
            "register": str(x.get("device") or x.get("terminal") or ""),
            "txn_type": map_type(x.get("type", "sale")),
            "amount": abs(float(x.get("total") or x.get("amount") or 0)),
            "payment_method": map_payment(x.get("payment_type", "")),
            "order_id": str(x.get("order_id") or x.get("table") or ""),
            "original_txn_id": str(x.get("original_id") or ""),
            "discount_amount": abs(float(x.get("discount") or 0)),
            "approved_by": str(x.get("approved_by") or ""),
            "sent_to_kitchen": 1 if x.get("sent_to_kitchen") else 0,
            "note": str(x.get("reason") or x.get("note") or "")[:500],
        }

    def sync(self, conn) -> int:
        if not self.configured:
            raise RuntimeError("Set SPLITPOS_API_URL and SPLITPOS_API_KEY in .env first")
        r = conn.execute("SELECT MAX(ts) AS m FROM transactions WHERE source='api'").fetchone()
        since = r["m"] or "2000-01-01T00:00:00"
        recs = [x for x in self.fetch(since) if x["ts"]]
        return store_transactions(conn, recs, source="api")
