"""Import adapters for other POS systems: Square, Toast and Clover.

Each adapter recognises a vendor export by its header signature and converts the
rows into DrawerGuard's canonical transaction records (the same shape the SplitPOS
importer produces), so every detection works unchanged.

Supported exports (column names follow the vendors' standard CSV reports; exports
change over time, so check `columns_detected` after the first import):
  * Square  — Transactions report (one row per payment or refund) and the
              Cash Drawer report (No Sale, Paid In / Paid Out events)
  * Toast   — PaymentDetails.csv (payments, refunds, voids) and CashEntries.csv
              (NO_SALE, PAY_OUT, CASH_OUT ...)
  * Clover  — Payments / Transactions export (Result = SUCCESS / REFUND / VOID)
              and the Cash Log (Open drawer, Cash removed ...)
"""
import hashlib

from .csv_importer import _norm, detect_dayfirst, map_payment, parse_dt, parse_money, slug

SIGNATURES = {
    # vendor: list of (required normalised headers) alternatives — any one set must be fully present
    "square": [{"transactionid", "paymentid", "staffname", "eventtype"}, {"transactionid", "grosssales", "netsales", "totalcollected"},
               {"cashdrawer", "eventtype", "description", "amount"}],
    "toast": [{"paymentid", "orderid", "paiddate", "server"}, {"entryid", "action", "cashdrawer", "employee"}],
    "clover": [{"paymentid", "orderid", "tender", "result"}, {"orderid", "tender", "employee", "result"},
               {"cashlog", "employee"}, {"eventtype", "employee", "device", "cashamount"}],
}


def detect_vendor(headers: list[str]) -> str | None:
    hs = {_norm(h) for h in headers}
    for vendor, alternatives in SIGNATURES.items():
        if any(req <= hs for req in alternatives):
            return vendor
    return None


class _Row:
    """Case/spacing-insensitive access to a CSV row."""

    def __init__(self, r: dict):
        self.d = {_norm(k): v for k, v in r.items()}

    def __call__(self, *names, default=""):
        for n in names:
            v = self.d.get(_norm(n))
            if v not in (None, ""):
                return str(v).strip()
        return default


def _rid(vendor, *parts):
    raw = "|".join(str(p) for p in parts)
    return f"{vendor[:2]}" + hashlib.sha1(raw.encode(), usedforsecurity=False).hexdigest()[:16]


def _rec(store, ts, cashier, typ, amount, *, rid, register="", pay="", order="", orig="", disc=0.0, appr="", note=""):
    return {"store": store, "id": rid, "ts": ts, "cashier": cashier or "UNKNOWN", "register": register, "txn_type": typ,
            "amount": round(abs(amount), 2), "payment_method": pay, "order_id": order, "original_txn_id": orig,
            "discount_amount": round(abs(disc), 2), "approved_by": appr, "sent_to_kitchen": 0, "note": note[:500]}


# ------------------------------------------------------------------ Square

SQUARE_CASH_EVENTS = {"no sale": "no_sale", "paid out": "paid_out", "paid in": None, "cash refund": "refund"}


def square(headers, data, store):
    out, errors = [], []
    dayfirst = detect_dayfirst(_Row(r)("Date") for r in data[:300])
    for i, raw in enumerate(data, start=2):
        g = _Row(raw)
        ts = parse_dt(g("Date"), g("Time") or None, dayfirst)
        if not ts:
            errors.append(f"row {i}: bad date")
            continue
        st = slug(g("Location")) if g("Location") else store
        staff, device = g("Staff Name", "Employee", "Team Member"), g("Device Nickname", "Device Name")
        if "cashdrawer" in {_norm(h) for h in headers} or (g("Event Type").lower() in SQUARE_CASH_EVENTS and not g("Transaction ID")):
            typ = SQUARE_CASH_EVENTS.get(g("Event Type").lower())
            if typ is None:
                continue
            out.append(_rec(st, ts, staff, typ, parse_money(g("Amount")), rid=_rid("square", ts, staff, g("Event Type"), g("Amount")),
                            register=device or g("Cash Drawer"), pay="cash", note=g("Description")))
            continue
        event = g("Event Type", default="Payment").lower()
        cash, card = parse_money(g("Cash")), parse_money(g("Card"))
        pay = "cash" if abs(cash) >= abs(card) and cash else map_payment(g("Card Brand") or "card") if card else map_payment(g("Other Tender Type"))
        total = parse_money(g("Total Collected", "Net Total", "Gross Sales"))
        rid = g("Payment ID", "Transaction ID") or _rid("square", ts, staff, total)
        if event.startswith("refund") or total < 0:
            out.append(_rec(st, ts, staff, "refund", total, rid=f"{rid}-R", register=device, pay=pay,
                            order=g("Transaction ID"), note=g("Description", "Details")))   # linked to the sale by transaction id
        else:
            disc = parse_money(g("Discounts"))
            out.append(_rec(st, ts, staff, "sale", total, rid=rid, register=device, pay=pay, order=g("Transaction ID"), disc=disc,
                            note=g("Description")))
            pr = parse_money(g("Partial Refunds"))
            if pr:
                out.append(_rec(st, ts, staff, "refund", pr, rid=f"{rid}-PR", register=device, pay=pay, orig=rid, note="Partial refund"))
    return out, errors


# ------------------------------------------------------------------ Toast

TOAST_ACTIONS = {"no_sale": "no_sale", "pay_out": "paid_out", "cash_out": "paid_out", "tip_out": None, "cash_in": None,
                 "cash_collected": None, "close_out_exact": None, "close_out_overage": None, "close_out_shortage": None}


def toast(headers, data, store):
    out, errors = [], []
    hs = {_norm(h) for h in headers}
    if "entryid" in hs:                                           # CashEntries.csv
        for i, raw in enumerate(data, start=2):
            g = _Row(raw)
            ts = parse_dt(g("Created Date", "Date"))
            typ = TOAST_ACTIONS.get(g("Action").lower().replace(" ", "_"))
            if not ts:
                errors.append(f"row {i}: bad date")
                continue
            if typ is None:
                continue
            out.append(_rec(slug(g("Location")) if g("Location") else store, ts, g("Employee"), typ, parse_money(g("Amount")),
                            rid=f"tc{g('Entry Id') or _rid('toast', ts, g('Employee'))}", register=g("Cash Drawer"), pay="cash",
                            appr=g("Employee 2"), note=g("Payout Reason", "No Sale Reason", "Comment")))
        return out, errors
    dayfirst = detect_dayfirst(_Row(r)("Paid Date") for r in data[:300])
    for i, raw in enumerate(data, start=2):                       # PaymentDetails.csv
        g = _Row(raw)
        ts = parse_dt(g("Paid Date", "Order Date"), None, dayfirst)
        if not ts:
            errors.append(f"row {i}: bad date")
            continue
        st = slug(g("Location")) if g("Location") else store
        server, pid, order = g("Server"), g("Payment Id"), g("Order #", "Order Id")
        typ_raw = g("Type").lower()
        pay = "cash" if typ_raw == "cash" else "card" if typ_raw in ("credit", "debit", "card") else map_payment(typ_raw)
        amount = parse_money(g("Amount"))
        status = g("Status").upper()
        register = g("Cash Drawer", "Revenue Center")
        out.append(_rec(st, ts, server, "sale", amount, rid=f"tp{pid or _rid('toast', ts, server, amount)}", register=register, pay=pay,
                        order=order))
        if parse_money(g("Refund Amount")) or g("Refunded").lower() in ("yes", "true", "1", "full", "partial"):
            rts = parse_dt(g("Refund Date"), None, dayfirst) or ts
            out.append(_rec(st, rts, server, "refund", parse_money(g("Refund Amount")) or amount, rid=f"tp{pid}-R", register=register,
                            pay=pay, order=order, orig=f"tp{pid}"))
        if g("Void User") or status == "VOIDED":
            vts = parse_dt(g("Void Date"), None, dayfirst) or ts
            out.append(_rec(st, vts, g("Void User") or server, "void", amount, rid=f"tp{pid}-V", register=register, order=order,
                            appr=g("Void Approver"), note="Payment voided"))
    return out, errors


# ------------------------------------------------------------------ Clover

CLOVER_CASH = {"open drawer": "no_sale", "no sale": "no_sale", "cash removed": "paid_out", "paid out": "paid_out"}


def clover(headers, data, store):
    out, errors = [], []
    hs = {_norm(h) for h in headers}
    cash_log = "cashlog" in hs or "cashamount" in hs
    dayfirst = detect_dayfirst(_Row(r)("Date", "Payment Date") for r in data[:300])
    for i, raw in enumerate(data, start=2):
        g = _Row(raw)
        ts = parse_dt(g("Date", "Payment Date", "Created Time", "Timestamp"), None, dayfirst)
        if not ts:
            errors.append(f"row {i}: bad date")
            continue
        st = slug(g("Location", "Merchant")) if g("Location", "Merchant") else store
        emp, device = g("Employee", "Employee Name"), g("Device", "Device Name")
        if cash_log:
            typ = CLOVER_CASH.get(g("Event Type", "Type", "Cash Log").lower())
            if typ:
                amt = parse_money(g("Cash Amount", "Amount"))
                out.append(_rec(st, ts, emp, typ, amt, rid=_rid("clover", ts, emp, typ, amt), register=device, pay="cash", note=g("Note")))
            continue
        result = g("Result", "Status", default="SUCCESS").upper()
        pid, order = g("Payment ID", "Id"), g("Order ID")
        amount = parse_money(g("Amount", "Total"))
        pay = map_payment(g("Tender"))
        rid = f"cl{pid or _rid('clover', ts, emp, amount)}"
        typ = "refund" if result in ("REFUND", "REFUNDED") or amount < 0 else "void" if result in ("VOID", "VOIDED") else "sale"
        if typ == "refund":
            out.append(_rec(st, ts, emp, "refund", amount, rid=rid + "-R", register=device, pay=pay, order=order,
                            orig=f"cl{g('Original Payment ID')}" if g("Original Payment ID") else "", note=g("Note", "Reason")))
        else:
            out.append(_rec(st, ts, emp, typ, amount, rid=rid, register=device, pay=pay, order=order, disc=parse_money(g("Discount")),
                            note=g("Note")))
            ra = parse_money(g("Refund Amount", "Refunded Amount"))
            if ra and typ == "sale":
                out.append(_rec(st, ts, emp, "refund", ra, rid=rid + "-R", register=device, pay=pay, order=order, orig=rid))
    return out, errors


ADAPTERS = {"square": square, "toast": toast, "clover": clover}


def convert(vendor: str, headers, data, store="main"):
    return ADAPTERS[vendor](headers, data, store)
