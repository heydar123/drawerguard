"""Incident response for cases, following the NIST SP 800-61 incident-handling lifecycle.

A case moves through Detection & analysis → Containment → Eradication → Recovery →
Post-incident activity. Each phase has a checklist written for POS cash fraud,
every step is timestamped, and the module rebuilds a single attack timeline from
alerts, the suspicious transactions, timeclock punches, evidence and analyst notes.
From that it derives dwell time (first fraud → detection), time to contain and
time to close, recommends preventive controls from the detections that fired, and
renders a printable incident report.
"""
import html
import json
from datetime import datetime, timezone

from .detection.catalog import meta

PHASES = [
    ("detection", "Detection & analysis"),
    ("containment", "Containment"),
    ("eradication", "Eradication"),
    ("recovery", "Recovery"),
    ("post_incident", "Post-incident activity"),
]
PHASE_KEYS = [p for p, _ in PHASES]

CHECKLIST = {
    "detection": [
        ("verify_cctv", "Verify the key alerts against CCTV footage"),
        ("timeline", "Review the till timeline around each alert"),
        ("scope", "Scope it: other tills, other dates, other people (collusion?)"),
        ("evidence", "Preserve evidence (CCTV clips, receipts) with SHA-256 hashes"),
        ("estimate", "Estimate the loss so far"),
    ],
    "containment": [
        ("remove_cash", "Remove the person from cash handling / overrides"),
        ("reset_pins", "Reset their POS PIN and any manager approval codes they know"),
        ("watchlist", "Put the till and person on a watchlist (tighter thresholds)"),
        ("notify", "Inform the owner / HR; follow your disciplinary policy"),
    ],
    "eradication": [
        ("fix_control", "Fix the control gap that allowed it (see recommended controls)"),
        ("shared_logins", "Remove shared logins; personal PINs only"),
        ("review_peers", "Check that no one else used the same method"),
    ],
    "recovery": [
        ("quantify", "Quantify the final loss and any recovery"),
        ("recover", "Recover funds (repayment, insurance, police report if appropriate)"),
        ("monitor", "Monitor for 30 days after the fix"),
    ],
    "post_incident": [
        ("lessons", "Hold a lessons-learned review"),
        ("tune", "Tune detections (thresholds, suppressions, new custom rule)"),
        ("train", "Update staff training and written procedures"),
        ("close", "Close the case with an outcome"),
    ],
}

CONTROLS = {
    "no_sale_excess": "Require a manager PIN and a reason code for No Sale; review No Sale counts daily.",
    "no_sale_after_cash": "Disable No Sale for cashiers; give change from the open drawer during the sale only.",
    "no_sale_isolated": "Point a camera at each drawer; restrict No Sale to managers.",
    "post_payment_void": "Block voids after payment without a manager PIN; print a void slip that must be signed.",
    "unmatched_refund": "Refunds only against an original receipt (scan the barcode); no blind refunds.",
    "refund_exceeds_original": "Cap refunds at the original amount in the POS settings.",
    "cash_refund_on_card_sale": "Force refunds to the original tender.",
    "refund_own_sale_quick": "A second person must approve refunds of your own sales.",
    "round_amount_refund": "Require the customer's name and phone for every refund; call back a sample weekly.",
    "excess_discount": "Discount above 20% needs a manager PIN; publish the comp policy.",
    "unapproved_override": "Make manager approval mandatory for all overrides above $20.",
    "self_approved": "Managers cannot approve their own transactions (segregation of duties).",
    "cancel_after_kitchen": "Kitchen cancellations need a manager PIN and a reason.",
    "paid_out": "Paid-outs only with a receipt attached and a manager PIN.",
    "off_hours": "Lock the POS outside opening hours; alarm on drawer opens after close.",
    "cash_shortage": "Blind cash counts by two people; drop excess cash into the safe during the shift.",
    "repeat_shortage": "Assign one person per drawer per shift; count at every handover.",
    "missing_count": "No clock-out until the blind count is entered.",
    "peer_outlier": "Review the cashier's override rights against their role.",
    "low_cash_ratio": "Random receipt checks; 'free meal if you don't get a receipt' signage.",
    "approver_concentration": "Rotate approvers; refunds over $25 need a second manager; review approver x cashier monthly.",
    "correlated_shift": "Treat as a priority: full shift review and immediate containment.",
    "ai_anomaly": "Use the AI drivers to decide which control above applies.",
    "behavior_change": "Find out what changed (role, rota, personal situation) and review closely for 30 days.",
    "iforest_anomaly": "Use the ML drivers to decide which control above applies.",
    "buddy_punch": "Biometric or photo-capture time clock; no punching for others (written policy).",
    "ghost_employee": "Verify every employee on payroll against ID and tax records; separate hiring from payroll.",
    "clocked_out_activity": "Auto-logout after inactivity; POS login only while clocked in.",
    "clock_padding": "Paid time starts at the rota time unless a manager approves early starts.",
    "timecard_edit": "Two-person approval for timecard edits that add time; weekly edit report to the owner.",
}


def _ts(v) -> str | None:
    return (v or "")[:19].replace(" ", "T") or None


def _hours_between(a, b):
    if not a or not b:
        return None
    try:
        return round((datetime.fromisoformat(b[:19]) - datetime.fromisoformat(a[:19])).total_seconds() / 3600, 1)
    except ValueError:
        return None


def load_ir(case: dict) -> dict:
    try:
        ir = json.loads(case.get("ir") or "{}")
    except ValueError:
        ir = {}
    ir.setdefault("checklist", {})
    ir.setdefault("phase_times", {})
    ir.setdefault("root_cause", "")
    ir.setdefault("lessons", "")
    ir.setdefault("controls", [])
    return ir


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def timeline(conn, case: dict, ir: dict, limit_txns: int = 120) -> list[dict]:
    cid, cashier, store = case["id"], case["cashier"], case["store"]
    ev = []
    alerts = conn.execute("SELECT * FROM alerts WHERE case_id=? ORDER BY ts", (cid,)).fetchall()
    txn_ids = [a["txn_id"] for a in alerts if a["txn_id"]]
    for a in alerts:
        m = meta(a["rule"])
        ev.append({"ts": _ts(a["ts"]), "kind": "alert", "severity": a["severity"], "title": a["title"],
                   "detail": f"{m.get('id')} · status {a['status']}", "ref": a["id"]})
    if txn_ids:
        q = f"SELECT * FROM transactions WHERE store=? AND id IN ({','.join('?' * len(txn_ids[:limit_txns]))})"
        for t in conn.execute(q, [store, *txn_ids[:limit_txns]]):
            ev.append({"ts": _ts(t["ts"]), "kind": "transaction",
                       "title": f"{t['txn_type'].replace('_', ' ')} ${t['amount']:.2f}" + (f" ({t['payment_method']})" if t["payment_method"] else ""),
                       "detail": f"receipt {t['id']} · {t['register'] or ''}" + (f" · approved by {t['approved_by']}" if t["approved_by"] else ""),
                       "ref": t["id"]})
    days = sorted({(a["ts"] or "")[:10] for a in alerts if a["ts"]})
    if days:
        q = f"SELECT * FROM timeclock WHERE store=? AND employee=? AND substr(clock_in,1,10) IN ({','.join('?' * len(days))})"
        for p in conn.execute(q, [store, cashier, *days]):
            ev.append({"ts": _ts(p["clock_in"]), "kind": "timeclock", "title": f"Clocked in ({p['device'] or 'clock'})",
                       "detail": f"out {(p['clock_out'] or '')[11:16]}" + (f" · edited by {p['edited_by']}" if p["edited_by"] else "")})
    for e in conn.execute("SELECT * FROM case_events WHERE case_id=?", (cid,)):
        ev.append({"ts": _ts(e["created_at"]), "kind": "case", "title": e["body"], "detail": f"{e['kind']} · {e['author'] or ''}"})
    for e in conn.execute("SELECT * FROM evidence WHERE case_id=? OR alert_id IN (SELECT id FROM alerts WHERE case_id=?)", (cid, cid)):
        ev.append({"ts": _ts(e["created_at"]), "kind": "evidence", "title": f"Evidence: {e['filename']}",
                   "detail": f"sha256 {(e['sha256'] or '')[:16]}… · {e['uploaded_by'] or ''}"})
    labels = dict(PHASES)
    for ph, ts in ir["phase_times"].items():
        ev.append({"ts": _ts(ts), "kind": "phase", "title": f"Phase: {labels.get(ph, ph)}", "detail": "incident response"})
    ev.sort(key=lambda x: x["ts"] or "")
    return ev


def metrics(conn, case: dict, ir: dict) -> dict:
    r = conn.execute("SELECT MIN(ts) first_ts, MIN(created_at) detected, MAX(ts) last_ts, COUNT(*) n, SUM(amount) amt "
                     "FROM alerts WHERE case_id=?", (case["id"],)).fetchone()
    first, detected = _ts(r["first_ts"]), _ts(r["detected"])
    contained = ir["phase_times"].get("containment")
    closed = ir["phase_times"].get("post_incident") if case["status"] != "open" else None
    return {
        "first_activity": first, "last_activity": _ts(r["last_ts"]), "detected": detected, "opened": _ts(case["created_at"]),
        "contained": contained, "closed": closed,
        "dwell_hours": _hours_between(first, detected),
        "time_to_contain_hours": _hours_between(_ts(case["created_at"]), contained),
        "alerts": r["n"], "value_at_risk": round(r["amt"] or 0, 2),
        "loss": case.get("loss_amount") or 0, "recovered": case.get("recovered") or 0,
    }


def recommended_controls(conn, cid: int) -> list[dict]:
    rules = [r["rule"] for r in conn.execute("SELECT rule, COUNT(*) n FROM alerts WHERE case_id=? GROUP BY rule ORDER BY n DESC", (cid,))]
    out, seen = [], set()
    for rule in rules:
        text = CONTROLS.get(rule)
        if text and text not in seen:
            seen.add(text)
            out.append({"rule": rule, "id": meta(rule).get("id"), "control": text})
    return out


def view(conn, case: dict) -> dict:
    ir = load_ir(case)
    phase = case.get("phase") or "detection"
    steps = []
    for ph, label in PHASES:
        items = [{"key": f"{ph}.{k}", "label": t, **ir["checklist"].get(f"{ph}.{k}", {"done": False})} for k, t in CHECKLIST[ph]]
        steps.append({"phase": ph, "label": label, "items": items, "done": sum(1 for i in items if i["done"]), "total": len(items),
                      "entered": ir["phase_times"].get(ph), "current": ph == phase})
    return {"phase": phase, "phases": steps, "root_cause": ir["root_cause"], "lessons": ir["lessons"],
            "controls_chosen": ir["controls"], "controls_recommended": recommended_controls(conn, case["id"]),
            "metrics": metrics(conn, case, ir), "timeline": timeline(conn, case, ir)}


def _e(v) -> str:
    return html.escape(str(v if v is not None else "—"))


def report_html(conn, case: dict, analyst: str) -> str:
    v = view(conn, case)
    m = v["metrics"]
    rows_tl = "".join(f"<tr><td>{_e(x['ts'])}</td><td><span class=k>{_e(x['kind'])}</span></td><td>{_e(x['title'])}"
                      f"<div class=d>{_e(x.get('detail'))}</div></td></tr>" for x in v["timeline"][:300])
    phases = "".join(f"<li class='{'cur' if p['current'] else ''}'><b>{_e(p['label'])}</b> — {p['done']}/{p['total']} steps"
                     f"{' · entered ' + _e(p['entered']) if p['entered'] else ''}<ul>"
                     + "".join(f"<li>{'☑' if i['done'] else '☐'} {_e(i['label'])}"
                               f"{' — ' + _e(i.get('by')) + ' ' + _e(i.get('at')) if i['done'] else ''}</li>" for i in p["items"])
                     + "</ul></li>" for p in v["phases"])
    controls = "".join(f"<li><b>{_e(c['id'])}</b> {_e(c['control'])}</li>" for c in v["controls_recommended"]) or "<li>—</li>"
    chosen = "".join(f"<li>{_e(c)}</li>" for c in v["controls_chosen"]) or "<li>None recorded yet</li>"
    ev = conn.execute("SELECT filename, sha256, uploaded_by, created_at FROM evidence WHERE case_id=? OR alert_id IN "
                      "(SELECT id FROM alerts WHERE case_id=?)", (case["id"], case["id"])).fetchall()
    evid = "".join(f"<tr><td>{_e(e['filename'])}</td><td class=mono>{_e(e['sha256'])}</td><td>{_e(e['uploaded_by'])}</td>"
                   f"<td>{_e(e['created_at'])}</td></tr>" for e in ev) or "<tr><td colspan=4>No evidence uploaded</td></tr>"
    status = {"open": "Open", "closed_theft": "Closed — theft confirmed", "closed_cleared": "Closed — cleared"}.get(case["status"], case["status"])
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Incident report — case #{case['id']}</title>
<style>body{{font:14px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;max-width:900px;margin:30px auto;padding:0 20px;color:#0f172a}}
h1{{font-size:24px;margin:0}}h2{{font-size:16px;border-bottom:2px solid #e2e8f0;padding-bottom:4px;margin-top:28px}}
.meta{{color:#64748b}}table{{width:100%;border-collapse:collapse;font-size:12.5px}}td,th{{border-bottom:1px solid #e2e8f0;padding:5px 6px;text-align:left;vertical-align:top}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.kpi{{border:1px solid #e2e8f0;border-radius:8px;padding:10px}}
.kpi b{{display:block;font-size:20px}}.k{{background:#eef2ff;color:#3730a3;border-radius:4px;padding:1px 6px;font-size:11px}}
.d{{color:#64748b;font-size:11.5px}}.mono{{font-family:ui-monospace,monospace;font-size:11px;word-break:break-all}}
li.cur>b{{color:#2563eb}}.pre{{white-space:pre-wrap;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:10px}}
.bar{{display:flex;gap:8px}}@media print{{.noprint{{display:none}}body{{margin:0}}}}</style></head><body>
<div class="noprint bar" style="margin-bottom:16px"><button onclick="print()">🖨️ Print / save as PDF</button></div>
<h1>Incident report — case #{case['id']}: {_e(case['title'])}</h1>
<div class=meta>Store {_e(case['store'])} · subject {_e(case['cashier'])} · status {_e(status)} · current phase {_e(dict(PHASES).get(v['phase']))}<br>
Prepared by {_e(analyst)} on {now()[:16].replace('T', ' ')} UTC with DrawerGuard. Lifecycle: NIST SP 800-61 incident handling.</div>
<h2>1. Executive summary</h2>
<div class=grid>
<div class=kpi>Alerts<b>{m['alerts']}</b></div><div class=kpi>Value at risk<b>${m['value_at_risk']:,.2f}</b></div>
<div class=kpi>Confirmed loss<b>${m['loss']:,.2f}</b></div><div class=kpi>Recovered<b>${m['recovered']:,.2f}</b></div>
<div class=kpi>First suspicious activity<b style="font-size:14px">{_e(m['first_activity'])}</b></div>
<div class=kpi>Detected<b style="font-size:14px">{_e(m['detected'])}</b></div>
<div class=kpi>Dwell time<b>{_e(m['dwell_hours'])} h</b></div><div class=kpi>Time to contain<b>{_e(m['time_to_contain_hours'])} h</b></div>
</div>
<h2>2. Root cause</h2><div class=pre>{_e(v['root_cause'] or 'Not recorded yet.')}</div>
<h2>3. Response by phase</h2><ol>{phases}</ol>
<h2>4. Recommended controls (from the detections that fired)</h2><ul>{controls}</ul>
<h2>5. Controls adopted</h2><ul>{chosen}</ul>
<h2>6. Lessons learned</h2><div class=pre>{_e(v['lessons'] or 'Not recorded yet.')}</div>
<h2>7. Evidence (chain of custody)</h2><table><tr><th>File</th><th>SHA-256</th><th>By</th><th>When</th></tr>{evid}</table>
<h2>8. Timeline</h2><table><tr><th style="width:150px">Time</th><th>Type</th><th>Event</th></tr>{rows_tl}</table>
<p class=meta style="margin-top:24px">Alerts are investigative leads, not proof. Decisions about employees must follow employment law and your own policies.</p>
</body></html>"""
