"""Case-management integrations: TheHive 5 and Jira.

  * TheHive   THEHIVE_URL + THEHIVE_API_KEY: new alerts at or above THEHIVE_MIN_SEVERITY are
              created as TheHive alerts (with observables), and a case can be pushed as a
              TheHive case.
  * Jira      JIRA_URL + JIRA_USER + JIRA_API_TOKEN + JIRA_PROJECT: a case can be pushed as a
              Jira issue (REST API v2, basic auth with an API token).

Every push is recorded in external_refs (system, local id, external id, link). Network errors
never break detection: they are logged and returned.
"""
import base64
import json
import logging
import os
import urllib.error
import urllib.request
from datetime import datetime

from .detection.catalog import meta

log = logging.getLogger("drawerguard.integrations")
TH_SEV = {1: 1, 2: 1, 3: 2, 4: 3, 5: 4}          # DrawerGuard 1-5 → TheHive 1-4 (low … critical)


def _env(k, d=""):
    return os.environ.get(k, d).strip()


def configured() -> dict:
    return {"thehive": bool(_env("THEHIVE_URL") and _env("THEHIVE_API_KEY")),
            "jira": bool(_env("JIRA_URL") and _env("JIRA_USER") and _env("JIRA_API_TOKEN") and _env("JIRA_PROJECT"))}


def _post(url: str, body: dict, headers: dict, timeout=15) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body, default=str).encode(), method="POST",
                                 headers={"Content-Type": "application/json", "Accept": "application/json", **headers})
    # URLs come from the operator's .env
    with urllib.request.urlopen(req, timeout=timeout) as r:  # nosec B310
        raw = r.read()
    return json.loads(raw or b"{}")


def _epoch_ms(ts):
    try:
        return int(datetime.fromisoformat(str(ts)[:19]).timestamp() * 1000)
    except (TypeError, ValueError):
        return int(datetime.now().timestamp() * 1000)


# ------------------------------------------------------------------ TheHive

def thehive_alert_body(a: dict) -> dict:
    m = meta(a["rule"])
    obs = [{"dataType": "other", "data": a["cashier"], "tags": ["cashier"]}] if a.get("cashier") else []
    if a.get("txn_id"):
        obs.append({"dataType": "other", "data": f"receipt:{a['txn_id']}", "tags": ["receipt"]})
    if a.get("register"):
        obs.append({"dataType": "hostname", "data": a["register"], "tags": ["till"]})
    return {
        "type": "drawerguard", "source": "DrawerGuard", "sourceRef": str(a.get("id") or a.get("fingerprint"))[:128],
        "title": a["title"][:250], "severity": TH_SEV.get(a["severity"], 2), "date": _epoch_ms(a.get("ts")),
        "tags": ["pos-fraud", m.get("id", ""), f"store:{a.get('store', '')}"],
        "description": f"**{m.get('id')}**: {a['title']}\n\n- Store: {a.get('store')}\n- Cashier: {a.get('cashier')}\n- Till: {a.get('register')}\n"
                       f"- Amount: ${a.get('amount') or 0:,.2f}\n- ACFE: {m.get('acfe', '')}\n\n**Triage:** {m.get('triage', '')}",
        "observables": obs,
    }


def send_thehive_alerts(alerts: list[dict]) -> dict:
    if not configured()["thehive"]:
        return {}
    min_sev = int(_env("THEHIVE_MIN_SEVERITY", "4"))
    url = _env("THEHIVE_URL").rstrip("/") + "/api/v1/alert"
    sent, errors, refs = 0, [], []
    for a in alerts:
        if a["severity"] < min_sev:
            continue
        try:
            r = _post(url, thehive_alert_body(a), {"Authorization": f"Bearer {_env('THEHIVE_API_KEY')}"})
            sent += 1
            refs.append((a.get("id"), r.get("_id") or r.get("id")))
        except (urllib.error.URLError, OSError, ValueError) as e:
            errors.append(str(e))
            log.error("TheHive alert failed: %s", e)
    return {"sent": sent, "errors": errors[:5], "refs": refs}


def thehive_case(case: dict, alerts: list[dict]) -> dict:
    url = _env("THEHIVE_URL").rstrip("/") + "/api/v1/case"
    body = {"title": f"DrawerGuard case #{case['id']}: {case['title']}"[:250], "severity": max((TH_SEV.get(a["severity"], 2) for a in alerts), default=2),
            "tags": ["pos-fraud", f"store:{case['store']}", f"cashier:{case['cashier']}"], "tlp": 2, "pap": 2,
            "description": _case_text(case, alerts, markdown=True)}
    r = _post(url, body, {"Authorization": f"Bearer {_env('THEHIVE_API_KEY')}"})
    ext = str(r.get("_id") or r.get("id") or r.get("number") or "")
    return {"external_id": ext, "url": f"{_env('THEHIVE_URL').rstrip('/')}/cases/{ext}/details" if ext else ""}


# ------------------------------------------------------------------ Jira

def jira_issue(case: dict, alerts: list[dict]) -> dict:
    base = _env("JIRA_URL").rstrip("/")
    tok = base64.b64encode(f"{_env('JIRA_USER')}:{_env('JIRA_API_TOKEN')}".encode()).decode()
    body = {"fields": {"project": {"key": _env("JIRA_PROJECT")}, "issuetype": {"name": _env("JIRA_ISSUE_TYPE", "Task")},
                       "summary": f"[DrawerGuard] Case #{case['id']}: {case['title']}"[:250],
                       "description": _case_text(case, alerts, markdown=False),
                       "labels": ["drawerguard", "pos-fraud", f"store-{case['store']}"[:60]]}}
    r = _post(f"{base}/rest/api/2/issue", body, {"Authorization": f"Basic {tok}"})
    key = r.get("key", "")
    return {"external_id": key, "url": f"{base}/browse/{key}" if key else ""}


def _case_text(case: dict, alerts: list[dict], markdown: bool) -> str:
    b = "**" if markdown else "*"
    lines = [f"{b}Store:{b} {case['store']}   {b}Cashier:{b} {case['cashier']}   {b}Status:{b} {case['status']}",
             f"{b}Alerts:{b} {len(alerts)}   {b}Value:{b} ${sum(a['amount'] or 0 for a in alerts):,.2f}", "", f"{b}Top alerts{b}"]
    for a in sorted(alerts, key=lambda a: -a["severity"])[:15]:
        lines.append(f"- [{meta(a['rule']).get('id')}] sev {a['severity']}: {a['title']}")
    lines += ["", "Created by DrawerGuard. Alerts are investigative leads, not proof."]
    return "\n".join(lines)


def push_case(system: str, case: dict, alerts: list[dict]) -> dict:
    if system == "thehive":
        return thehive_case(case, alerts)
    if system == "jira":
        return jira_issue(case, alerts)
    raise ValueError("Unknown system")
