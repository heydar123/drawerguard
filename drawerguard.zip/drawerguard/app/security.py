"""Security monitoring of DrawerGuard itself: sign-in telemetry, brute-force and
password-spraying detection, new-device alerts, and a security posture overview."""
import logging
import os
import re
import threading
import time
from collections import defaultdict

from . import siem
from .db import rows
from .notify import broadcast

log = logging.getLogger("drawerguard.security")
_lock = threading.Lock()
_ip_fails: dict[str, list[tuple[float, str]]] = defaultdict(list)    # ip -> [(time, username)]
_spray_alerted: dict[str, float] = {}

IP_WINDOW, IP_LIMIT = 600, int(os.environ.get("LOGIN_IP_LIMIT", "20"))         # 20 failures / 10 min per IP
SPRAY_USERS = int(os.environ.get("SPRAY_USERS", "5"))                          # distinct usernames from one IP


def ua_family(ua: str) -> str:
    ua = ua or ""
    browser = next((b for b, pat in (("Edge", r"Edg/"), ("Opera", r"OPR/"), ("Chrome", r"Chrome/"), ("Firefox", r"Firefox/"),
                                    ("Safari", r"Safari/"), ("curl", r"curl/"), ("Python", r"python")) if re.search(pat, ua, re.I)), "Other")
    os_ = next((o for o, pat in (("iPhone", r"iPhone"), ("iPad", r"iPad"), ("Android", r"Android"), ("Windows", r"Windows"),
                                ("macOS", r"Mac OS X|Macintosh"), ("Linux", r"Linux")) if re.search(pat, ua)), "Unknown OS")
    return f"{browser} on {os_}"


def ip_blocked(ip: str) -> bool:
    now = time.time()
    with _lock:
        _ip_fails[ip] = [(t, u) for t, u in _ip_fails[ip] if now - t < IP_WINDOW]
        return len(_ip_fails[ip]) >= IP_LIMIT


def register_failure(conn, ip: str, username: str) -> None:
    """Track failures per IP; raise a security alert on password spraying (many usernames, one IP)."""
    now = time.time()
    with _lock:
        _ip_fails[ip].append((now, username.lower()))
        users = {u for t, u in _ip_fails[ip] if now - t < IP_WINDOW}
        spray = len(users) >= SPRAY_USERS and now - _spray_alerted.get(ip, 0) > 3600
        if spray:
            _spray_alerted[ip] = now
    if spray:
        msg = f"Possible password spraying: {len(users)} different usernames tried from {ip} in 10 minutes."
        log.warning(msg)
        try:
            broadcast("🚨 DrawerGuard security alert", msg, "urgent")
        except Exception as e:      # never block the login flow on a notification problem
            log.error("security notify failed: %s", e)
        siem.forward_auth({"username": ",".join(sorted(users))[:200], "ip": ip, "outcome": "spray", "reason": msg})


def record_login(conn, username: str, ip: str, user_agent: str, success: bool, reason: str = "") -> bool:
    """Store a sign-in attempt. Returns True when a *successful* sign-in comes from a
    device/browser + IP never seen before for this user (and the user has signed in before)."""
    fam = ua_family(user_agent)
    new_device = False
    if success:
        prior = rows(conn.execute("SELECT ip, user_agent FROM login_events WHERE username=? AND success=1", (username,)))
        new_device = bool(prior) and not any(p["ip"] == ip and ua_family(p["user_agent"]) == fam for p in prior)
    conn.execute("INSERT INTO login_events(username, ip, user_agent, success, reason, new_device) VALUES(?,?,?,?,?,?)",
                 (username[:60], ip, (user_agent or "")[:200], int(success), reason[:100], int(new_device)))
    conn.commit()
    siem.forward_auth({"username": username, "ip": ip, "outcome": "success" if success else "failure",
                       "reason": reason, "device": fam, "new_device": new_device})
    return new_device


def overview(conn) -> dict:
    ev = rows(conn.execute("SELECT * FROM login_events ORDER BY id DESC LIMIT 200"))
    for e in ev:
        e["device"] = ua_family(e["user_agent"])
    day = rows(conn.execute("""SELECT SUM(success=0) failed, SUM(success=1) ok, COUNT(DISTINCT ip) ips,
                               SUM(new_device) new_devices FROM login_events WHERE created_at >= datetime('now','-1 day')"""))[0]
    users = rows(conn.execute("SELECT username, role, active, totp_secret IS NOT NULL AS two_factor, last_login FROM users"))
    active = [u for u in users if u["active"]]
    by_ip = rows(conn.execute("""SELECT ip, COUNT(*) attempts, SUM(success=0) failed, COUNT(DISTINCT username) users,
                                 MAX(created_at) last_seen FROM login_events GROUP BY ip ORDER BY failed DESC, attempts DESC LIMIT 20"""))
    return {
        "events": ev, "last_24h": {k: v or 0 for k, v in day.items()}, "by_ip": by_ip,
        "two_factor": {"enabled": sum(1 for u in active if u["two_factor"]), "users": len(active),
                       "missing": [u["username"] for u in active if not u["two_factor"] and u["role"] in ("owner", "manager")]},
        "api_keys": rows(conn.execute("SELECT COUNT(*) n, SUM(revoked=0) active FROM api_keys"))[0],
        "blocked_ips": [ip for ip in list(_ip_fails) if ip_blocked(ip)],
    }
