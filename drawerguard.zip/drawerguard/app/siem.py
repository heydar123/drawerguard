"""SIEM integration: send DrawerGuard alerts to Splunk, Elastic, Sentinel, Wazuh, QRadar…

Formats
  * CEF (ArcSight Common Event Format), the classic syslog payload for most SIEMs
  * JSON with Elastic Common Schema (ECS) style field names

Transports (configure in .env; blank = off)
  * Syslog RFC 5424 over UDP or TCP   SIEM_SYSLOG_HOST / SIEM_SYSLOG_PORT / SIEM_SYSLOG_PROTO / SIEM_FORMAT
  * Splunk HTTP Event Collector       SPLUNK_HEC_URL / SPLUNK_HEC_TOKEN
  * Generic JSON webhook              SIEM_WEBHOOK_URL (+ SIEM_WEBHOOK_SECRET → HMAC-SHA256 signature header)
  * Elasticsearch / OpenSearch _bulk  SIEM_ELASTIC_URL (+ SIEM_ELASTIC_INDEX, SIEM_ELASTIC_API_KEY)
Authentication events (sign-ins, failures, new devices, password spraying) are also
forwarded when SIEM_AUTH_EVENTS=1.
"""
import hashlib
import hmac
import json
import logging
import time
import os
import socket
import ssl
import urllib.request
from datetime import datetime, timezone

from . import __version__
from .detection.catalog import meta

log = logging.getLogger("drawerguard.siem")
SEV_CEF = {1: 2, 2: 4, 3: 6, 4: 8, 5: 10}
SEV_SYSLOG = {1: 6, 2: 5, 3: 4, 4: 3, 5: 2}      # info, notice, warning, error, critical


def _env(k, d=""):
    return os.environ.get(k, d).strip()


def _cef_escape(v, header=False) -> str:
    s = str(v if v is not None else "")
    if header:
        return s.replace("\\", "\\\\").replace("|", "\\|")
    return s.replace("\\", "\\\\").replace("=", "\\=").replace("\n", " ").replace("\r", " ")


def _epoch_ms(ts: str | None) -> int:
    try:
        return int(datetime.fromisoformat(ts).timestamp() * 1000) if ts else 0
    except ValueError:
        return 0


def to_cef(a: dict) -> str:
    m = meta(a["rule"])
    ext = {
        "rt": _epoch_ms(a.get("ts")), "suser": a.get("cashier"), "deviceExternalId": a.get("register"),
        "dvchost": a.get("store"), "externalId": a.get("id") or a.get("fingerprint"), "cs1Label": "rule", "cs1": a["rule"],
        "cs2Label": "acfe_scheme", "cs2": m.get("acfe"), "cs3Label": "receipt", "cs3": a.get("txn_id") or "",
        "cs4Label": "status", "cs4": a.get("status", "open"), "cfp1Label": "amount", "cfp1": a.get("amount") or 0, "msg": a["title"],
    }
    head = "|".join(_cef_escape(x, True) for x in (
        "CEF:0", "DrawerGuard", "DrawerGuard", __version__, m["id"], a["title"][:120], SEV_CEF.get(a["severity"], 5)))
    return head + "|" + " ".join(f"{k}={_cef_escape(v)}" for k, v in ext.items() if v not in (None, ""))


def to_ecs(a: dict) -> dict:
    m = meta(a["rule"])
    details = a.get("details") or {}
    if isinstance(details, str):
        try:
            details = json.loads(details)
        except ValueError:
            details = {}
    return {
        "@timestamp": (a.get("ts") or datetime.now(timezone.utc).isoformat()),
        "event": {"kind": "alert", "category": ["intrusion_detection"], "type": ["info"], "module": "drawerguard",
                  "severity": a["severity"], "id": str(a.get("id") or a.get("fingerprint"))},
        "rule": {"id": m["id"], "name": a["rule"], "category": m.get("acfe"), "description": m.get("logic", "")},
        "message": a["title"],
        "user": {"name": a.get("cashier")},
        "observer": {"vendor": "DrawerGuard", "product": "DrawerGuard", "version": __version__, "name": a.get("store")},
        "host": {"name": a.get("register") or ""},
        "drawerguard": {"store": a.get("store"), "register": a.get("register"), "receipt": a.get("txn_id"), "amount": a.get("amount"),
                        "status": a.get("status", "open"), "details": details},
    }


def _syslog_frame(a: dict, payload: str) -> bytes:
    pri = 8 * 13 + SEV_SYSLOG.get(a["severity"], 5)        # facility 13 = log audit
    ts = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    return f"<{pri}>1 {ts} {socket.gethostname()} drawerguard - {meta(a['rule'])['id']} - {payload}".encode()


def configured() -> dict:
    return {"syslog": bool(_env("SIEM_SYSLOG_HOST")), "splunk_hec": bool(_env("SPLUNK_HEC_URL") and _env("SPLUNK_HEC_TOKEN")),
            "webhook": bool(_env("SIEM_WEBHOOK_URL")), "elasticsearch": bool(_env("SIEM_ELASTIC_URL"))}


def elastic_bulk_body(alerts: list[dict], index: str) -> bytes:
    """NDJSON for the Elasticsearch _bulk API. The document id is the alert fingerprint, so
    replaying the same alerts never creates duplicates."""
    lines = []
    for a in alerts:
        doc_id = hashlib.sha1(str(a.get("fingerprint") or a.get("id")).encode(), usedforsecurity=False).hexdigest()
        lines.append(json.dumps({"index": {"_index": index, "_id": doc_id}}))
        lines.append(json.dumps(to_ecs(a), default=str))
    return ("\n".join(lines) + "\n").encode()


def forward(alerts: list[dict]) -> dict:
    """Send alerts to every configured SIEM destination. Never raises."""
    min_sev = int(_env("SIEM_MIN_SEVERITY", "1"))
    alerts = [a for a in alerts if a["severity"] >= min_sev]
    out = {}
    if not alerts:
        return out
    host = _env("SIEM_SYSLOG_HOST")
    if host:
        try:
            port, proto, fmt = int(_env("SIEM_SYSLOG_PORT", "514")), _env("SIEM_SYSLOG_PROTO", "udp").lower(), _env("SIEM_FORMAT", "cef").lower()
            frames = [_syslog_frame(a, to_cef(a) if fmt == "cef" else json.dumps(to_ecs(a), default=str)) for a in alerts]
            if proto == "tcp":
                with socket.create_connection((host, port), timeout=10) as s:
                    for f in frames:
                        s.sendall(str(len(f)).encode() + b" " + f)          # RFC 6587 octet counting
            else:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                    for f in frames:
                        s.sendto(f[:65000], (host, port))
            out["syslog"] = len(frames)
        except OSError as e:
            log.error("syslog forward failed: %s", e)
            out["syslog"] = f"error: {e}"
    url, tok = _env("SPLUNK_HEC_URL"), _env("SPLUNK_HEC_TOKEN")
    if url and tok:
        try:
            body = "\n".join(json.dumps({"time": _epoch_ms(a.get("ts")) / 1000 or None, "sourcetype": "drawerguard:alert",
                                         "source": "drawerguard", "event": to_ecs(a)}, default=str) for a in alerts).encode()
            ctx = ssl.create_default_context()
            if _env("SPLUNK_HEC_INSECURE") == "1":          # self-signed lab Splunk only
                ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
            req = urllib.request.Request(url, data=body, headers={"Authorization": f"Splunk {tok}", "Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=15, context=ctx)
            out["splunk_hec"] = len(alerts)
        except Exception as e:
            log.error("Splunk HEC forward failed: %s", e)
            out["splunk_hec"] = f"error: {e}"
    es = _env("SIEM_ELASTIC_URL")
    if es:
        try:
            index = _env("SIEM_ELASTIC_INDEX", "drawerguard-alerts")
            headers = {"Content-Type": "application/x-ndjson"}
            if _env("SIEM_ELASTIC_API_KEY"):
                headers["Authorization"] = f"ApiKey {_env('SIEM_ELASTIC_API_KEY')}"
            req = urllib.request.Request(es.rstrip("/") + "/_bulk", data=elastic_bulk_body(alerts, index), headers=headers)
            # the URL comes from the operator's .env
            with urllib.request.urlopen(req, timeout=20) as r:  # nosec B310
                res = json.loads(r.read() or b"{}")
            out["elasticsearch"] = f"error: {res.get('items', [{}])[0]}" if res.get("errors") else len(alerts)
        except Exception as e:
            log.error("Elasticsearch forward failed: %s", e)
            out["elasticsearch"] = f"error: {e}"
    hook = _env("SIEM_WEBHOOK_URL")
    if hook:
        try:
            body = json.dumps([to_ecs(a) for a in alerts], default=str).encode()
            urllib.request.urlopen(urllib.request.Request(hook, data=body, headers=signed_headers(body)), timeout=15)
            out["webhook"] = len(alerts)
        except Exception as e:
            log.error("SIEM webhook failed: %s", e)
            out["webhook"] = f"error: {e}"
    return out


def signed_headers(body: bytes) -> dict:
    """Receivers can verify X-DrawerGuard-Signature = sha256=HMAC(secret, timestamp + "." + body)
    and reject old timestamps, which stops forged or replayed webhook calls."""
    h = {"Content-Type": "application/json", "User-Agent": f"DrawerGuard/{__version__}"}
    secret = _env("SIEM_WEBHOOK_SECRET")
    if secret:
        ts = str(int(time.time()))
        sig = hmac.new(secret.encode(), ts.encode() + b"." + body, hashlib.sha256).hexdigest()
        h.update({"X-DrawerGuard-Timestamp": ts, "X-DrawerGuard-Signature": f"sha256={sig}"})
    return h


def verify_signature(secret: str, body: bytes, ts: str, signature: str, max_age: int = 300) -> bool:
    """Reference implementation for receivers (also used in tests)."""
    try:
        if abs(time.time() - int(ts)) > max_age:
            return False
    except ValueError:
        return False
    good = "sha256=" + hmac.new(secret.encode(), ts.encode() + b"." + body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(good, signature)


AUTH_SIG = {"success": ("AUTH-OK", 3), "failure": ("AUTH-FAIL", 5), "spray": ("AUTH-SPRAY", 9)}


def forward_auth(ev: dict) -> None:
    """Send a sign-in event to the syslog SIEM destination (opt-in: SIEM_AUTH_EVENTS=1)."""
    if _env("SIEM_AUTH_EVENTS") != "1" or not _env("SIEM_SYSLOG_HOST"):
        return
    sig, sev = AUTH_SIG.get(ev.get("outcome"), ("AUTH", 3))
    if ev.get("new_device"):
        sig, sev = "AUTH-NEWDEV", 6
    ext = {"rt": int(time.time() * 1000), "suser": ev.get("username"), "src": ev.get("ip"), "outcome": ev.get("outcome"),
           "reason": ev.get("reason"), "requestClientApplication": ev.get("device")}
    line = "|".join(_cef_escape(x, True) for x in ("CEF:0", "DrawerGuard", "DrawerGuard", __version__, sig,
                                                     f"Sign-in {ev.get('outcome')}", sev))
    line += "|" + " ".join(f"{k}={_cef_escape(v)}" for k, v in ext.items() if v not in (None, ""))
    try:
        frame = f"<{8 * 10 + (2 if sev >= 9 else 4 if sev >= 5 else 6)}>1 {datetime.now(timezone.utc).isoformat()} {socket.gethostname()} drawerguard - {sig} - {line}"
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.sendto(frame.encode()[:65000], (_env("SIEM_SYSLOG_HOST"), int(_env("SIEM_SYSLOG_PORT", "514"))))
    except OSError as e:
        log.error("auth event forward failed: %s", e)
