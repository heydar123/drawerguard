"""Default configuration: detection thresholds and POS export column mapping.

Detection defaults are loaded from detections/*.toml (detection-as-code). Everything
can be overridden from the dashboard (Detection rules page): overrides are stored in
the `settings` table and merged over these defaults.
"""
import copy

def _load_rules() -> dict:
    """Default thresholds come from the detection-as-code files in detections/*.toml."""
    from .detection.dac import load_all
    return {d["key"]: {**d["config"], "label": d["name"]} for d in load_all()}


DEFAULT_RULES = _load_rules()

DECEPTION_RULES = ("canary",)
PAYROLL_RULES = ("buddy_punch", "ghost_employee", "clocked_out_activity", "clock_padding", "timecard_edit")

# Each canonical field lists header names that SplitAbility / other POS exports may use.
# Matching is case-insensitive and ignores spaces, dashes and underscores.
DEFAULT_COLUMN_MAP = {
    "id": ["id", "transaction id", "txn id", "receipt", "receipt no", "receipt number", "docket", "docket no", "invoice", "ref"],
    "ts": ["timestamp", "date time", "datetime", "date/time", "time stamp", "created", "date"],
    "time": ["time"],
    "cashier": ["cashier", "employee", "staff", "user", "operator", "server", "clerk", "staff name"],
    "register": ["register", "terminal", "device", "station", "till", "pos"],
    "txn_type": ["type", "transaction type", "txn type", "action", "event", "status"],
    "amount": ["amount", "total", "value", "net", "gross", "sale total", "amount paid"],
    "payment_method": ["payment", "payment method", "payment type", "tender", "tender type", "paid by", "method"],
    "order_id": ["order", "order id", "order no", "table", "check", "check no", "ticket"],
    "original_txn_id": ["original", "original id", "original receipt", "orig receipt", "ref receipt", "refund of", "linked receipt"],
    "discount_amount": ["discount", "discount amount", "comp", "comp amount"],
    "approved_by": ["approved by", "manager", "authorised by", "authorized by", "override by"],
    "sent_to_kitchen": ["sent to kitchen", "kds", "printed", "sent", "fired"],
    "note": ["note", "notes", "reason", "comment", "description"],
    "store": ["store", "location", "site", "venue", "branch", "outlet"],
}

SHIFT_COLUMN_MAP = {
    "cashier": ["cashier", "employee", "staff", "user", "operator"],
    "register": ["register", "terminal", "device", "till", "station"],
    "start_ts": ["start", "shift start", "clock in", "opened", "open time"],
    "end_ts": ["end", "shift end", "clock out", "closed", "close time"],
    "opening_float": ["float", "opening float", "starting cash", "opening cash"],
    "expected_cash": ["expected", "expected cash", "system cash", "calculated cash"],
    "counted_cash": ["counted", "counted cash", "actual", "actual cash", "declared", "declared cash"],
    "store": ["store", "location", "site", "venue", "branch", "outlet"],
}

TIMECLOCK_COLUMN_MAP = {
    "employee": ["employee", "staff", "staff name", "employee name", "name", "user", "cashier"],
    "clock_in": ["clock in", "clock-in", "time in", "in", "punch in", "start"],
    "clock_out": ["clock out", "clock-out", "time out", "out", "punch out", "end"],
    "orig_in": ["original clock in", "original in", "orig clock in"],
    "orig_out": ["original clock out", "original out", "orig clock out"],
    "device": ["device", "terminal", "time clock", "clock", "station"],
    "method": ["method", "punch method", "source"],
    "edited_by": ["edited by", "modified by", "adjusted by", "changed by"],
    "edit_note": ["edit reason", "edit note", "reason", "note", "comment"],
    "hourly_rate": ["rate", "hourly rate", "pay rate", "wage"],
    "store": ["store", "location", "site", "venue", "branch", "outlet"],
}

TYPE_ALIASES = {
    "sale": ["sale", "sales", "paid", "completed", "order", "payment", "purchase", "closed"],
    "refund": ["refund", "return", "refunded", "credit"],
    "void": ["void", "voided", "delete", "deleted", "item void", "line void", "remove item", "removed"],
    "no_sale": ["no sale", "nosale", "open drawer", "drawer open", "drawer opened", "cash drawer", "drawer"],
    "discount": ["discount", "comp", "complimentary", "promo", "markdown"],
    "paid_out": ["paid out", "payout", "pay out", "petty cash", "cash out", "drop"],
    "cancel": ["cancel", "cancelled", "canceled", "abandoned", "order cancelled"],
}

PAYMENT_ALIASES = {
    "cash": ["cash", "notes", "coins"],
    "card": ["card", "credit", "debit", "eftpos", "visa", "mastercard", "amex", "tap", "contactless", "apple pay", "google pay"],
}


def merged_rules(overrides: dict | None) -> dict:
    rules = copy.deepcopy(DEFAULT_RULES)
    for k, v in (overrides or {}).items():
        if k in rules and isinstance(v, dict):
            rules[k].update(v)
    return rules
