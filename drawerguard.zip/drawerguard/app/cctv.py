"""CCTV helpers: map tills to cameras and build DVR/NVR playback links.

url_template placeholders (POS time is shifted by the camera's offset_seconds):
  {start} {end}            ISO time            2026-11-08T14:31:10
  {start_compact} {end_compact}  20261108T143110  (Hikvision style)
  {start_epoch} {end_epoch} Unix seconds
  {date} {time}            2026-11-08 / 14:32:10
Examples
  Hikvision NVR web:  http://192.168.1.64/doc/page/playback.asp?starttime={start_compact}&endtime={end_compact}
  Generic:            http://nvr.local/playback?cam=2&from={start_epoch}&to={end_epoch}
If you leave the template empty, DrawerGuard still tells you which camera and the exact DVR time to look at.
"""
from datetime import datetime, timedelta

from .db import rows

PRESETS = {
    "Hikvision": "http://NVR-IP/doc/page/playback.asp?starttime={start_compact}&endtime={end_compact}",
    "Dahua": "http://NVR-IP/#/playback?start={start}&end={end}",
    "Generic (epoch)": "http://NVR-IP/playback?from={start_epoch}&to={end_epoch}",
}


def links_for(conn, store: str, register: str, ts: str, before_s: int = 60, after_s: int = 120) -> list[dict]:
    if not ts:
        return []
    cams = rows(conn.execute("SELECT * FROM cameras WHERE store=? AND (register=? OR register='') ORDER BY register DESC, name",
                             (store, register or "")))
    pos = datetime.fromisoformat(ts)
    out = []
    for c in cams:
        dvr = pos + timedelta(seconds=c["offset_seconds"] or 0)
        a, b = dvr - timedelta(seconds=before_s), dvr + timedelta(seconds=after_s)
        url = ""
        if c["url_template"]:
            try:
                url = c["url_template"].format(
                    start=a.isoformat(timespec="seconds"), end=b.isoformat(timespec="seconds"),
                    start_compact=a.strftime("%Y%m%dT%H%M%S"), end_compact=b.strftime("%Y%m%dT%H%M%S"),
                    start_epoch=int(a.timestamp()), end_epoch=int(b.timestamp()),
                    date=dvr.strftime("%Y-%m-%d"), time=dvr.strftime("%H:%M:%S"))
            except (KeyError, IndexError, ValueError):
                url = ""
        out.append({"camera": c["name"], "register": c["register"] or "whole store", "dvr_time": dvr.isoformat(timespec="seconds"),
                    "from": a.isoformat(timespec="seconds"), "to": b.isoformat(timespec="seconds"), "url": url})
    return out
