# Changelog

## 5.0.0: Enterprise & AppSec edition
- **Deception:** DG-031 canary detection (honeytokens): planted manager override codes, staff logins, order/table numbers,
  decommissioned tills and reason codes; any use is a critical alert. Values that already exist in the data are refused.
  Purple-team scenario T20 (insider tries the planted code)
- **Watchlist:** containment that raises every new alert for a watched cashier one severity level; added from a cashier page or
  automatically from the incident-response checklist
- **Incidents:** alerts grouped by person and shift, scored by how many independent detections agree (−75% items to triage on the demo)
- **Investigation graph:** link analysis of people, tills, time clocks, canaries and cases with flagged relationships
  (collusion, buddy punching, canary use)
- **Compliance:** 21 live control checks mapped to PCI DSS v4.0.1, NIST CSF 2.0 and CIS Controls v8, with evidence, fixes and a
  printable evidence report; card-number (PAN) scanning with a Luhn check and masking on import
- **Integrations:** TheHive 5 (alerts and cases) and Jira (issues), recorded as external references
- **Authentication hardening:** lockout lasts `LOCKOUT_MINUTES` (30), configurable minimum password length, idle sign-out
  (`IDLE_TIMEOUT_MINUTES`, 15)
- **AppSec program:** 35 OWASP Top 10 attack tests, Hypothesis fuzz tests, CSV formula-injection fix (CWE-1236), CodeQL,
  gitleaks, OWASP ZAP baseline workflow, Dependabot, CycloneDX SBOM in CI, ASVS 4.0.3 self-assessment (docs/APPSEC.md)
- Benchmark (`scripts/benchmark.py` → docs/PERFORMANCE.md), DFIR-style case study (docs/CASE_STUDY.md), animated walkthrough
- Schema v6; 137 tests

## 4.0.0: Purple-team edition
- **Purple-team simulator:** 19 POS and payroll fraud techniques injected into a cloned "Red Team" cashier in memory; control vs attack
  diff, coverage matrix, gaps, time to detect, simulated loss, intensity sweeps; `scripts/purple_report.py` → docs/PURPLE_TEAM.md
- **Payroll & timeclock fraud:** timeclock import (with original vs edited times), DG-025 buddy punching, DG-026 ghost employee,
  DG-027 sales while clocked out (shared login), DG-028 hours padding, DG-029 timecard edits; Payroll page with wages at risk
- **Machine learning:** DG-030 isolation forest (pure Python, seeded, one-sided robust features, explanations); Model health page with
  PSI drift per feature, alert-volume drift, agreement between the two models, model card; daily drift notification
- **Incident response:** NIST SP 800-61 phases and checklists per case, reconstructed timeline (alerts, receipts, punches, notes,
  evidence), dwell time and time to contain, recommended controls, printable incident report
- **Detection-as-code:** all 30 detections are TOML files in `detections/` (metadata, thresholds, tests); 65 tests; validation;
  `scripts/dac.py` in CI; tests and source visible on the Detection catalog page
- **More POS systems:** Square, Toast and Clover import adapters (payments, refunds, voids, cash-drawer events), auto-detected
- **SIEM lab pack:** Elastic + Kibana compose and setup, Splunk app, Sentinel KQL, Wazuh decoders/rules, ES|QL hunts;
  native Elasticsearch `_bulk` forwarding; `scripts/siem_replay.py` backfill
- **Multi-language UI:** English, Türkçe, Español, Azərbaycanca
- DG-023 collusion now uses overlapping 30-day windows (a gap found by the purple-team simulator: calendar months split short schemes)
- Two new payroll hunts in the hunt library; timeclock readable in the hunt sandbox
- Fix: one SQLite connection per worker thread (parallel dashboard requests could fail on a shared connection)
- Schema v5; `.dockerignore`; Python 3.11+ (tomllib); 83 tests

## 3.0.0: SOC edition
- New detections: DG-022 missing cash counts, DG-023 cashier–approver collusion (binomial test, median-peer baseline), DG-024 multi-indicator shift correlation
- Custom detections (CU-xxx) with a safe JSON rule language, UI builder and history test; threshold backtesting; Sigma export
- SOC operations: SLA per severity, overdue flags, MTTA/MTTR, assignment, tags, alert history, false-positive rate per detection
- Suppressions (reason + expiry) and playbooks (auto-assign, tag, open case, push)
- Threat hunting: read-only SQL sandbox (authorizer, allow-list, timeout), hunt library, saved hunts, guided pivots, optional NL→SQL
- Forensics: Benford's law (Nigrini MAD), round/repeated amounts, hour profile, approval network, team heatmap
- Security center: sign-in telemetry, new-device alerts, per-IP blocking, password-spraying detection, sign out everywhere / per user
- Machine API (`/api/v1/*`) with scoped, SHA-256-hashed API keys and rate limiting; HMAC-signed webhooks
- Evidence chain of custody (SHA-256 on upload, verify, ZIP package with manifest)
- Daily backups, data retention, data-health monitoring
- UI: global search, keyboard shortcuts, dark mode, grouped navigation
- Hardened Docker (non-root, read-only, no capabilities); schema v4 with automatic migration
- Demo: fifth thief who colludes with a manager; 55 tests

## 2.1.0: Security edition
- Detection catalog: stable IDs (DG-001…DG-021) mapped to the ACFE Occupational Fraud Tree, with logic, false positives and triage
- SIEM integration: CEF over syslog (UDP/TCP), Splunk HEC, ECS JSON webhook; JSONL and CEF exports
- TOTP two-factor authentication (RFC 6238) with replay protection
- Tamper-evident SHA-256 hash-chained audit log with in-app verification; failed logins audited
- Password change revokes all other sessions
- Security headers (CSP, X-Frame-Options, nosniff, Referrer-Policy, no-store)
- Detection accuracy evaluation on labelled synthetic data (`scripts/evaluate.py`, docs/EVALUATION.md)
- CI: tests on Python 3.11–3.13, ruff, bandit SAST, pip-audit; STRIDE threat model

## 2.0.0
- AI behaviour scoring (self + team baselines), behaviour-change detection, AI case summaries
- Multi-store, owner/manager/auditor roles
- Cases with evidence uploads and printable case files; daily/weekly reports with email scheduler
- CCTV mapping with DVR playback links; installable phone app; ntfy/Telegram alerts

## 1.0.0
- SplitPOS CSV/XLSX import, 19 fraud rules, peer comparison, risk score, dashboard, email/SMS/Slack alerts
