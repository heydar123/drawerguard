"""Prepare a local Elasticsearch + Kibana for DrawerGuard alerts (lab use).

Creates the index template (ECS mapping), a Kibana data view and a set of saved
searches that mirror a SOC's first questions. Standard library only.

    python siem-lab/elastic/setup.py [--es http://localhost:9200] [--kibana http://localhost:5601]
"""
import argparse
import json
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).parent
SEARCHES = [
    ("DrawerGuard – critical alerts", "event.severity >= 5", ["rule.id", "user.name", "drawerguard.store", "message"]),
    ("DrawerGuard – collusion and correlation", 'rule.id : ("DG-023" or "DG-024")', ["rule.id", "user.name", "message"]),
    ("DrawerGuard – refund fraud", 'rule.id : ("DG-005" or "DG-006" or "DG-007" or "DG-008" or "DG-009")',
     ["rule.id", "user.name", "drawerguard.amount", "message"]),
    ("DrawerGuard – skimming / No Sale", 'rule.id : ("DG-001" or "DG-002" or "DG-003")', ["rule.id", "user.name", "host.name", "message"]),
    ("DrawerGuard – payroll fraud", 'rule.id : ("DG-025" or "DG-026" or "DG-027" or "DG-028" or "DG-029")',
     ["rule.id", "user.name", "message"]),
    ("DrawerGuard – AI / ML anomalies", 'rule.id : ("DG-020" or "DG-021" or "DG-030")', ["rule.id", "user.name", "message"]),
]


def call(method, url, body=None, kibana=False):
    headers = {"Content-Type": "application/json"}
    if kibana:
        headers["kbn-xsrf"] = "drawerguard"
    req = urllib.request.Request(url, method=method, data=json.dumps(body).encode() if body is not None else None, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:        # nosec B310 - lab URLs from the command line
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--es", default="http://localhost:9200")
    ap.add_argument("--kibana", default="http://localhost:5601")
    a = ap.parse_args()
    st, _ = call("PUT", f"{a.es}/_index_template/drawerguard-alerts", json.loads((HERE / "index-template.json").read_text()))
    print("index template:", st)
    st, dv = call("POST", f"{a.kibana}/api/data_views/data_view", {"data_view": {
        "id": "drawerguard-alerts", "title": "drawerguard-alerts*", "name": "DrawerGuard alerts", "timeFieldName": "@timestamp"},
        "override": True}, kibana=True)
    print("data view:", st)
    for title, kql, cols in SEARCHES:
        sid = "dg-" + "".join(ch for ch in title.lower() if ch.isalnum())[:40]
        src = {"query": {"query": kql, "language": "kuery"}, "filter": [], "indexRefName": "kibanaSavedObjectMeta.searchSourceJSON.index"}
        st, _ = call("POST", f"{a.kibana}/api/saved_objects/search/{sid}?overwrite=true", {
            "attributes": {"title": title, "columns": cols, "sort": [["@timestamp", "desc"]],
                           "kibanaSavedObjectMeta": {"searchSourceJSON": json.dumps(src)}},
            "references": [{"name": "kibanaSavedObjectMeta.searchSourceJSON.index", "type": "index-pattern", "id": "drawerguard-alerts"}]},
            kibana=True)
        print(f"saved search '{title}':", st)
    print(f"\nOpen {a.kibana}/app/discover and pick the 'DrawerGuard alerts' data view.")


if __name__ == "__main__":
    main()
