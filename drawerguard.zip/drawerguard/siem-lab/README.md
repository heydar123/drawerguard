# SIEM lab pack

Everything needed to watch DrawerGuard alerts in the SIEM a SOC already uses. DrawerGuard can send
alerts as **CEF over syslog**, **Splunk HEC**, an **Elasticsearch `_bulk`** call, or a signed **ECS JSON webhook**
(see `.env.example`). Every alert carries the detection ID (DG-xxx), the ACFE scheme, the cashier, store,
till, receipt and amount.

| Folder | What's inside |
|---|---|
| `docker-compose.elastic.yml` | Local Elasticsearch + Kibana 8 (lab only: no auth, bound to 127.0.0.1) |
| `elastic/` | ECS index template, `setup.py` (data view + 6 saved searches), ES\|QL hunting queries |
| `splunk/drawerguard_app/` | Splunk app: `props`/`transforms` for JSON and CEF, 4 saved searches / alerts, an overview dashboard |
| `sentinel/` | KQL analytics rules (custom table via Logs Ingestion API, or CEF via the AMA connector) |
| `wazuh/` | Decoders and rules for CEF over syslog, including a 3-alerts-in-24h frequency rule |

## Elastic in 5 minutes
```bash
docker compose -f siem-lab/docker-compose.elastic.yml up -d     # wait ~1 minute
python siem-lab/elastic/setup.py
# .env:  SIEM_ELASTIC_URL=http://localhost:9200
python scripts/siem_replay.py                                     # send the alerts you already have
```
Open http://localhost:5601 → Discover → **DrawerGuard alerts**. Saved searches: critical alerts, collusion and
correlation, refund fraud, skimming, payroll fraud, AI/ML anomalies. Paste the queries from `elastic/hunting.esql`
into Discover's ES|QL mode.

## Splunk
1. Settings → Data inputs → HTTP Event Collector → New token (sourcetype `drawerguard:alert`).
2. `.env`: `SPLUNK_HEC_URL=https://<splunk>:8088/services/collector/event`, `SPLUNK_HEC_TOKEN=...`
   (`SPLUNK_HEC_INSECURE=1` only for a lab with a self-signed certificate).
3. Copy `splunk/drawerguard_app` to `$SPLUNK_HOME/etc/apps/` and restart. Open the **DrawerGuard** app.

## Microsoft Sentinel
Send the ECS webhook (`SIEM_WEBHOOK_URL`) to a Logic App or the Logs Ingestion API into a `DrawerGuard_CL` table,
or use CEF over syslog with the AMA CEF connector. Create scheduled analytics rules from `sentinel/analytics-rules.kql`.

## Wazuh
`.env`: `SIEM_SYSLOG_HOST=<wazuh-manager>`, `SIEM_SYSLOG_PROTO=udp`, `SIEM_FORMAT=cef`. Enable a syslog `<remote>`
listener in `ossec.conf`, copy `wazuh/*.xml` into `etc/decoders` and `etc/rules`, restart the manager.

## Sigma
`GET /api/detections/sigma` (or the button on the Detection catalog page) exports every detection as Sigma YAML
for any other backend.

> The lab files are starting points: check field names against your SIEM version. Test with
> `python scripts/siem_replay.py --dry-run`, which prints one CEF line without sending anything.
