"""Start DrawerGuard:  python run.py   then open http://localhost:8000"""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

import uvicorn

if __name__ == "__main__":
    os.chdir(Path(__file__).parent)
    # 0.0.0.0 = reachable from phones on your Wi-Fi. Set HOST=127.0.0.1 in .env to allow this PC only.
    uvicorn.run("app.main:app", host=os.environ.get("HOST", "0.0.0.0"), port=int(os.environ.get("PORT", "8000")))  # noqa: S104
