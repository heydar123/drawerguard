# Architecture

```mermaid
flowchart LR
  subgraph Sources
    A[SplitPOS back-office<br/>CSV / XLSX exports]
    B[Inbox folder<br/>inbox/&lt;store&gt;/]
    C[REST API /api/v1<br/>scoped API keys]
    V[Square · Toast · Clover<br/>exports]
    T[Timeclock export]
  end
  subgraph DrawerGuard["DrawerGuard (FastAPI + SQLite)"]
    I[Importer<br/>column auto-detect,<br/>date/money normalisation]
    DB[(SQLite<br/>transactions · shifts · alerts<br/>cases · evidence · audit chain)]
    subgraph Engine["Detection engine (per store)"]
      R[27 rules<br/>DG-001…DG-019, DG-022, DG-023, DG-025…DG-029]
      ML[Isolation forest DG-030]
      CU[Custom rules CU-xxx<br/>safe JSON DSL]
      CO[Correlation DG-024]
      P[Peer comparison<br/>leave-one-out z-scores]
      AI[AI behaviour model<br/>robust z vs self + team<br/>change-point test]
    end
    S[Risk scoring 0–100]
    SOC[SOC layer<br/>suppressions · SLA · playbooks]
    H[Hunt sandbox · forensics]
    SEC[Security center<br/>login telemetry · API keys]
    PT[Purple-team simulator<br/>in-memory attacks]
    IR[Incident response<br/>NIST 800-61]
    DAC[(detections/*.toml<br/>detection-as-code)]
    API[REST API<br/>RBAC · 2FA · CSP]
    UI[Dashboard / PWA]
    REP[Reports & case files<br/>scheduler]
  end
  subgraph Outputs
    SIEM[SIEM<br/>CEF syslog · Splunk HEC · ECS JSON]
    PUSH[Owner alerts<br/>ntfy · Telegram · email · SMS · Slack]
    CCTV[DVR / NVR playback links]
  end
  A --> I
  B --> I
  C --> I
  V --> I
  T --> I
  DAC --> Engine
  PT --> Engine
  DB --> IR --> API
  PT --> API
  I --> DB --> Engine --> DB
  Engine --> S --> API
  DB --> API --> UI
  API --> REP
  Engine --> SOC
  SOC -- new alerts --> SIEM
  SOC -- severity ≥ 4 --> PUSH
  DB --> H --> API
  SEC --> API
  UI --> CCTV
```

## Data flow
1. **Ingest:** exports are parsed and normalised (types, tenders, dates, money) and de-duplicated by `(store, receipt id)`.
2. **Detect:** every enabled detection runs per store. Alerts get a deterministic fingerprint, so re-running is idempotent and never resets an alert you've already reviewed.
3. **Triage automation:** the SOC layer applies suppressions, sets the SLA due time and runs playbooks (assign, tag, open a case, push). Playbooks can never dismiss an alert on their own.
4. **Score:** each cashier gets a 0–100 risk score that combines alert severity per 100 transactions, peer z-scores (shrunk for small samples), cash-up shortages, the AI shift scores, and analyst-confirmed alerts.
5. **Respond:** new alerts go to the SIEM and to the owner's phone. Analysts triage in the UI (till timeline, CCTV link, evidence), group alerts into cases, and export case files.
6. **Assure:** every action goes into a hash-chained audit log, and CI runs tests, the accuracy evaluation, SAST and dependency scanning.

## AI behaviour model (DG-020)
For each cashier-day, nine features: No-Sale rate, void rate, refund rate, refund value %, discount %, cancel rate, cash share, drawer shortage, paid-outs.
Each feature gets a **robust z-score** (median / 1.4826·MAD, with a floor) against (a) the cashier's own other days and (b) the team's days, signed in the suspicious direction.
The positive parts are combined as `score = 100·(1 − e^(−‖z⁺‖/4.5))`. The top contributing features are reported as plain-English "drivers".
**DG-021** runs a two-proportion z-test on the last *N* days against earlier history, to catch new behaviour.

## Tech choices
- **Pure Python, no numpy/scikit-learn**, so it installs on any Windows PC, including brand-new Python versions.
- **SQLite** with WAL: one file, zero admin, automatic schema migrations (v1 → v5), one connection per worker thread.
- **A single-file dashboard** (no build step) that works offline as an installable PWA.

## Collusion (DG-023)
For every approver × cashier pair, the share of the cashier's overrides approved by that approver is compared with the median share across peers, using a binomial z-test. A median baseline stops one extreme pair from hiding itself in the average.

## Hunt sandbox
Hunts run on a separate `mode=ro` SQLite connection. A `set_authorizer` callback allows only SELECT/READ on nine data tables, plus CTEs and functions. Users, API keys, sign-ins, audit and settings tables, `sqlite_*`, `pragma_*` and ATTACH are denied. A progress handler aborts queries after `HUNT_TIMEOUT` seconds, and results are capped.

## Detection-as-code
`detections/DG-xxx_<key>.toml` holds each detection's metadata, default thresholds and tests. `app/detection/dac.py` loads
the files (the default rule config and the catalog are built from them), validates them (required fields, IDs, schemes,
severities, an implementation exists) and runs the tests: compact event lines for unit tests, the labelled demo dataset for
statistical detections. `scripts/dac.py` runs it in CI.

## Purple-team simulator
`app/purple.py` clones a low-risk cashier (transactions, cash-ups, punches) into a synthetic *Red Team* cashier on its own
till, runs `detect_store` on an in-memory context without the attack (control) and with it, and diffs the alerts by
fingerprint. 19 techniques, intensity and window are parameters; a sweep runs one technique at 0.25×–2×.

## Incident response
`app/ir.py` keeps a NIST SP 800-61 phase and checklist per case (JSON on the case row), rebuilds a timeline from alerts,
the flagged transactions, timeclock punches, notes and evidence, computes dwell time and time to contain, maps the
detections that fired to preventive controls, and renders a printable incident report.

## Payroll and ML
`app/detection/payroll.py` joins the timeclock with POS activity (DG-025 to DG-029). `app/detection/ml.py` adds a seeded,
pure-Python isolation forest on one-sided robust-scaled features (DG-030) and model monitoring: PSI per feature, alert
volume drift and agreement with DG-020.

## Deception, incidents, graph, compliance and integrations (v5)
- `app/detection/deception.py`: DG-031 canaries (loaded per store into the detection context) and the watchlist
  (applied in `run_detection`: severity +1 and a `watchlist` tag on new alerts).
- `app/investigate.py`: incident grouping (store + person + day, monthly peer alerts by month; score = severity weights +
  a bonus per extra independent detection) and the link-analysis graph (people, tills, clocks, canaries, cases).
- `app/compliance.py`: 21 live checks returning pass/warn/fail/info with evidence and a fix, mapped to PCI DSS v4.0.1,
  NIST CSF 2.0 and CIS Controls v8.
- `app/integrations.py`: TheHive 5 (`/api/v1/alert`, `/api/v1/case`) and Jira (`/rest/api/2/issue`); every push is stored in
  `external_refs`.
- `db.ThreadLocalConnection`: one SQLite connection per worker thread behind the shared `conn` object.
