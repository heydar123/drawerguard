# Case study: a cashier–manager refund ring

*An investigation write-up in incident-report style, run end to end in DrawerGuard on the sample data (Harbor Street store,
45 days, ~9,100 transactions). The people are synthetic; the method is the point. Reproduce it with
`python scripts/load_demo.py` or in the live demo.*

## 1. Summary
| | |
|---|---|
| **What happened** | A cashier (Sofia V.) refunded 112 earlier cash sales whose customers had long left, pocketing the cash. A shift manager (Rita) approved 105 of them. |
| **Loss** | $1,922.74 in 45 days (≈ $300 a week) |
| **Why it was hard** | Every refund looked legitimate on its own: a real original receipt, a manager's approval, a believable reason, not a round amount. No single-transaction rule fires. |
| **How it was caught** | Behaviour analytics (two independent models) and a collusion test on *who approves whose overrides*, confirmed with a hunt query and the approval network |
| **Time to detect** | First high-confidence signals within the first week of data (AI models on day 5, collusion window on day 5) |
| **Detections** | DG-018 peer outlier, DG-020 behaviour model, DG-030 isolation forest, **DG-023 collusion**, DG-008 refunds of own sales |

## 2. Detection
The first signals were statistical, not rule hits:
- **DG-018 Behaviour far from other cashiers.** Sofia's refund rate was **5.3 per 100 sales**, about four times her colleagues'
  (1.2–1.3 per 100).
- **DG-020 and DG-030** flagged the same shift on **Sep 30**: the robust-z model (score 82) and the isolation forest agreed,
  which the Model health page reports as model agreement.
- **DG-023 Collusion** fired for every 30-day window: *"Rita (Manager) approved 70 of Sofia V.'s 81 overrides (86%) … vs 52% of
  everyone else's."* The test is a binomial z-test against the **median** share Rita approves for the other cashiers, so one
  colluding pair can't hide inside the average.

The **Incidents** page grouped her alerts by shift, so the analyst saw a handful of multi-signal incidents instead of dozens of
separate alerts.

## 3. Investigation
**Hunt: who approves whose overrides** (SQL workbench, library query *"Who approves whose overrides"*):

| Approver | Cashier | Approvals | Value |
|---|---|---|---|
| **Rita (Manager)** | **Sofia V.** | **109** | **$2,031** |
| Sam (Manager) | Nina R. | 17 | $382 |
| Rita (Manager) | Nina R. | 14 | $337 |

Rita approved **94%** of Sofia's refunds (105 of 112) but only 36–53% of anyone else's.

**Timing.** Joining each refund to its original sale shows a **median of 135 minutes** between the sale and the refund: the
customer was long gone, which is the signature of refunding an old receipt to take the cash.

**Approval network.** The Forensics page and the **Investigation graph** draw the Rita → Sofia edge in red; no other pair
stands out.

**Next steps for a real case:** pull CCTV for a sample of refund times (is a customer at the counter?), call customers where
contact details exist, and compare the rota: does Rita approve refunds on shifts where she isn't working the floor?

## 4. Response (NIST SP 800-61)
| Phase | Actions in DrawerGuard |
|---|---|
| Detection & analysis | Case opened from the incident; CCTV clips attached (SHA-256 recorded at upload); loss estimated from the refund list |
| Containment | Sofia added to the **watchlist** (every new alert one severity higher); refunds above $25 now need a second manager; Rita's approval code reset |
| Eradication | Refunds forced to the original tender and only against a scanned receipt; approvers rotated |
| Recovery | Loss quantified, recovery agreed, store monitored for 30 days |
| Post-incident | Lessons recorded; a **canary** approval code planted under the till (DG-031); incident report exported for HR |

## 5. Lessons and controls
- **Segregation of duties is a detection surface.** The approval relationship (who signs off whom) exposed what each
  transaction hid. DG-023 now runs in every store.
- **Two models agreeing is worth more than one high score.** The robust-z model and the isolation forest look at the data
  differently; their overlap is a strong prioritisation signal.
- **Prevent, then detect.** Recommended controls from the case: refund-to-original-tender, second approver above a limit,
  approver rotation, and receipt checks.

## 6. Detection engineering follow-up
After the case, the **purple-team simulator** replayed the collusion technique (scenario T14) against both stores. It
showed that DG-023 originally used **calendar months**, so a two-week scheme that straddled a month boundary could fall
below the minimum in both months. The detection was changed to **overlapping 30-day windows every 15 days** (any scheme of
15 days or less sits inside one window), the change was made in `detections/DG-023_approver_concentration.toml` (version 2),
its test re-run in CI, and the sensitivity sweep now shows the smallest collusion it catches on the sample data
(about $90 a week at the Downtown store). The remaining blind spot, documented in [PURPLE_TEAM.md](PURPLE_TEAM.md), is
low-and-slow skimming below every threshold.

---

## Second case: a ghost employee
*Downtown Cafe, timeclock export.* **DG-026** flagged **Kevin D.**: 176 paid hours over 27 shifts, about **$3,252** in wages, and
not one POS transaction or approval. Every punch was entered by the same manager from the office PC (method *manager*),
which the hunt *"Paid hours vs POS activity per employee"* and the Investigation graph (Kevin's only link is the office PC)
both show. Next steps in a real case: verify the person exists (ID, tax forms, a bank account not shared with another
employee) and separate hiring from payroll approval.
