# Threat model

DrawerGuard has two threat models:

1. **The business threat** it detects: insider theft at the point of sale.
2. **The application threat**: attacks against DrawerGuard itself. The obvious attacker is a dishonest employee who wants to hide their own alerts.

---

## 1. Business threat: insider cash theft

| | |
|---|---|
| **Asset** | Cash in the drawer, goods sold for cash, and paid hours (wages) |
| **Threat actor** | Cashier or shift manager with legitimate POS access (insider) |
| **Attack surface** | POS functions: No Sale, void, refund, discount/comp, cancel, paid-out, cash-up; the time clock and timecard edits; shared POS logins |
| **Framework** | ACFE Occupational Fraud Tree → Asset Misappropriation → Cash |

| Scheme (ACFE) | How it's done at a till | Primary detections |
|---|---|---|
| Skimming: unrecorded sales | Take cash, don't ring the sale, use No Sale to open the drawer | DG-001, DG-002, DG-013, DG-019, DG-020 |
| Skimming: understated sales | Ring a large discount or comp, keep the difference | DG-010 |
| Cash larceny | Take cash directly from the drawer | DG-003, DG-014, DG-015, DG-016, DG-017 |
| Register disbursements: false refunds | Fake refund, refund a card sale in cash, refund own sale | DG-005 to DG-009 |
| Register disbursements: false voids | Void items after the customer paid cash | DG-004 |
| Control override (enabler) | No approval, or self-approval of overrides | DG-011, DG-012 |
| Slow / new behaviour | Starts small, escalates; new hire | DG-018, DG-020, DG-021 |
| Collusion | A manager approves the cashier's fake refunds | DG-023, DG-024 |
| Concealment | Skipping the end-of-shift cash count | DG-022 |
| Payroll: ghost employee | A manager adds a fake employee and punches them in | DG-026 |
| Payroll: falsified hours | Buddy punching, padding hours, timecard edits that add time | DG-025, DG-028, DG-029 |
| Access misuse | Selling under another cashier's login | DG-027 |
| Any of the above, in combination | Several techniques in one shift; patterns no single rule sees | DG-024, DG-030 |
| Reconnaissance / probing | Trying a manager code found under the till, an unused till, a fake reason code | DG-031 (canaries) |

**Detection strategy, in layers:**
- Deterministic rules for known patterns: high precision and easy to explain.
- Peer comparison: outliers against colleagues.
- Self-baselined behavioural scoring: the cashier against their own history.
- Change-point testing: catches someone who has just started.

Every alert carries enough context to verify it against CCTV: till timeline, receipt, DVR-corrected time.

**Validated by purple teaming and AppSec testing:** see [APPSEC.md](APPSEC.md) for the OWASP Top 10 attack tests.
**Purple teaming:** the built-in simulator replays 19 fraud techniques against the live detection configuration
(see [PURPLE_TEAM.md](PURPLE_TEAM.md)), and every detection has its own unit tests ([DETECTION_TESTS.md](DETECTION_TESTS.md)).

**Known blind spots** (to be honest about):
- Collusion where the accomplice approves only a small share of overrides (DG-023 needs a clear concentration;
  the purple-team sweep shows it needs roughly $90/week of fake refunds before it fires on the sample data).
- Low-and-slow skimming: one small unrung sale every few days stays under every threshold (purple-team scenario T15).
- Theft that leaves no POS event at all, such as taking from the safe.
- Very low-and-slow theft below the thresholds.
- Fraud using data that the export doesn't contain.

Mitigations: segregation of duties, surprise cash counts, and cameras on the safe.

---

## 2. Application threat model (STRIDE)

**Trust boundaries:** browser ↔ API (LAN); API ↔ SQLite / evidence files (local disk); API → outbound integrations (SIEM, Elasticsearch, ntfy, SMTP, Anthropic API); POS and timeclock exports → importer (untrusted files); `detections/*.toml` → engine (trusted code, changed only through review).

| STRIDE | Threat | Mitigation in DrawerGuard |
|---|---|---|
| **Spoofing** | Password spraying from one device | Per-IP block after 20 failures in 10 minutes; a security alert when one IP tries 5+ usernames; new-device notifications |
| **Spoofing** | A stolen API key | Keys are shown once and stored as SHA-256; scopes (read / ingest) and store limits; rate limit 120/min; revocable; last-used shown |
| **Spoofing** | Password guessing; a stolen session | PBKDF2-SHA256 (200k iterations, per-user salt); per-user lockout after 8 failures in 5 min; **TOTP 2FA** (RFC 6238, replay-protected); HMAC-signed sessions with expiry; **changing the password revokes all sessions** |
| **Tampering** | A manager deletes or edits audit records to hide activity | **SHA-256 hash-chained audit log** with an integrity check in the UI (`/api/audit/verify`); alerts are also forwarded to an external **SIEM** in real time, so a copy exists outside the attacker's reach |
| **Tampering** | A malicious CSV/XLSX upload | Parsed as data only (no formulas executed, no eval); size limits; types and amounts are normalised; rows are inserted with bound parameters |
| **Repudiation** | "I didn't dismiss that alert" | Every state change, export, import and login (including failures) is in the audit log with the actor's name |
| **Information disclosure** | A manager sees another store's data | Store-scoped authorisation on every endpoint (`scope()`); roles: owner / manager / auditor |
| **Information disclosure** | Evidence files are served to the wrong person | Evidence is only served through authenticated, store-scoped endpoints; random UUID filenames; extension allow-list |
| **Information disclosure** | Data leaks to an AI provider | The optional Claude summary sends only aggregated metrics (no receipts or customer data); it is off unless a key is set |
| **Denial of service** | A huge upload | 100 MB import cap; 250 MB evidence cap streamed to disk |
| **Elevation of privilege** | An auditor changes alerts; a manager edits rules | Permission checks (`need("review")`, `need("admin")`) on every write endpoint, covered by tests |
| **Browser attacks** | XSS, clickjacking, MIME sniffing | All user data is HTML-escaped on render; CSP (`frame-ancestors 'none'`, `object-src 'none'`, `base-uri 'none'`); `X-Frame-Options: DENY`; `nosniff`; `Referrer-Policy: no-referrer`; `Cache-Control: no-store` on API responses |
| **Injection / disclosure** | Abusing the threat-hunting SQL workbench | Admin only; separate `mode=ro` connection; SQLite authorizer allows only reads of 9 data tables (users, API keys, logins, audit and settings are blocked); no ATTACH or PRAGMA; progress-handler timeout; row cap |
| **Tampering** | Evidence altered after upload | SHA-256 recorded on upload; re-verify in the UI; the evidence package carries a manifest of hashes |
| **Tampering** | Forged webhook calls to the SIEM | HMAC-SHA256 signature header with timestamp (`SIEM_WEBHOOK_SECRET`) |
| **Repudiation** | "I didn't suppress that alert" | Suppressions require a reason; every status, owner and suppression change goes to alert history and the audit log |
| **Tampering** | A malicious timeclock / Square / Toast / Clover export | Same importer rules as POS files: parsed as data, size limits, bound parameters; vendor adapters only map known columns |
| **Tampering** | Someone weakens a detection to hide their own activity | Detections are code (`detections/*.toml`): changes go through review and CI runs every detection's tests; threshold changes in the UI are owner-only and audited; the purple-team simulator shows coverage after any change |
| **Information disclosure** | Card numbers typed into POS notes end up in DrawerGuard | Luhn-checked PAN scan; PANs masked on import (last 4 kept); compliance check DP-01 fails if any are found |
| **Tampering** | Formula injection: a cashier name or note like `=HYPERLINK(...)` runs when an analyst opens an export | Cells starting with `= + - @` are neutralised in every CSV export (server and browser) |
| **Spoofing** | An insider uses a manager code they found | Canary codes (DG-031) are critical alerts; real codes are personal and audited |
| **Denial of service** | Hammering the purple-team simulator (CPU-heavy) | Owner-only; runs in memory with bounded inputs (7–60 days, 0.1–5× intensity); every run is audited |
| **Information disclosure** | The incident report or a timeline leaks into the wrong hands | Same store-scoped authorisation as cases; HTML-escaped; exports are audited |
| **Injection** | SQL injection | Every value is a bound `?` parameter. Dynamic SQL only adds fixed column names and placeholder lists (documented reason for the S608 lint suppression) |

**Residual risks and recommendations:**
- **No TLS by default on the LAN.** If you expose DrawerGuard beyond the home or office network, put it behind HTTPS (Caddy, Nginx or Cloudflare Tunnel). Set `HOST=127.0.0.1` to keep it on one PC.
- **The CSP allows `'unsafe-inline'` scripts** because the dashboard ships as one file. The next step is to move the script to a static file and use a nonce-based CSP.
- **An owner with direct database access** can still rewrite history. The hash chain *detects* this and the SIEM copy *survives* it, but neither prevents it.
- **Sessions are HMAC tokens** stamped with the password hash and a per-user epoch, so "sign out everywhere" and admin sign-out revoke them. Revoking one single session still isn't possible.
