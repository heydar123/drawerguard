# Application security

DrawerGuard holds evidence about people's jobs, so the app itself is a target. The most likely attacker is an
**insider with a login** (a manager who wants another store's data or wants their own alerts gone) or an insider who
**plants data** through the POS (a cashier name or note that runs in an analyst's browser or spreadsheet).
This page maps the controls to the **OWASP Top 10 (2021)** and **OWASP ASVS 4.0.3** sections, with the automated test
that proves each one. Threat model: [THREAT_MODEL.md](THREAT_MODEL.md).

## Security testing in CI
| Layer | Tool | Where |
|---|---|---|
| Attack tests (OWASP Top 10) | pytest, 35 cases | [`tests/test_appsec.py`](../tests/test_appsec.py) |
| Property-based fuzzing | Hypothesis: money/date parsers, importers, custom-rule language, detection DSL, PAN masking, hunt sandbox | [`tests/test_fuzz.py`](../tests/test_fuzz.py) |
| SAST | bandit, ruff (flake8-bandit rules), CodeQL (Python + JavaScript, security-extended) | `ci.yml`, `codeql.yml` |
| Dependencies | pip-audit, Dependabot (pip, Actions, Docker) | `ci.yml`, `dependabot.yml` |
| Supply chain | CycloneDX 1.5 SBOM on every build (`scripts/sbom.py`) | `ci.yml` artifact |
| Secrets | gitleaks on every push | `secrets.yml` |
| DAST | OWASP ZAP baseline against a running instance with demo data | `dast.yml` (weekly / on demand) |
| Detection regression | 69 detection-as-code tests | `scripts/dac.py` |

## OWASP Top 10 (2021) → controls → tests
| Category | Controls in DrawerGuard | Tests |
|---|---|---|
| **A01 Broken access control** | Store scoping on every endpoint (`scope()`), object-level checks on alert/case/evidence ids, role permissions (owner / manager / auditor), Pydantic models ignore extra fields | `test_a01_manager_cannot_read_another_store` (10 endpoints), `test_a01_object_level_checks_on_ids`, `test_a01_role_checks`, `test_a01_mass_assignment_is_ignored` |
| **A02 Cryptographic failures** | PBKDF2-SHA256 (200,000 iterations, per-user salt), API keys stored as SHA-256 only, HMAC-signed session tokens bound to the password hash and a per-user epoch, card numbers masked on import | `test_a02_passwords_and_api_keys_are_hashed`, `test_a02_tampered_and_foreign_tokens_are_rejected`, `test_pan_in_notes_is_masked_on_import` |
| **A03 Injection** | Bound parameters everywhere; hunt sandbox = read-only connection + SQLite authorizer + table allow-list + timeout; HTML escaped in UI and server-rendered reports; CSV cells starting with `= + - @` neutralised | `test_a03_sql_injection_in_filters`, `test_a03_hunt_sandbox_blocks` (7 payloads), `test_a03_stored_xss_is_escaped_in_server_rendered_reports`, `test_a03_csv_formula_injection_is_neutralised`, `test_hunt_sandbox_never_writes` (fuzz) |
| **A04 Insecure design** | Bounded inputs for expensive operations (purple team), length limits on free text, canaries refuse values already in the data, playbooks can never auto-dismiss | `test_a04_abuse_limits` |
| **A05 Security misconfiguration** | CSP (`frame-ancestors 'none'`, `object-src 'none'`, `base-uri 'none'`), X-Frame-Options, nosniff, Referrer-Policy, `no-store` on the API; upload allow-list; strict backup file names; hardened Docker; `.dockerignore` keeps `.env` out of images | `test_a05_security_headers`, `test_a05_uploads_and_paths` |
| **A06 Vulnerable components** | pip-audit, Dependabot, SBOM | CI |
| **A07 Identification & authentication** | Lockout after `LOCKOUT_ATTEMPTS` (8) for `LOCKOUT_MINUTES` (30), per-IP blocking, password-spraying detection, TOTP 2FA with replay protection, configurable minimum length (12 recommended), idle sign-out, sign out everywhere | `test_a07_lockout_persists_even_with_the_right_password`, `test_a07_password_policy_and_sign_out_everywhere` |
| **A08 Software & data integrity** | SHA-256 hash-chained audit log, evidence hashed at upload and re-verifiable, signed webhooks, detections versioned as code with tests | `test_a08_audit_chain_detects_tampering`, evidence tests in `test_v3.py` |
| **A09 Logging & monitoring failures** | Every login (success and failure), export, change and deletion goes to the audit log; sign-in telemetry; optional forwarding of auth events to the SIEM | `test_a09_security_events_are_logged` |
| **A10 SSRF** | No endpoint accepts a URL to fetch: SIEM, TheHive, Jira and Claude endpoints come only from the server's `.env` | `test_a10_no_user_controlled_outbound_urls` (walks the OpenAPI schema) |

## OWASP ASVS 4.0.3 (Level 2) self-assessment
| ASVS section | Status | Notes |
|---|---|---|
| V2.1 Password security | ✅ | Minimum length configurable (`PASSWORD_MIN_LENGTH`, 12 recommended; 8 kept as the default for existing installs) |
| V2.2 General authenticator security | ✅ | Lockout, per-IP limits, spraying detection, new-device alerts |
| V2.4 Credential storage | ✅ | PBKDF2-SHA256, 200k iterations, unique salt |
| V2.8 One-time verifier (TOTP) | ✅ | RFC 6238, ±1 step, replay protection |
| V3.3 Session termination | ✅ | Logout, idle sign-out (`IDLE_TIMEOUT_MINUTES`), sign out everywhere, password change revokes sessions |
| V3.5 Token-based sessions | ⚠️ | Stateless HMAC tokens: revocation is per user (epoch), not per single token |
| V4.1 / V4.2 Access control | ✅ | Deny by default, store scoping, object-level checks (IDOR) |
| V5.1 Input validation | ✅ | Pydantic models with length and range limits; importers normalise types |
| V5.3 Output encoding & injection | ✅ | Escaping in UI and reports, parameterised SQL, formula-injection guard |
| V7.1 / V7.2 Log content & processing | ✅ | Who, what, when for every security-relevant event |
| V7.3 Log protection | ✅ | Hash chain + optional off-box SIEM copy |
| V8.1 / V8.3 Data protection | ✅ | `no-store` on API responses, PAN masking, data retention job, no secrets in logs |
| V9 Communication | ⚠️ | Plain HTTP on a trusted LAN by default; put it behind HTTPS (Caddy, Nginx, Cloudflare Tunnel) when exposed |
| V10 Malicious code | ✅ | SBOM, dependency audit, CodeQL, no `eval`, custom rules are data (JSON DSL) not code |
| V12.1 / V12.3 Files | ✅ | Extension allow-list, size caps, random stored names, authenticated downloads, strict backup names |
| V13.1 / V13.2 API | ✅ | Scoped API keys, rate limits, JSON only, OpenAPI documented |
| V14.4 HTTP security headers | ⚠️ | All present; CSP still allows inline script because the dashboard is a single file (planned: nonces) |

## Running it yourself
```bash
pip install -r requirements-dev.txt
python -m pytest tests/test_appsec.py tests/test_fuzz.py -v
bandit -c pyproject.toml -r app && ruff check . && pip-audit -r requirements.txt
python scripts/sbom.py
```
Found a vulnerability? See [SECURITY.md](../SECURITY.md).
