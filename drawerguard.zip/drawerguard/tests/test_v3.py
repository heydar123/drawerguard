"""Tests for v3 features: SOC lifecycle, suppressions, playbooks, custom detections, backtesting,
Sigma, threat hunting sandbox, forensics, security center, API keys, evidence integrity, backups."""
import io
import json
import os
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if "DRAWERGUARD_DB" not in os.environ:                 # when run on its own
    _tmp = Path(tempfile.mkdtemp())
    os.environ.update(DRAWERGUARD_DB=str(_tmp / "test.db"), DRAWERGUARD_DATA=str(_tmp / "data"),
                      DRAWERGUARD_PASSWORD="ownerpass1", REPORTS_ENABLED="0")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import forensics, hunt  # noqa: E402
from app.detection.custom import RuleError, validate  # noqa: E402
from app.main import app  # noqa: E402
from sample_data.generate_demo import Gen  # noqa: E402

C = TestClient(app)


def login(u="owner", p="ownerpass1"):
    r = C.post("/api/login", json={"username": u, "password": p})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="module")
def H():
    h = login()
    out = Path(tempfile.mkdtemp())
    g = Gen(3, "harbor")
    g.run(datetime(2026, 11, 8), 30)
    g.write(out, "harbor")
    for f in ("harbor_transactions.csv", "harbor_cashup.csv"):
        r = C.post("/api/import", headers=h, files={"file": (f, (out / f).read_bytes())}, data={"store": "v3shop"})
        assert r.status_code == 200, r.text
    return h


# ------------------------------------------------------------------ SOC lifecycle

def test_sla_assignment_history_and_metrics(H):
    al = C.get("/api/alerts?store=v3shop&status=open&min_severity=4&limit=3", headers=H).json()["items"]
    assert al and all(a["due_at"] for a in al)
    aid = al[0]["id"]
    assert C.patch(f"/api/alerts/{aid}", headers=H, json={"assigned_to": "owner"}).status_code == 200
    assert C.patch(f"/api/alerts/{aid}", headers=H, json={"status": "investigating"}).status_code == 200
    assert C.patch(f"/api/alerts/{aid}", headers=H, json={"status": "confirmed", "notes": "seen on CCTV"}).status_code == 200
    a = C.get(f"/api/alerts?status=&id={aid}", headers=H).json()["items"][0]
    assert a["assigned_to"] == "owner" and a["acked_at"] and a["resolved_at"]
    hist = C.get(f"/api/alerts/{aid}/history", headers=H).json()
    assert {h["field"] for h in hist} >= {"assigned_to", "status", "notes"}
    assert C.get("/api/alerts?assigned=me&status=", headers=H).json()["total"] >= 1
    assert C.patch(f"/api/alerts/{aid}", headers=H, json={"assigned_to": "nobody-here"}).status_code == 400
    m = C.get("/api/soc/metrics?days=0&store=v3shop", headers=H).json()
    assert m["total"] > 0 and m["dispositions"]["confirmed"] >= 1 and m["mttr_h"] is not None and m["rules"]


def test_suppression_auto_closes_new_and_existing(H):
    r = C.post("/api/suppressions", headers=H, json={"store": "v3shop", "rule": "paid_out", "reason": "Approved supplies purchases",
                                                    "apply_existing": True})
    assert r.status_code == 200 and r.json()["closed_existing"] >= 1
    assert C.post("/api/suppressions", headers=H, json={"reason": "everything"}).status_code == 400       # too broad
    left = C.get("/api/alerts?store=v3shop&rule=paid_out&status=open", headers=H).json()["total"]
    assert left == 0
    closed = C.get("/api/alerts?store=v3shop&rule=paid_out&status=dismissed", headers=H).json()["items"]
    assert closed and all(a["suppressed_by"] for a in closed)


def test_playbook_assigns_and_opens_case(H):
    assert C.post("/api/automations", headers=H, json={"name": "auto-dismiss", "set_status": "dismissed"}).status_code == 400
    r = C.post("/api/automations", headers=H, json={"name": "Collusion → case", "rules": ["custom:999999", "approver_concentration",
                                                                                       "no_sale_after_cash"],
                                                   "min_severity": 4, "assign_to": "owner", "add_to_case": True, "tag": "playbook"})
    assert r.status_code == 200
    # new data triggers the playbook
    csv_text = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total\n"
                "PB1,11/09/2026,10:00:00,Zed Q.,T9,Sale,Cash,$12.00\n"
                "PB2,11/09/2026,10:00:30,Zed Q.,T9,Open Drawer,,\n")
    C.post("/api/import", headers=H, files={"file": ("pb.csv", csv_text.encode())}, data={"store": "v3shop"})
    a = C.get("/api/alerts?store=v3shop&cashier=Zed Q.&rule=no_sale_after_cash&status=", headers=H).json()["items"]
    assert a and a[0]["assigned_to"] == "owner" and a[0]["case_id"] and "playbook" in a[0]["tags"]
    runs = [x for x in C.get("/api/automations", headers=H).json() if x["name"] == "Collusion → case"][0]["runs"]
    assert runs >= 1


# ------------------------------------------------------------------ detection engineering

def test_custom_rule_validation():
    with pytest.raises(RuleError):
        validate({"match": [{"field": "__import__", "op": "==", "value": 1}]})
    with pytest.raises(RuleError):
        validate({"match": [{"field": "amount", "op": "contains", "value": 1}]})
    with pytest.raises(RuleError):
        validate({"match": [{"field": "txn_type", "op": "==", "value": "hack"}]})
    d = validate({"match": [{"field": "txn_type", "op": "==", "value": "refund"}],
                  "aggregate": {"by": ["day"], "count_gte": 3}})
    assert d["aggregate"]["by"] == ["cashier", "day"]


def test_custom_rule_test_create_and_alert(H):
    body = {"name": "Big cash refunds", "severity": 4, "definition": {
        "match": [{"field": "txn_type", "op": "==", "value": "refund"}, {"field": "payment_method", "op": "==", "value": "cash"},
                  {"field": "amount", "op": ">=", "value": 10}]}}
    t = C.post("/api/custom-rules/test?store=v3shop", headers=H, json=body).json()
    assert t["matches"] > 0 and t["by_cashier"]
    r = C.post("/api/custom-rules", headers=H, json=body)
    assert r.status_code == 200 and r.json()["new_alerts"] > 0
    rid = r.json()["id"]
    al = C.get(f"/api/alerts?store=v3shop&rule=custom:{rid}&status=", headers=H).json()
    assert al["total"] > 0 and al["items"][0]["rule_id"] == f"CU-{rid:03d}" and al["rule_labels"][f"custom:{rid}"].endswith("Big cash refunds")
    agg = {"name": "Many voids", "severity": 3, "definition": {"match": [{"field": "txn_type", "op": "==", "value": "void"}],
                                                               "aggregate": {"by": ["cashier", "day"], "count_gte": 2}}}
    assert C.post("/api/custom-rules/test?store=v3shop", headers=H, json=agg).status_code == 200


def test_backtest_and_sigma(H):
    bt = C.post("/api/settings/rules/backtest?store=v3shop", headers=H, json={"no_sale_excess": {"max_per_shift": 1}}).json()
    row = next(r for r in bt["rules"] if r["rule"] == "no_sale_excess")
    assert row["proposed"] >= row["current"] and row["delta"] >= 0
    off = C.post("/api/settings/rules/backtest?store=v3shop", headers=H, json={"paid_out": {"enabled": False}}).json()
    assert next(r for r in off["rules"] if r["rule"] == "paid_out")["proposed"] == 0
    y = C.get("/api/detections/sigma", headers=H)
    assert y.status_code == 200 and y.text.count("\n---\n") >= 23 and "logsource:" in y.text and "drawerguard.stateful" in y.text
    assert 'title: "Too many No-Sale drawer opens"' in y.text


# ------------------------------------------------------------------ hunting

def test_hunt_sandbox_blocks_everything_but_reads(H):
    ok = C.post("/api/hunt/run", headers=H, json={"sql": "SELECT cashier, COUNT(*) n FROM transactions GROUP BY cashier"})
    assert ok.status_code == 200 and ok.json()["rows"]
    for bad in ["DELETE FROM alerts", "SELECT * FROM users", "SELECT 1; DROP TABLE alerts", "SELECT * FROM api_keys",
                "SELECT name FROM sqlite_master", "UPDATE alerts SET status='dismissed'", "SELECT * FROM pragma_table_info('users')",
                "WITH x AS (SELECT * FROM login_events) SELECT * FROM x"]:
        assert C.post("/api/hunt/run", headers=H, json={"sql": bad}).status_code == 400, bad
    lib = C.get("/api/hunt/library", headers=H).json()["library"]
    for h in lib:
        r = C.post("/api/hunt/run", headers=H, json={"sql": h["sql"]})
        assert r.status_code == 200, (h["name"], r.text)
    mgr_h = None
    C.post("/api/users", headers=H, json={"username": "huntmgr", "password": "huntmgr123", "role": "manager", "stores": ["v3shop"]})
    mgr_h = login("huntmgr", "huntmgr123")
    assert C.post("/api/hunt/run", headers=mgr_h, json={"sql": "SELECT 1"}).status_code == 403
    pv = C.get("/api/hunt/pivot?group_by=cashier&group_by2=hour&metric=count&type=no_sale&store=v3shop", headers=mgr_h)
    assert pv.status_code == 200 and pv.json()["rows"]
    assert C.get("/api/hunt/pivot?group_by=cashier;DROP&store=v3shop", headers=mgr_h).status_code == 400
    assert C.post("/api/hunt/saved", headers=H, json={"name": "x", "sql": "SELECT * FROM users"}).status_code == 400


def test_hunt_timeout():
    with pytest.raises(hunt.HuntError, match="longer than"):
        hunt.run("WITH RECURSIVE c(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM c) SELECT COUNT(*) FROM c")


# ------------------------------------------------------------------ forensics

def test_benford_math():
    counts, n = forensics.digit_dist([1.5, 0.19, 23, 230, 9.99, 0])
    assert n == 5 and counts[1] == 2 and counts[2] == 2 and counts[9] == 1
    exact = {d: round(forensics.BENFORD[d] * 10000) for d in range(1, 10)}
    assert forensics.mad(exact, sum(exact.values()), forensics.BENFORD) < 0.001
    assert forensics.conformity(0.004) == "close conformity" and forensics.conformity(0.02) == "nonconformity"


def test_forensics_endpoints_and_collusion_graph(H):
    b = C.get("/api/forensics/benford?type=refund&store=v3shop", headers=H).json()
    assert b["n"] > 0 and len(b["expected"]) == 9
    r = C.get("/api/forensics/rounding?type=refund&store=v3shop", headers=H).json()
    assert r["cashiers"]
    net = C.get("/api/forensics/approvals?store=v3shop", headers=H).json()
    flagged = [e for e in net["edges"] if e["flagged"]]
    assert flagged and flagged[0]["cashier"] == "Sofia V." and flagged[0]["approver"] == "Rita (Manager)"
    hm = C.get("/api/forensics/heatmap?days=0&store=v3shop", headers=H).json()
    assert hm["days"] and hm["cashiers"] and hm["cells"]
    assert C.get("/api/forensics/benford?type=bogus", headers=H).status_code == 400


# ------------------------------------------------------------------ security center, API keys

def test_login_telemetry_new_device_and_ip_limit(H):
    C.post("/api/users", headers=H, json={"username": "devuser", "password": "devuser123", "role": "manager"})
    assert C.post("/api/login", json={"username": "devuser", "password": "devuser123"}, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0) Chrome/120"}).status_code == 200
    assert C.post("/api/login", json={"username": "devuser", "password": "devuser123"}, headers={"User-Agent": "Mozilla/5.0 (iPhone) Safari/604"}).status_code == 200
    C.post("/api/login", json={"username": "devuser", "password": "WRONG"})
    ov = C.get("/api/security/overview", headers=H).json()
    mine = [e for e in ov["events"] if e["username"] == "devuser"]
    assert any(e["new_device"] for e in mine) and any(not e["success"] for e in mine)
    from app import security
    security._ip_fails.clear()
    for i in range(security.IP_LIMIT):
        C.post("/api/login", json={"username": f"spray{i}", "password": "x"})
    assert C.post("/api/login", json={"username": "owner", "password": "ownerpass1"}).status_code == 429   # IP blocked
    security._ip_fails.clear()


def test_signout_all(H):
    C.post("/api/users", headers=H, json={"username": "sess", "password": "sesspass1", "role": "auditor"})
    a, b = login("sess", "sesspass1"), login("sess", "sesspass1")
    new = C.post("/api/me/signout-all", headers=a).json()["token"]
    assert C.get("/api/me", headers=b).status_code == 401 and C.get("/api/me", headers=a).status_code == 401
    assert C.get("/api/me", headers={"Authorization": f"Bearer {new}"}).status_code == 200


def test_api_keys_ingest_scopes_and_revocation(H):
    k = C.post("/api/apikeys", headers=H, json={"name": "pos-bridge", "scopes": ["ingest"], "stores": ["v3shop"]}).json()
    key = k["key"]
    assert key.startswith("dg_") and all(key not in json.dumps(x) for x in C.get("/api/apikeys", headers=H).json())
    body = {"transactions": [{"id": "API1", "ts": "2026-11-09T12:00:00", "cashier": "Api C.", "register": "T7", "type": "Sale",
                              "amount": 15, "payment_method": "cash"},
                             {"id": "API2", "ts": "2026-11-09T12:00:20", "cashier": "Api C.", "register": "T7", "type": "No Sale"},
                             {"bad": True}]}
    r = C.post("/api/v1/transactions?store=v3shop", headers={"X-API-Key": key}, json=body)
    assert r.status_code == 200 and r.json()["added"] == 2 and r.json()["rejected"]
    assert C.post("/api/v1/transactions?store=main", headers={"X-API-Key": key}, json=body).status_code == 403      # store scope
    assert C.get("/api/v1/alerts", headers={"X-API-Key": key}).status_code == 403                                    # no read scope
    assert C.post("/api/v1/transactions", headers={"X-API-Key": "dg_fake_123"}, json=body).status_code == 401
    rk = C.post("/api/apikeys", headers=H, json={"name": "soar", "scopes": ["read"], "stores": ["*"]}).json()
    rd = C.get("/api/v1/alerts?min_severity=4&limit=5", headers={"X-API-Key": rk["key"]}).json()
    assert rd["alerts"] and rd["alerts"][0]["rule"]["id"].startswith(("DG-", "CU-"))
    C.delete(f"/api/apikeys/{k['id']}", headers=H)
    assert C.post("/api/v1/transactions?store=v3shop", headers={"X-API-Key": key}, json=body).status_code == 401


def test_webhook_signature(monkeypatch):
    from app import siem
    monkeypatch.setenv("SIEM_WEBHOOK_SECRET", "s3cret")
    h = siem.signed_headers(b'{"a":1}')
    assert siem.verify_signature("s3cret", b'{"a":1}', h["X-DrawerGuard-Timestamp"], h["X-DrawerGuard-Signature"])
    assert not siem.verify_signature("s3cret", b'{"a":2}', h["X-DrawerGuard-Timestamp"], h["X-DrawerGuard-Signature"])
    assert not siem.verify_signature("wrong", b'{"a":1}', h["X-DrawerGuard-Timestamp"], h["X-DrawerGuard-Signature"])


# ------------------------------------------------------------------ evidence integrity, backups, retention, health, search

def test_evidence_hash_tamper_detection_and_package(H):
    a = C.get("/api/alerts?store=v3shop&status=&min_severity=4&limit=2", headers=H).json()["items"]
    cid = C.post("/api/cases", headers=H, json={"store": "v3shop", "cashier": a[0]["cashier"], "title": "Integrity test",
                                                "alert_ids": [a[0]["id"]]}).json()["id"]
    up = C.post("/api/evidence", headers=H, files={"file": ("still.png", b"\x89PNG original bytes", "image/png")},
                data={"case_id": str(cid), "note": "cam 2"}).json()
    assert len(up["sha256"]) == 64
    assert C.get(f"/api/evidence/{up['id']}/verify", headers=H).json()["status"] == "intact"
    from app.db import DATA_DIR
    from app.deps import conn
    stored = conn.execute("SELECT stored_name FROM evidence WHERE id=?", (up["id"],)).fetchone()["stored_name"]
    (DATA_DIR / "evidence" / stored).write_bytes(b"\x89PNG TAMPERED")
    assert C.get(f"/api/evidence/{up['id']}/verify", headers=H).json()["status"] == "MODIFIED"
    z = zipfile.ZipFile(io.BytesIO(C.get(f"/api/cases/{cid}/package", headers=H).content))
    man = json.loads(z.read("manifest.json"))
    assert "case_file.html" in z.namelist() and any(f.get("intact") is False for f in man["files"])


def test_backups_retention_health_search(H):
    b = C.post("/api/admin/backup", headers=H).json()
    assert b["name"] in [x["name"] for x in C.get("/api/admin/backups", headers=H).json()]
    assert C.get(f"/api/admin/backups/{b['name']}", headers=H).status_code == 200
    for evil in ("..%2F..%2Fetc%2Fpasswd", "drawerguard_1.db", "..%2Fdrawerguard.db"):
        assert C.get(f"/api/admin/backups/{evil}", headers=H).status_code == 404
    assert C.post("/api/admin/retention", headers=H, json={"days": 7}).status_code == 400
    dry = C.post("/api/admin/retention", headers=H, json={"days": 3650, "dry_run": True}).json()
    assert dry["dry_run"] and "would_delete" in dry
    health = C.get("/api/health/data", headers=H).json()
    assert any(h["store"] == "v3shop" and h["transactions"] > 0 for h in health)
    s = C.get("/api/search?q=Sofia", headers=H).json()
    assert "Sofia V." in s["cashiers"]
