"""Application-security tests: DrawerGuard attacked the way an insider or an outsider would.

Each test is tagged with the OWASP Top 10 (2021) category it covers; docs/APPSEC.md maps
them to OWASP ASVS 4.0.3 requirements. The threat actor that matters most is a manager or
cashier who wants to see another store's data, hide their own alerts, or plant something
in the data that runs in an analyst's browser or spreadsheet.
"""
import csv
import io
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if "DRAWERGUARD_DB" not in os.environ:                 # when run on its own
    _tmp = Path(tempfile.mkdtemp())
    os.environ.update(DRAWERGUARD_DB=str(_tmp / "test.db"), DRAWERGUARD_DATA=str(_tmp / "data"),
                      DRAWERGUARD_PASSWORD="ownerpass1", REPORTS_ENABLED="0")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import security  # noqa: E402
from app.deps import conn  # noqa: E402
from app.main import app  # noqa: E402

C = TestClient(app)
XSS = "<script>alert(1)</script>"
FORMULA = "=HYPERLINK(\"http://evil.example\",\"x\")"
CSV_A = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total,Reason\n"
         "SA1,11/09/2026,10:00:00,Ana P.,T1,Sale,Cash,$12.00,\n"
         f"SA2,11/09/2026,10:05:00,\"{XSS}\",T1,Refund,Cash,$40.00,{XSS}\n"
         f"SA3,11/09/2026,10:06:00,\"{FORMULA.replace(chr(34), chr(34) * 2)}\",T1,Refund,Cash,$35.00,\n")
CSV_B = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total\n"
         "SB1,11/09/2026,11:00:00,Bo Q.,T1,Refund,Cash,$45.00\n")


def login(u, p):
    r = C.post("/api/login", json={"username": u, "password": p})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="module")
def env():
    owner = login("owner", "ownerpass1")
    for csv_text, store in ((CSV_A, "seca"), (CSV_B, "secb")):
        r = C.post("/api/import", headers=owner, files={"file": ("x.csv", csv_text.encode())}, data={"store": store})
        assert r.status_code == 200, r.text
    for u, role, stores in (("mgr_a", "manager", ["seca"]), ("aud_a", "auditor", ["seca"])):
        C.post("/api/users", headers=owner, json={"username": u, "password": "long-enough-pass-1", "role": role, "stores": stores})
    b_alert = C.get("/api/alerts?store=secb&status=", headers=owner).json()["items"][0]["id"]
    b_case = C.post("/api/cases", headers=owner, json={"store": "secb", "cashier": "Bo Q.", "title": "B", "alert_ids": [b_alert]}).json()["id"]
    return {"owner": owner, "mgr": login("mgr_a", "long-enough-pass-1"), "aud": login("aud_a", "long-enough-pass-1"),
            "b_alert": b_alert, "b_case": b_case}


# ------------------------------------------------------------------ A01 Broken access control

@pytest.mark.parametrize("path", [
    "/api/alerts?store=secb", "/api/summary?store=secb", "/api/transactions?store=secb", "/api/payroll/overview?store=secb",
    "/api/incidents?store=secb", "/api/graph?store=secb", "/api/purple/runs?store=secb", "/api/watchlist?store=secb",
    "/api/ml/health?store=secb", "/api/soc/metrics?store=secb",
])
def test_a01_manager_cannot_read_another_store(env, path):
    assert C.get(path, headers=env["mgr"]).status_code == 403


def test_a01_object_level_checks_on_ids(env):
    m = env["mgr"]
    assert C.get(f"/api/cases/{env['b_case']}", headers=m).status_code == 403
    assert C.get(f"/api/cases/{env['b_case']}/ir", headers=m).status_code == 403
    assert C.get(f"/api/cases/{env['b_case']}/ir-report", headers=m).status_code == 403
    assert C.patch(f"/api/alerts/{env['b_alert']}", headers=m, json={"status": "dismissed"}).status_code == 403
    assert C.post("/api/alerts/bulk", headers=m, json={"ids": [env["b_alert"]], "status": "dismissed"}).status_code == 403
    assert C.get(f"/api/alerts/{env['b_alert']}/history", headers=m).status_code == 403
    assert C.post("/api/watchlist", headers=m, json={"store": "secb", "cashier": "Bo Q.", "reason": "spying"}).status_code == 403


def test_a01_role_checks(env):
    a, m = env["aud"], env["mgr"]
    al = C.get("/api/alerts?store=seca&status=", headers=a).json()["items"][0]["id"]
    assert C.patch(f"/api/alerts/{al}", headers=a, json={"status": "dismissed"}).status_code == 403      # auditors read only
    assert C.post("/api/canaries", headers=m, json={"kind": "approver", "value": "Zed Z."}).status_code == 403   # owner only
    assert C.post("/api/purple/run", headers=m, json={"store": "seca"}).status_code == 403
    assert C.post("/api/users", headers=m, json={"username": "x2", "password": "long-enough-pass-1"}).status_code == 403
    assert C.get("/api/admin/backups", headers=m).status_code == 403


def test_a01_mass_assignment_is_ignored(env):
    o = env["owner"]
    al = C.get("/api/alerts?store=seca&status=", headers=o).json()["items"][0]
    r = C.patch(f"/api/alerts/{al['id']}", headers=o, json={"notes": "ok", "severity": 1, "store": "secb", "rule": "x"})
    assert r.status_code == 200
    after = conn.execute("SELECT severity, store, rule FROM alerts WHERE id=?", (al["id"],)).fetchone()
    assert (after["severity"], after["store"], after["rule"]) == (al["severity"], "seca", al["rule"])


# ------------------------------------------------------------------ A02 Cryptographic failures

def test_a02_passwords_and_api_keys_are_hashed(env):
    for r in conn.execute("SELECT pw_hash FROM users"):
        assert r["pw_hash"].startswith("pbkdf2$200000$")
    key = C.post("/api/apikeys", headers=env["owner"], json={"name": "t", "scopes": ["read"], "stores": ["seca"]}).json()["key"]
    secret = key.split("_")[-1]
    dump = "\n".join(conn.iterdump())
    assert secret not in dump and key not in dump


def test_a02_tampered_and_foreign_tokens_are_rejected(env):
    tok = env["mgr"]["Authorization"].split(" ")[1]
    bad = tok[:-1] + ("0" if tok[-1] != "0" else "1")
    assert C.get("/api/me", headers={"Authorization": f"Bearer {bad}"}).status_code == 401
    forged = "owner" + tok[tok.index("|"):]                  # change the username, keep the signature
    assert C.get("/api/me", headers={"Authorization": f"Bearer {forged}"}).status_code == 401


# ------------------------------------------------------------------ A03 Injection

@pytest.mark.parametrize("payload", ["' OR '1'='1", "x'; DROP TABLE alerts; --", "%' UNION SELECT username, pw_hash FROM users --"])
def test_a03_sql_injection_in_filters(env, payload):
    o = env["owner"]
    for path in (f"/api/alerts?store=seca&cashier={payload}&status=", f"/api/transactions?store=seca&q={payload}",
                 f"/api/alerts?store=seca&q={payload}&status="):
        r = C.get(path, headers=o)
        assert r.status_code == 200 and "pbkdf2" not in r.text
    assert conn.execute("SELECT COUNT(*) n FROM alerts").fetchone()["n"] > 0


@pytest.mark.parametrize("sql", ["DELETE FROM alerts", "ATTACH DATABASE 'x.db' AS x", "PRAGMA writable_schema=1",
                                 "SELECT * FROM users", "SELECT * FROM audit_log", "WITH x AS (SELECT * FROM api_keys) SELECT * FROM x",
                                 "SELECT load_extension('evil')"])
def test_a03_hunt_sandbox_blocks(env, sql):
    assert C.post("/api/hunt/run", headers=env["owner"], json={"sql": sql}).status_code == 400


def test_a03_stored_xss_is_escaped_in_server_rendered_reports(env):
    o = env["owner"]
    al = C.get(f"/api/alerts?store=seca&cashier={XSS}&status=", headers=o).json()["items"]
    assert al, "the XSS cashier should have an alert (unmatched refund)"
    cid = C.post("/api/cases", headers=o, json={"store": "seca", "cashier": XSS, "title": XSS, "alert_ids": [al[0]["id"]]}).json()["id"]
    for path in (f"/api/cases/{cid}/file", f"/api/cases/{cid}/ir-report"):
        page = C.get(path, headers=o).text
        assert XSS not in page and "&lt;script&gt;" in page, path


def test_a03_csv_formula_injection_is_neutralised(env):
    r = C.get("/api/export/alerts.csv?store=seca", headers=env["owner"])
    cells = [c for row in csv.reader(io.StringIO(r.text)) for c in row]
    assert any(c.startswith("'=HYPERLINK") for c in cells)
    assert not any(c.startswith("=") for c in cells)


# ------------------------------------------------------------------ A04 Insecure design / A07 Authentication

def test_a07_lockout_persists_even_with_the_right_password(env):
    C.post("/api/users", headers=env["owner"], json={"username": "lockme", "password": "long-enough-pass-1", "role": "auditor",
                                                     "stores": ["seca"]})
    for _ in range(8):
        assert C.post("/api/login", json={"username": "lockme", "password": "wrong-password"}).status_code == 401
    r = C.post("/api/login", json={"username": "lockme", "password": "long-enough-pass-1"})
    assert r.status_code == 429 and "30 minutes" in r.json()["detail"]
    assert conn.execute("SELECT COUNT(*) n FROM login_events WHERE username='lockme' AND success=0").fetchone()["n"] >= 9
    security._ip_fails.clear()


def test_a07_password_policy_and_sign_out_everywhere(env):
    assert C.post("/api/users", headers=env["owner"], json={"username": "weak", "password": "short"}).status_code == 400
    h = login("aud_a", "long-enough-pass-1")
    assert C.post("/api/me/signout-all", headers=h).status_code == 200
    assert C.get("/api/me", headers=h).status_code == 401


def test_a04_abuse_limits(env):
    o = env["owner"]
    assert C.post("/api/purple/run", headers=o, json={"store": "seca", "intensity": 99}).status_code == 400
    assert C.post("/api/watchlist", headers=o, json={"store": "seca", "cashier": "Ana P.", "reason": "x" * 1000}).status_code == 422
    assert C.post("/api/canaries", headers=o, json={"kind": "employee", "value": "Ana P."}).status_code == 400   # collides with real data


# ------------------------------------------------------------------ A05 Security misconfiguration

def test_a05_security_headers():
    r = C.get("/")
    h = {k.lower(): v for k, v in r.headers.items()}
    assert "frame-ancestors 'none'" in h["content-security-policy"] and "object-src 'none'" in h["content-security-policy"]
    assert h["x-frame-options"] == "DENY" and h["x-content-type-options"] == "nosniff" and h["referrer-policy"] == "no-referrer"
    assert "no-store" in C.get("/api/health").headers.get("cache-control", "")


def test_a05_uploads_and_paths(env):
    o = env["owner"]
    al = C.get("/api/alerts?store=seca&status=", headers=o).json()["items"][0]["id"]
    for name in ("x.html", "x.exe", "x.svg", "x.php"):
        assert C.post("/api/evidence", headers=o, files={"file": (name, b"<b>hi</b>")}, data={"alert_id": str(al)}).status_code == 400
    for bad in ("..%2F..%2Fetc%2Fpasswd", "drawerguard.db", "..", "%2Fetc%2Fshadow"):
        assert C.get(f"/api/admin/backups/{bad}", headers=o).status_code in (400, 404)


# ------------------------------------------------------------------ A08 Integrity / A09 Logging

def test_a08_audit_chain_detects_tampering(env):
    o = env["owner"]
    assert C.get("/api/audit/verify", headers=o).json()["ok"]
    row = conn.execute("SELECT id, action FROM audit_log ORDER BY id DESC LIMIT 1").fetchone()
    conn.execute("UPDATE audit_log SET action='nothing to see' WHERE id=?", (row["id"],))
    conn.commit()
    try:
        v = C.get("/api/audit/verify", headers=o).json()
        assert not v["ok"] and v["broken_at"] == row["id"]
    finally:
        conn.execute("UPDATE audit_log SET action=? WHERE id=?", (row["action"], row["id"]))
        conn.commit()
    assert C.get("/api/audit/verify", headers=o).json()["ok"]


def test_a09_security_events_are_logged(env):
    C.post("/api/login", json={"username": "mgr_a", "password": "nope-nope"})
    assert conn.execute("SELECT COUNT(*) n FROM audit_log WHERE action='failed login' AND actor='mgr_a'").fetchone()["n"] >= 1
    C.get("/api/export/alerts.csv?store=seca", headers=env["owner"])
    assert conn.execute("SELECT COUNT(*) n FROM audit_log WHERE action='exported alerts'").fetchone()["n"] >= 1
    security._ip_fails.clear()


# ------------------------------------------------------------------ A10 SSRF

def test_a10_no_user_controlled_outbound_urls(env):
    """Outbound destinations (SIEM, TheHive, Jira, Claude) come only from the server's .env: no API accepts a URL."""
    spec = C.get("/openapi.json").json()
    for path, methods in spec["paths"].items():
        for m, op in methods.items():
            body = op.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema", {})
            ref = body.get("$ref", "").split("/")[-1]
            props = spec["components"]["schemas"].get(ref, {}).get("properties", {}) if ref else {}
            assert not [p for p in props if "url" in p.lower() and p not in ("url_template",)], f"{m.upper()} {path}"
