"""Property-based fuzzing (Hypothesis) of everything that parses untrusted input: money and date
parsing, column detection, the importers, the custom-rule language, the detection-test DSL,
PAN masking and the hunt sandbox. The property is always the same: no crash other than the
documented, handled error type, and invariants hold for any input."""
import os
import sys
import tempfile
from pathlib import Path

import pytest

hypothesis = pytest.importorskip("hypothesis")
from hypothesis import HealthCheck, given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if "DRAWERGUARD_DB" not in os.environ:
    _tmp = Path(tempfile.mkdtemp())
    os.environ.update(DRAWERGUARD_DB=str(_tmp / "test.db"), DRAWERGUARD_DATA=str(_tmp / "data"),
                      DRAWERGUARD_PASSWORD="ownerpass1", REPORTS_ENABLED="0")

from app.db import connect, init_db  # noqa: E402
from app.detection.custom import RuleError, validate  # noqa: E402
from app.detection.dac import DacError, parse_events, parse_punches  # noqa: E402
from app.ingest.csv_importer import find_pans, import_file, mask_pans, parse_dt, parse_money  # noqa: E402

FAST = settings(max_examples=150, deadline=None, suppress_health_check=[HealthCheck.too_slow])
cell = st.text(alphabet=st.characters(blacklist_categories=("Cs",)), max_size=30)


@FAST
@given(st.one_of(cell, st.integers(), st.floats(allow_nan=False, allow_infinity=False), st.none()))
def test_parse_money_never_crashes(v):
    out = parse_money(v)
    assert isinstance(out, float)


@FAST
@given(cell, st.one_of(st.none(), cell), st.one_of(st.none(), st.booleans()))
def test_parse_dt_never_crashes(v, t, dayfirst):
    out = parse_dt(v, t, dayfirst)
    assert out is None or (isinstance(out, str) and len(out) >= 10)


@FAST
@given(st.text(max_size=120))
def test_pan_masking_invariants(text):
    masked, n = mask_pans(text)
    assert n == len(find_pans(text))
    assert find_pans(masked) == []              # nothing card-like survives
    assert len(masked) <= len(text) + 0         # masking never grows the text


@settings(max_examples=60, deadline=None, suppress_health_check=[HealthCheck.too_slow, HealthCheck.function_scoped_fixture])
@given(st.lists(st.lists(cell, min_size=1, max_size=6), min_size=1, max_size=8), st.sampled_from(["auto", "transactions", "shifts", "timeclock"]))
def test_importer_survives_garbage_csv(rows, kind):
    conn = connect(":memory:")
    init_db(conn)
    text = "\n".join(",".join('"' + c.replace('"', '""') + '"' for c in r) for r in rows)
    try:
        r = import_file(conn, text.encode(), "fuzz.csv", kind=kind, store="fz")
        assert r["rows_added"] <= r["rows_read"]
    except ValueError:
        pass                                     # "could not find a date column" etc. is the handled error


json_leaf = st.one_of(st.none(), st.booleans(), st.integers(), st.floats(allow_nan=False), cell)
json_val = st.recursive(json_leaf, lambda ch: st.one_of(st.lists(ch, max_size=4), st.dictionaries(cell, ch, max_size=4)), max_leaves=12)


@FAST
@given(json_val)
def test_custom_rule_language_rejects_cleanly(defn):
    try:
        validate(defn)
    except RuleError:
        pass


@FAST
@given(st.lists(st.text(max_size=60), max_size=4))
def test_detection_dsl_rejects_cleanly(lines):
    for fn in (parse_events, parse_punches):
        try:
            fn(lines)
        except (DacError, ValueError, IndexError, KeyError):
            pass


@settings(max_examples=80, deadline=None)
@given(st.text(max_size=200))
def test_hunt_sandbox_never_writes(sql):
    from app import hunt
    conn = connect(str(Path(os.environ["DRAWERGUARD_DB"])))
    init_db(conn)
    before = conn.execute("SELECT COUNT(*) n FROM sqlite_master").fetchone()["n"]
    try:
        hunt.run(sql, str(Path(os.environ["DRAWERGUARD_DB"])))
    except Exception:  # noqa: S110 - any rejection is fine; the property is that nothing changes
        pass
    assert conn.execute("SELECT COUNT(*) n FROM sqlite_master").fetchone()["n"] == before
