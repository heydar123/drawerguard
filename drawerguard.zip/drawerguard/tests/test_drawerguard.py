import os
import sqlite3
import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
_tmp = Path(tempfile.mkdtemp())
os.environ["DRAWERGUARD_DB"] = str(_tmp / "test.db")
os.environ["DRAWERGUARD_DATA"] = str(_tmp / "data")
os.environ["DRAWERGUARD_PASSWORD"] = "ownerpass1"
os.environ["REPORTS_ENABLED"] = "0"

import pytest  # noqa: E402

from app.auth import check_pw, hash_pw  # noqa: E402
from app.config import DEFAULT_RULES, merged_rules  # noqa: E402
from app.db import connect, init_db  # noqa: E402
from app.detection.ai import build_summary, day_profiles, rule_behavior_change, score_days  # noqa: E402
from app.detection.engine import cashier_scores, run_detection  # noqa: E402
from app.detection.rules import Context, run_rules  # noqa: E402
from app.ingest.csv_importer import (detect_dayfirst, import_file, map_payment, map_type,  # noqa: E402
                                     parse_dt, parse_money)
from sample_data.generate_demo import Gen  # noqa: E402


# ------------------------------------------------------------------ parsing

@pytest.mark.parametrize("raw,val", [("$1,234.50", 1234.5), ("(12.00)", -12.0), ("-5", -5.0), ("12,50", 12.5), ("", 0.0), (7, 7.0)])
def test_parse_money(raw, val):
    assert parse_money(raw) == val


def test_parse_dates():
    assert parse_dt("11/08/2026 14:05:00") == "2026-11-08T14:05:00"
    assert parse_dt("08/11/2026 14:05", dayfirst_hint=True) == "2026-11-08T14:05:00"
    assert detect_dayfirst(["25/10/2026"]) is True
    assert detect_dayfirst(["10/25/2026"]) is False


@pytest.mark.parametrize("raw,typ", [("Open Drawer", "no_sale"), ("NO SALE", "no_sale"), ("Item Void", "void"), ("Comp", "discount"),
                                     ("Paid Out", "paid_out"), ("Order Cancelled", "cancel"), ("Refund", "refund"), ("Sale", "sale")])
def test_map_type(raw, typ):
    assert map_type(raw) == typ


def test_map_payment():
    assert map_payment("EFTPOS") == "card" and map_payment("Cash") == "cash" and map_payment("Voucher") == "other"


# ------------------------------------------------------------------ rules

def T(id, ts, cashier="Ann", typ="sale", amount=10.0, pay="cash", order="", orig="", disc=0.0, appr="", kitchen=0, reg="T1"):
    return dict(store="main", id=id, ts=ts, cashier=cashier, register=reg, txn_type=typ, amount=amount, payment_method=pay, order_id=order,
                original_txn_id=orig, discount_amount=disc, approved_by=appr, sent_to_kitchen=kitchen, note="")


def rules_hit(txns, shifts=()):
    return {a["rule"] for a in run_rules(Context(txns, list(shifts)), merged_rules({}))}


def test_no_sale_rules():
    assert "no_sale_after_cash" in rules_hit([T("1", "2026-11-01T10:00:00"), T("2", "2026-11-01T10:00:40", typ="no_sale", amount=0, pay="")])
    txns = [T(f"n{i}", f"2026-11-01T1{i}:00:00", typ="no_sale", amount=0, pay="") for i in range(5)]
    assert {"no_sale_isolated", "no_sale_excess"} <= rules_hit(txns)


def test_refund_rules():
    txns = [T("s1", "2026-11-01T10:00:00", pay="card", amount=12),
            T("r1", "2026-11-01T10:05:00", typ="refund", amount=12, pay="cash", orig="s1"),
            T("r2", "2026-11-01T11:00:00", typ="refund", amount=20, pay="cash"),
            T("r3", "2026-11-01T12:00:00", typ="refund", amount=30, pay="card", orig="s1", appr="Ann")]
    assert {"cash_refund_on_card_sale", "refund_own_sale_quick", "unmatched_refund", "round_amount_refund",
            "refund_exceeds_original", "self_approved", "unapproved_override"} <= rules_hit(txns)


def test_void_after_cash_payment_but_not_before():
    before = [T("v", "2026-11-01T10:00:00", typ="void", amount=8, pay="", order="O1"), T("s", "2026-11-01T10:01:00", order="O1", amount=20)]
    after = [T("s", "2026-11-01T10:00:00", order="O1", amount=20), T("v", "2026-11-01T10:03:00", typ="void", amount=8, pay="", order="O1")]
    assert "post_payment_void" not in rules_hit(before)
    assert "post_payment_void" in rules_hit(after)


def test_discount_cancel_offhours_paidout():
    txns = [T("s", "2026-11-01T10:00:00", amount=5, disc=15, order="A"),
            T("c", "2026-11-01T11:00:00", typ="cancel", amount=30, pay="", kitchen=1),
            T("p", "2026-11-01T12:00:00", typ="paid_out", amount=50),
            T("x", "2026-11-01T02:00:00", typ="no_sale", amount=0, pay="")]
    assert {"excess_discount", "cancel_after_kitchen", "paid_out", "off_hours"} <= rules_hit(txns)


def test_cash_shortage_and_repeat():
    shifts = [dict(store="main", cashier="Ann", register="T1", start_ts=f"2026-11-0{d}T07:00:00", end_ts=f"2026-11-0{d}T15:00:00",
                   expected_cash=500, counted_cash=470) for d in (1, 3, 5)]
    assert {"cash_shortage", "repeat_shortage"} <= rules_hit([T("s", "2026-11-01T10:00:00")], shifts)


def test_clean_cashier_has_no_alerts():
    txns = [T(f"s{i}", f"2026-11-01T{8 + i // 6:02d}:{(i % 6) * 10:02d}:00", amount=9.5, pay="card" if i % 2 else "cash") for i in range(40)]
    assert rules_hit(txns) == set()


def test_every_default_rule_has_label_and_severity():
    for k, v in DEFAULT_RULES.items():
        assert v["label"] and 1 <= v["severity"] <= 5, k


# ------------------------------------------------------------------ AI

def test_ai_scores_spike_day_high():
    txns = []
    for d in range(1, 15):
        for i in range(30):
            txns.append(T(f"{d}-{i}", f"2026-10-{d:02d}T{9 + i // 6:02d}:{(i % 6) * 9:02d}:00", pay="cash" if i % 2 else "card"))
            txns.append(T(f"b{d}-{i}", f"2026-10-{d:02d}T{9 + i // 6:02d}:{(i % 6) * 9 + 1:02d}:00", cashier="Bob", pay="cash" if i % 2 else "card"))
    for i in range(12):   # Ann's bad day: many No-Sales
        txns.append(T(f"ns{i}", f"2026-10-14T{10 + i // 4:02d}:{(i % 4) * 13 + 3:02d}:00", typ="no_sale", amount=0, pay=""))
    res = {(r["cashier"], r["day"]): r for r in score_days(day_profiles(Context(txns, [])), merged_rules({})["ai_anomaly"])}
    bad = res[("Ann", "2026-10-14")]
    assert bad["score"] >= 80 and bad["drivers"][0]["feature"] == "no_sale_rate"
    assert max(r["score"] for k, r in res.items() if k != ("Ann", "2026-10-14")) < 50


def test_behavior_change_detects_new_habit():
    txns = []
    for d in range(1, 29):
        for i in range(20):
            txns.append(T(f"{d}-{i}", f"2026-10-{d:02d}T{9 + i // 4:02d}:{(i % 4) * 12:02d}:00"))
        if d > 21:
            for i in range(3):
                txns.append(T(f"v{d}-{i}", f"2026-10-{d:02d}T15:{i * 10:02d}:00", typ="void", amount=6, pay=""))
    hits = rule_behavior_change(Context(txns, []), merged_rules({})["behavior_change"])
    assert any(h["rule"] == "behavior_change" and '"metric": "void"' in h["details"] for h in hits)


def test_build_summary_text():
    score = {"cashier": "Ann", "score": 88, "level": "high", "amount_at_risk": 120, "z": {"no_sale_rate": 3}, "metrics": {"no_sale_rate": 9}}
    alerts = [{"rule": "no_sale_after_cash", "severity": 4, "status": "open", "ts": "2026-11-01T10:00:00", "txn_id": "1", "register": "T1"}]
    s = build_summary(score, alerts, [], [])
    assert "HIGH risk" in s["headline"] and s["next_steps"]


# ------------------------------------------------------------------ auth

def test_password_hashing():
    h = hash_pw("secret123")
    assert check_pw("secret123", h) and not check_pw("nope", h)


# ------------------------------------------------------------------ end to end, two stores

@pytest.fixture(scope="module")
def demo():
    out = Path(tempfile.mkdtemp())
    c = connect(str(out / "e2e.db"))
    init_db(c)
    for store, name in (("main", "splitpos"), ("harbor", "harbor")):
        g = Gen(7, store)
        g.run(datetime(2026, 11, 8), 45)
        g.write(out, name)
        import_file(c, (out / f"{name}_transactions.csv").read_bytes(), "t.csv", store=store)
        import_file(c, (out / f"{name}_cashup.csv").read_bytes(), "c.csv", store=store)
    run_detection(c)
    return c, out


def test_e2e_thieves_rank_top_per_store(demo):
    demo_conn, _ = demo
    main = cashier_scores(demo_conn, 30, ["main"])
    assert {s["cashier"] for s in main[:3]} == {"Jake M.", "Tina R.", "Leo K."}
    assert all(s["level"] != "high" for s in main[3:])
    harbor = cashier_scores(demo_conn, 30, ["harbor"])
    assert {s["cashier"] for s in harbor[:2]} == {"Nina R.", "Sofia V."} and all(s["level"] != "high" for s in harbor[2:])


def test_e2e_ai_flags_only_thieves(demo):
    demo_conn, _ = demo
    flagged = [r["cashier"] for r in demo_conn.execute("SELECT cashier FROM alerts WHERE rule='ai_anomaly'")]
    thieves = {"Jake M.", "Tina R.", "Leo K.", "Nina R.", "Sofia V."}
    assert flagged and sum(c in thieves for c in flagged) / len(flagged) >= 0.85      # AI alert precision


def test_e2e_idempotent_and_dedup(demo):
    demo_conn, out = demo
    assert run_detection(demo_conn)["new_count"] == 0
    r = import_file(demo_conn, (out / "harbor_transactions.csv").read_bytes(), "again.csv", store="harbor")
    assert r["rows_added"] == 0


def test_migration_from_v1(tmp_path):
    p = tmp_path / "v1.db"
    c = sqlite3.connect(p)
    c.executescript("""
    CREATE TABLE transactions (id TEXT PRIMARY KEY, ts TEXT NOT NULL, cashier TEXT NOT NULL, register TEXT DEFAULT '', txn_type TEXT NOT NULL, amount REAL DEFAULT 0, payment_method TEXT DEFAULT '', order_id TEXT DEFAULT '', original_txn_id TEXT DEFAULT '', discount_amount REAL DEFAULT 0, approved_by TEXT DEFAULT '', sent_to_kitchen INTEGER DEFAULT 0, note TEXT DEFAULT '', source TEXT DEFAULT 'csv', imported_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE shifts (id INTEGER PRIMARY KEY AUTOINCREMENT, cashier TEXT NOT NULL, register TEXT DEFAULT '', start_ts TEXT NOT NULL, end_ts TEXT NOT NULL, opening_float REAL DEFAULT 0, expected_cash REAL, counted_cash REAL, UNIQUE(cashier, register, start_ts));
    CREATE TABLE alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT UNIQUE NOT NULL, rule TEXT NOT NULL, severity INTEGER NOT NULL, cashier TEXT, register TEXT, ts TEXT, txn_id TEXT, amount REAL DEFAULT 0, title TEXT NOT NULL, details TEXT DEFAULT '{}', status TEXT DEFAULT 'open', notes TEXT DEFAULT '', notified INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE import_log (id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, kind TEXT, rows_read INTEGER, rows_added INTEGER, errors TEXT DEFAULT '[]', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    INSERT INTO transactions(id,ts,cashier,register,txn_type,amount,payment_method) VALUES('A1','2026-11-01T10:00:00','Bob','T1','sale',12,'card');
    INSERT INTO transactions(id,ts,cashier,register,txn_type,amount,payment_method,original_txn_id) VALUES('A2','2026-11-01T10:05:00','Bob','T1','refund',12,'cash','A1');
    INSERT INTO alerts(fingerprint,rule,severity,cashier,title,status) VALUES('cash_refund_on_card_sale:A2','cash_refund_on_card_sale',5,'Bob','x','confirmed');
    """)
    c.commit()
    c.close()
    c = connect(str(p))
    init_db(c)
    assert c.execute("SELECT COUNT(*) FROM transactions WHERE store='main'").fetchone()[0] == 2
    new = run_detection(c)["new"]
    assert not any(a["rule"] == "cash_refund_on_card_sale" for a in new)          # kept, not duplicated
    assert c.execute("SELECT status FROM alerts WHERE rule='cash_refund_on_card_sale'").fetchone()[0] == "confirmed"


# ------------------------------------------------------------------ API: roles, stores, cases, evidence, reports

@pytest.fixture(scope="module")
def client():
    from fastapi.testclient import TestClient
    from app.main import app
    return TestClient(app)


def login(client, u, p):
    r = client.post("/api/login", json={"username": u, "password": p})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}, r.json()["token"]


CSV = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total,Original Receipt\n"
       "A1,11/01/2026,10:00:00,Bob,T1,Sale,Card,$12.00,\n"
       "A2,11/01/2026,10:05:00,Bob,T1,Refund,Cash,$12.00,A1\n"
       "A3,11/01/2026,10:06:00,Bob,T1,Open Drawer,,,\n")


def test_api_full_flow(client):
    assert client.get("/api/summary").status_code == 401
    assert client.post("/api/login", json={"username": "owner", "password": "nope"}).status_code == 401
    H, tok = login(client, "owner", "ownerpass1")
    r = client.post("/api/import", headers=H, files={"file": ("t.csv", CSV.encode())}, data={"store": "Second Shop"})
    assert r.status_code == 200 and r.json()["store"] == "second-shop" and r.json()["new_alerts"] >= 2
    r = client.post("/api/import", headers=H, files={"file": ("t.csv", CSV.encode())}, data={"store": "main"})
    assert r.json()["rows_added"] == 3                      # same receipt ids, different store = separate rows
    assert {s["id"] for s in client.get("/api/me", headers=H).json()["stores"]} >= {"main", "second-shop"}

    # users & roles
    assert client.post("/api/users", headers=H, json={"username": "mgr", "password": "managerpw1", "role": "manager", "stores": ["second-shop"]}).status_code == 200
    assert client.post("/api/users", headers=H, json={"username": "aud", "password": "auditorpw1", "role": "auditor"}).status_code == 200
    HM, tm = login(client, "mgr", "managerpw1")
    HA, _ = login(client, "aud", "auditorpw1")
    assert client.get("/api/summary?store=main", headers=HM).status_code == 403
    assert client.get("/api/users", headers=HM).status_code == 403
    alerts = client.get("/api/alerts?status=open&store=second-shop", headers=HM).json()
    assert alerts["total"] >= 2 and all(a["store"] == "second-shop" for a in alerts["items"])
    aid = alerts["items"][0]["id"]
    assert client.patch(f"/api/alerts/{aid}", headers=HA, json={"status": "dismissed"}).status_code == 403
    main_alert = client.get("/api/alerts?status=open&store=main", headers=H).json()["items"][0]["id"]
    assert client.patch(f"/api/alerts/{main_alert}", headers=HM, json={"status": "dismissed"}).status_code == 403

    # context + cctv
    client.post("/api/cameras", headers=H, json={"store": "second-shop", "register": "T1", "name": "Cam 1",
                                                 "url_template": "http://nvr/?s={start_compact}", "offset_seconds": 10})
    c = client.get("/api/context?store=second-shop&id=A2", headers=HM).json()
    assert c["linked"][0]["id"] == "A1" and c["cctv"][0]["url"] == "http://nvr/?s=20261101T100410"

    # cases + evidence
    ids = [a["id"] for a in alerts["items"]]
    cid = client.post("/api/cases", headers=HM, json={"store": "second-shop", "cashier": "Bob", "title": "Bob refunds", "alert_ids": ids}).json()["id"]
    assert client.post(f"/api/cases/{cid}/notes", headers=HM, json={"body": "checked CCTV"}).status_code == 200
    r = client.post("/api/evidence", headers=HM, files={"file": ("still.png", b"\x89PNG fake", "image/png")}, data={"case_id": str(cid), "note": "cam"})
    assert r.status_code == 200
    assert client.post("/api/evidence", headers=HM, files={"file": ("x.exe", b"MZ")}, data={"case_id": str(cid)}).status_code == 400
    case = client.get(f"/api/cases/{cid}", headers=HA).json()
    assert len(case["alerts"]) == len(ids) and len(case["evidence"]) == 1 and len(case["events"]) >= 3
    assert client.patch(f"/api/cases/{cid}", headers=HM, json={"status": "closed_theft", "loss_amount": 12}).status_code == 200
    assert all(a["status"] == "confirmed" for a in client.get(f"/api/alerts?case_id={cid}", headers=H).json()["items"])
    assert "Bob refunds" in client.get(f"/api/cases/{cid}/file?token={tm}").text

    # reports, AI summary, exports
    rep = client.post("/api/reports", headers=H, json={"days": 0}).json()
    assert "DrawerGuard" in client.get(f"/api/reports/{rep['id']}/view?token={tok}").text
    d = client.get("/api/cashiers/Bob?days=0&store=second-shop", headers=HM).json()
    assert d["summary"]["headline"].startswith("Bob")
    assert client.get(f"/api/export/alerts.csv?token={tok}").text.startswith("id,store")
    r = client.put("/api/settings/rules", headers=H, json={"no_sale_isolated": {"enabled": False}})
    assert r.json()["rules"]["no_sale_isolated"]["enabled"] is False
    assert client.put("/api/settings/rules", headers=HM, json={}).status_code == 403
    assert client.post("/api/me/password", headers=HA, json={"old": "auditorpw1", "new": "short"}).status_code == 400


# ------------------------------------------------------------------ security features (v2.1)

def test_totp_rfc6238_vector():
    from app.auth import totp_check, totp_now
    # RFC 6238 test secret "12345678901234567890" (base32) at T=59 -> 287082 (6-digit SHA1)
    sec = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    assert totp_now(sec, at=59) == "287082"
    assert totp_check(sec, "287082", 0, at=59) == 1
    assert totp_check(sec, "287082", 1, at=59) is None          # replay refused
    assert totp_check(sec, "000000", 0, at=59) is None


def test_audit_chain_detects_tampering(tmp_path):
    from app.db import audit, verify_audit
    c = connect(str(tmp_path / "a.db"))
    init_db(c)
    for i in range(5):
        audit(c, "owner", f"action {i}", "x")
    assert verify_audit(c)["ok"]
    c.execute("UPDATE audit_log SET action='nothing to see' WHERE id=3")
    c.commit()
    v = verify_audit(c)
    assert not v["ok"] and v["broken_at"] == 3


def test_siem_formats_and_udp_forward(monkeypatch):
    import json as _json
    import socket
    from app import siem
    a = {"id": 7, "store": "main", "rule": "cash_refund_on_card_sale", "severity": 5, "cashier": "Tina R.", "register": "Till|1",
         "ts": "2026-11-08T14:00:00", "txn_id": "R1", "amount": 12.5, "title": "Card sale refunded in cash = bad", "details": "{}"}
    cef = siem.to_cef(a)
    assert cef.startswith("CEF:0|DrawerGuard|DrawerGuard|") and "|DG-007|" in cef and "|10|" in cef
    assert "msg=Card sale refunded in cash \\= bad" in cef and "deviceExternalId=Till|1" in cef
    ecs = siem.to_ecs(a)
    assert ecs["rule"]["id"] == "DG-007" and ecs["user"]["name"] == "Tina R." and "False Refunds" in ecs["rule"]["category"]
    srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    srv.bind(("127.0.0.1", 0))
    srv.settimeout(3)
    monkeypatch.setenv("SIEM_SYSLOG_HOST", "127.0.0.1")
    monkeypatch.setenv("SIEM_SYSLOG_PORT", str(srv.getsockname()[1]))
    monkeypatch.setenv("SIEM_FORMAT", "json")
    assert siem.forward([a]) == {"syslog": 1}
    msg = srv.recv(65535).decode()
    assert msg.startswith("<106>1 ") and _json.loads(msg[msg.index("{"):])["rule"]["id"] == "DG-007"
    srv.close()


def test_security_headers_detections_and_session_revocation(client):
    r = client.get("/api/health")
    assert r.headers["X-Frame-Options"] == "DENY" and "frame-ancestors 'none'" in r.headers["Content-Security-Policy"]
    H, tok = login(client, "owner", "ownerpass1")
    d = client.get("/api/detections", headers=H).json()
    assert len(d) >= 24 and d[0]["id"] == "DG-001" and all(x["acfe"] for x in d)
    assert client.post("/api/users", headers=H, json={"username": "temp", "password": "temppass1", "role": "auditor"}).status_code == 200
    HT, _ = login(client, "temp", "temppass1")
    new = client.post("/api/me/password", headers=HT, json={"old": "temppass1", "new": "temppass2"}).json()["token"]
    assert client.get("/api/me", headers=HT).status_code == 401                       # old session revoked
    assert client.get("/api/me", headers={"Authorization": f"Bearer {new}"}).status_code == 200
    assert client.get("/api/audit/verify", headers=H).json()["ok"]


def test_2fa_login_flow(client):
    from app.auth import totp_now
    H, _ = login(client, "owner", "ownerpass1")
    client.post("/api/users", headers=H, json={"username": "tfa", "password": "tfapass123", "role": "auditor"})
    HT, _ = login(client, "tfa", "tfapass123")
    sec = client.post("/api/me/2fa/setup", headers=HT).json()["secret"]
    assert client.post("/api/me/2fa/enable", headers=HT, json={"secret": sec, "code": "000000"}).status_code == 400
    import time as _t
    # enable with the previous step's code so that the current step can still be used to log in
    assert client.post("/api/me/2fa/enable", headers=HT, json={"secret": sec, "code": totp_now(sec, _t.time() - 30)}).status_code == 200
    r = client.post("/api/login", json={"username": "tfa", "password": "tfapass123"})
    assert r.status_code == 401 and r.json()["detail"] == "2fa_required"
    assert client.post("/api/login", json={"username": "tfa", "password": "tfapass123", "code": totp_now(sec)}).status_code == 200
    assert client.post("/api/login", json={"username": "tfa", "password": "tfapass123", "code": totp_now(sec)}).status_code == 401   # replay
    assert "totp_secret" not in client.get("/api/users", headers=H).json()[0]


def test_collusion_and_correlation_detected(demo):
    demo_conn, _ = demo
    collusion = {r["cashier"] for r in demo_conn.execute("SELECT cashier FROM alerts WHERE rule='approver_concentration'")}
    assert "Sofia V." in collusion
    corr = {r["cashier"] for r in demo_conn.execute("SELECT cashier FROM alerts WHERE rule='correlated_shift'")}
    assert corr and corr <= {"Jake M.", "Tina R.", "Leo K.", "Nina R.", "Sofia V."}
    missing = [r["cashier"] for r in demo_conn.execute("SELECT cashier FROM alerts WHERE rule='missing_count'")]
    assert missing.count("Jake M.") >= 3


def test_missing_count_rule_unit():
    shifts = [dict(store="main", cashier="Ann", register="T1", start_ts=f"2026-11-0{d}T07:00:00", end_ts=f"2026-11-0{d}T15:00:00",
                   expected_cash=500, counted_cash=None) for d in (1, 4)]
    alerts = [a for a in run_rules(Context([T("s", "2026-11-01T10:00:00")], shifts), merged_rules({})) if a["rule"] == "missing_count"]
    assert len(alerts) == 2 and alerts[1]["severity"] == alerts[0]["severity"] + 1
