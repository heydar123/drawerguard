"""Tests for v5: canaries (DG-031), watchlist, incident grouping, investigation graph, compliance
checks, PAN masking, TheHive/Jira integrations (against a local mock server)."""
import json
import os
import sys
import tempfile
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if "DRAWERGUARD_DB" not in os.environ:                 # when run on its own
    _tmp = Path(tempfile.mkdtemp())
    os.environ.update(DRAWERGUARD_DB=str(_tmp / "test.db"), DRAWERGUARD_DATA=str(_tmp / "data"),
                      DRAWERGUARD_PASSWORD="ownerpass1", REPORTS_ENABLED="0")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import compliance, integrations  # noqa: E402
from app.deps import conn  # noqa: E402
from app.ingest.csv_importer import find_pans, luhn_ok, mask_pans  # noqa: E402
from app.main import app  # noqa: E402
from sample_data.generate_demo import Gen  # noqa: E402

C = TestClient(app)
STORE = "v5shop"


def login(u="owner", p="ownerpass1"):
    r = C.post("/api/login", json={"username": u, "password": p})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="module")
def H():
    h = login()
    out = Path(tempfile.mkdtemp())
    g = Gen(5, "harbor")
    g.run(datetime(2026, 11, 8), 30)
    g.write(out, "harbor")
    for f in ("harbor_transactions.csv", "harbor_cashup.csv", "harbor_timeclock.csv"):
        r = C.post("/api/import", headers=h, files={"file": (f, (out / f).read_bytes())}, data={"store": STORE})
        assert r.status_code == 200, r.text
    return h


# ------------------------------------------------------------------ canaries + watchlist

def test_canary_trips_on_use(H):
    r = C.post("/api/canaries", headers=H, json={"store": STORE, "kind": "approver", "value": "Morgan (Manager)", "note": "sticky note"})
    assert r.status_code == 200
    csv_text = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total,Approved By\n"
                "CN1,11/08/2026,12:00:00,Ben T.,Till 1,Refund,Cash,$18.00,Morgan (Manager)\n")
    C.post("/api/import", headers=H, files={"file": ("c.csv", csv_text.encode())}, data={"store": STORE})
    # a value already in the data can't be a canary (it would fire on legitimate use)
    assert C.post("/api/canaries", headers=H, json={"store": STORE, "kind": "approver", "value": "Rita (Manager)"}).status_code == 400
    al = C.get(f"/api/alerts?store={STORE}&rule=canary&status=", headers=H).json()["items"]
    assert al and al[0]["severity"] == 5 and al[0]["rule_id"] == "DG-031" and al[0]["cashier"] == "Ben T."
    listed = C.get("/api/canaries", headers=H).json()["canaries"]
    assert next(c for c in listed if c["value"] == "Morgan (Manager)")["hits"] >= 1
    assert C.post("/api/canaries", headers=H, json={"store": STORE, "kind": "employee", "value": "Ben T."}).status_code == 400
    assert C.post("/api/canaries", headers=H, json={"store": STORE, "kind": "wifi", "value": "abc"}).status_code == 400


def test_watchlist_raises_severity_of_new_alerts(H):
    assert C.post("/api/watchlist", headers=H, json={"store": STORE, "cashier": "Zoe W.", "reason": "Case review", "days": 30}).status_code == 200
    csv_text = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total\n"
                "WL1,11/08/2026,13:00:00,Zoe W.,Till 9,Refund,Cash,$12.30\n")
    C.post("/api/import", headers=H, files={"file": ("w.csv", csv_text.encode())}, data={"store": STORE})
    a = C.get(f"/api/alerts?store={STORE}&cashier=Zoe W.&rule=unmatched_refund&status=", headers=H).json()["items"][0]
    assert a["severity"] == 5 and "watchlist" in a["tags"]          # unmatched refund is normally 4
    w = C.get(f"/api/watchlist?store={STORE}", headers=H).json()
    assert w[0]["cashier"] == "Zoe W." and w[0]["active"] and w[0]["alerts_since"] >= 1


def test_ir_watchlist_checkbox_adds_to_watchlist(H):
    al = C.get(f"/api/alerts?store={STORE}&cashier=Nina R.&status=&limit=3", headers=H).json()["items"]
    cid = C.post("/api/cases", headers=H, json={"store": STORE, "cashier": "Nina R.", "title": "Short drawers",
                                                "alert_ids": [a["id"] for a in al]}).json()["id"]
    C.patch(f"/api/cases/{cid}/ir", headers=H, json={"check": "containment.watchlist"})
    assert any(w["cashier"] == "Nina R." for w in C.get(f"/api/watchlist?store={STORE}", headers=H).json())


def test_purple_canary_scenario(H):
    r = C.post("/api/purple/run", headers=H, json={"store": STORE, "scenarios": ["T20"], "days": 14}).json()
    x = r["results"][0]
    assert x["status"] == "detected", x
    assert any(f["id"] == "DG-031" for f in x["fired"]) and not x["missing_expected"]


# ------------------------------------------------------------------ incidents + graph

def test_incidents_group_alerts(H):
    d = C.get(f"/api/incidents?store={STORE}&days=0", headers=H).json()
    assert d["incidents"] < d["alerts"] and d["reduction_pct"] > 30
    top = d["items"][0]
    assert top["severity"] >= 4 and len(top["alert_ids"]) == top["alerts"] and top["rules"]
    keys = [x["key"] for x in d["items"]]
    assert len(keys) == len(set(keys))


def test_graph_flags_collusion_and_buddy_punching(H):
    g = C.get(f"/api/graph?store={STORE}&days=0", headers=H).json()
    kinds = {n["kind"] for n in g["nodes"]}
    assert {"person", "till", "clock"} <= kinds
    flags = {f for e in g["suspicious"] for f in e["flags"]}
    assert "collusion" in flags and "canary" in flags
    ids = {n["id"] for n in g["nodes"]}
    assert all(e["source"] in ids and e["target"] in ids for e in g["edges"])


# ------------------------------------------------------------------ compliance + PAN

def test_luhn_and_pan_masking():
    assert luhn_ok("4111111111111111") and not luhn_ok("4111111111111112")
    assert find_pans("refund to 4111 1111 1111 1111 please") == ["4111 1111 1111 1111"]
    assert find_pans("receipt 1234567890123 order 99") == []          # not Luhn-valid / not a card brand
    assert mask_pans("card 5555-5555-5555-4444") == ("card ************4444", 1)


def test_pan_in_notes_is_masked_on_import(H):
    csv_text = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total,Reason\n"
                "PN1,11/08/2026,14:00:00,Ben T.,Till 1,Refund,Cash,$9.00,Customer card 4111 1111 1111 1111 declined\n")
    C.post("/api/import", headers=H, files={"file": ("p.csv", csv_text.encode())}, data={"store": STORE})
    note = conn.execute("SELECT note FROM transactions WHERE store=? AND id='PN1'", (STORE,)).fetchone()["note"]
    assert "4111 1111" not in note and note.endswith("1111 declined") and "*" * 12 in note


def test_compliance_assessment(H):
    a = C.get("/api/compliance", headers=H).json()
    assert 0 <= a["score"] <= 100 and set(a["frameworks"]) == set(compliance.FRAMEWORKS)
    byid = {c["id"]: c for c in a["controls"]}
    assert byid["IA-02"]["status"] == "pass"                        # 8 attempts, 30 minutes
    assert byid["DP-01"]["status"] == "pass"                        # PAN masked, none stored
    assert byid["LM-01"]["status"] == "pass"
    assert byid["IA-01"]["status"] in ("fail", "warn")              # no 2FA on the test owner
    assert "8.3.4" in byid["IA-02"]["mapping"]["PCI DSS v4.0.1"]
    rep = C.get("/api/compliance/report", headers=H)
    assert rep.status_code == 200 and "Control evidence report" in rep.text
    me = C.get("/api/me", headers=H).json()
    assert me["idle_minutes"] == 15 and me["password_min_length"] >= 8


# ------------------------------------------------------------------ integrations (mock TheHive + Jira)

class _Mock(BaseHTTPRequestHandler):
    seen: list = []

    def do_POST(self):  # noqa: N802
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])) or b"{}")
        _Mock.seen.append((self.path, self.headers.get("Authorization", ""), body))
        resp = {"_id": "~4096", "number": 7} if "/api/v1/" in self.path else {"key": "DG-42", "id": "10042"}
        out = json.dumps(resp).encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(out)))
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


@pytest.fixture()
def mock_server(monkeypatch):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), _Mock)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    for k, v in {"THEHIVE_URL": url, "THEHIVE_API_KEY": "hive-key", "JIRA_URL": url, "JIRA_USER": "me@example.com",
                 "JIRA_API_TOKEN": "jira-token", "JIRA_PROJECT": "SEC"}.items():
        monkeypatch.setenv(k, v)
    _Mock.seen.clear()
    yield url
    srv.shutdown()


def test_push_case_to_jira_and_thehive(H, mock_server):
    cid = C.get(f"/api/cases?store={STORE}", headers=H).json()[0]["id"]
    r = C.post(f"/api/cases/{cid}/push", headers=H, json={"system": "jira"})
    assert r.status_code == 200 and r.json()["external_id"] == "DG-42" and r.json()["url"].endswith("/browse/DG-42")
    path, auth, body = _Mock.seen[-1]
    assert path == "/rest/api/2/issue" and auth.startswith("Basic ") and body["fields"]["project"]["key"] == "SEC"
    r = C.post(f"/api/cases/{cid}/push", headers=H, json={"system": "thehive"})
    assert r.status_code == 200 and r.json()["external_id"] == "~4096"
    path, auth, body = _Mock.seen[-1]
    assert path == "/api/v1/case" and auth == "Bearer hive-key" and 1 <= body["severity"] <= 4
    refs = C.get("/api/integrations", headers=H).json()
    assert refs["configured"]["jira"] and {x["system"] for x in refs["recent"]} >= {"jira", "thehive"}


def test_new_alerts_flow_to_thehive(H, mock_server):
    csv_text = ("Receipt,Date,Time,Staff,Terminal,Type,Payment,Total\n"
                "TH1,11/08/2026,15:00:00,Ben T.,Till 1,Refund,Cash,$60.00\n")
    C.post("/api/import", headers=H, files={"file": ("t.csv", csv_text.encode())}, data={"store": STORE})
    alerts = [b for p, _a, b in _Mock.seen if p == "/api/v1/alert"]
    assert alerts and all(b["source"] == "DrawerGuard" and b["type"] == "drawerguard" for b in alerts)
    assert any(o["data"] == "Ben T." for b in alerts for o in b["observables"])


def test_integrations_not_configured_is_a_clear_error(H):
    for k in ("THEHIVE_URL", "JIRA_URL"):
        os.environ.pop(k, None)
    cid = C.get(f"/api/cases?store={STORE}", headers=H).json()[0]["id"]
    r = C.post(f"/api/cases/{cid}/push", headers=H, json={"system": "jira"})
    assert r.status_code == 400 and "not configured" in r.json()["detail"]
    assert integrations.configured() == {"thehive": False, "jira": False}
