"""Tests for v4: payroll/timeclock fraud, isolation forest + drift, purple-team simulator,
incident response, detection-as-code, Square/Toast/Clover adapters, Elasticsearch forwarding."""
import json
import os
import sys
import tempfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
if "DRAWERGUARD_DB" not in os.environ:                 # when run on its own
    _tmp = Path(tempfile.mkdtemp())
    os.environ.update(DRAWERGUARD_DB=str(_tmp / "test.db"), DRAWERGUARD_DATA=str(_tmp / "data"),
                      DRAWERGUARD_PASSWORD="ownerpass1", REPORTS_ENABLED="0")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app import siem  # noqa: E402
from app.db import connect, init_db  # noqa: E402
from app.detection import ml  # noqa: E402
from app.detection.dac import load_all, parse_events, parse_punches, run_all, validate  # noqa: E402
from app.ingest.adapters import detect_vendor  # noqa: E402
from app.ingest.csv_importer import import_file  # noqa: E402
from app.main import app  # noqa: E402
from sample_data.generate_demo import Gen  # noqa: E402

C = TestClient(app)
STORE = "v4shop"


def login(u="owner", p="ownerpass1"):
    r = C.post("/api/login", json={"username": u, "password": p})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


@pytest.fixture(scope="module")
def H():
    h = login()
    out = Path(tempfile.mkdtemp())
    g = Gen(7, "main")
    g.run(datetime(2026, 11, 8), 40)
    g.write(out, "main")
    for f in ("main_transactions.csv", "main_cashup.csv", "main_timeclock.csv"):
        r = C.post("/api/import", headers=h, files={"file": (f, (out / f).read_bytes())}, data={"store": STORE})
        assert r.status_code == 200, r.text
    return h


# ------------------------------------------------------------------ timeclock + payroll fraud

def test_timeclock_import_detects_kind_and_edits(H):
    imps = C.get(f"/api/imports?store={STORE}", headers=H).json()
    assert any(i["kind"] == "timeclock" and i["rows_added"] > 100 for i in imps)


def test_payroll_detections_find_the_planted_schemes(H):
    al = C.get(f"/api/alerts?store={STORE}&status=&limit=500&rule=ghost_employee", headers=H).json()["items"]
    assert al and al[0]["cashier"] == "Kevin D." and al[0]["rule_id"] == "DG-026"
    edits = C.get(f"/api/alerts?store={STORE}&status=&rule=timecard_edit", headers=H).json()["items"]
    assert edits and {a["cashier"] for a in edits} == {"Chris W."}
    ov = C.get(f"/api/payroll/overview?store={STORE}&days=0", headers=H).json()
    assert ov["has_data"] and ov["totals"]["employees"] >= 8
    kevin = next(e for e in ov["employees"] if e["employee"] == "Kevin D.")
    assert kevin["pos_txns"] == 0 and kevin["manager_punches"] > 10 and "ghost_employee" in kevin["flags"] and kevin["risk"] == "high"


def test_payroll_alerts_do_not_drive_cash_risk_score(H):
    cs = C.get(f"/api/summary?store={STORE}&days=0", headers=H).json()["cashiers"]
    chris = next(c for c in cs if c["cashier"] == "Chris W.")
    assert chris["payroll_alerts"] >= 1 and chris["level"] != "high"
    assert not any(c["cashier"] == "Kevin D." for c in cs)          # no POS activity → not a cashier


# ------------------------------------------------------------------ ML

def test_isolation_forest_is_deterministic_and_finds_outliers():
    X = [[0.0, 0.1 * (i % 5)] for i in range(200)] + [[6.0, 7.0]]
    f = ml.IsolationForest(100, 128, seed=1).fit(X)
    s_out, contrib = f.score([6.0, 7.0])
    s_in, _ = f.score([0.0, 0.2])
    assert s_out > 0.6 > s_in and sum(contrib) > 0
    assert ml.IsolationForest(100, 128, seed=1).fit(X).score([6.0, 7.0])[0] == s_out


def test_psi_flags_a_shift():
    base = [i % 10 for i in range(300)]
    assert ml.psi(base, [i % 10 for i in range(60)]) < 0.1
    assert ml.psi(base, [8 + i % 2 for i in range(60)]) > 0.25


def test_ml_health_endpoint(H):
    h = C.get(f"/api/ml/health?store={STORE}", headers=H).json()["stores"][0]
    assert h["ready"] and len(h["features"]) == 9 and h["status"] in ("stable", "watch", "drift")
    assert h["model_card"]["models"][1]["id"] == "DG-030" and sum(h["iforest_histogram"]) > 30


# ------------------------------------------------------------------ purple team

def test_purple_team_run_and_matrix(H):
    sc = C.get("/api/purple/scenarios", headers=H).json()
    assert len(sc) >= 19 and all(s["id"].startswith("T") for s in sc)
    r = C.post("/api/purple/run", headers=H, json={"store": STORE, "scenarios": ["T02", "T05", "T07", "T15", "T18"], "days": 14})
    assert r.status_code == 200, r.text
    res = {x["id"]: x for x in r.json()["results"]}
    assert res["T02"]["status"] == "detected" and any(f["id"] == "DG-002" for f in res["T02"]["fired"])
    assert res["T05"]["status"] == "detected" and not res["T05"]["missing_expected"]
    assert res["T07"]["status"] == "detected"
    assert res["T18"]["status"] == "detected" and res["T18"]["fired"][0]["id"] == "DG-026"
    assert res["T15"]["expected"] == []                     # documented blind spot
    # nothing was written to the real tables
    assert C.get(f"/api/alerts?store={STORE}&cashier=Red Team&status=", headers=H).json()["total"] == 0
    runs = C.get(f"/api/purple/runs?store={STORE}", headers=H).json()
    assert runs and C.get(f"/api/purple/runs/{runs[0]['id']}", headers=H).json()["summary"]["scenarios"] == 5


def test_purple_team_needs_admin(H):
    C.post("/api/users", headers=H, json={"username": "aud4", "password": "auditor-pass-1", "role": "auditor", "stores": [STORE]})
    a = login("aud4", "auditor-pass-1")
    assert C.post("/api/purple/run", headers=a, json={"store": STORE}).status_code == 403
    assert C.post("/api/purple/run", headers=H, json={"store": STORE, "intensity": 50}).status_code == 400


# ------------------------------------------------------------------ incident response

def test_incident_response_lifecycle_and_report(H):
    al = C.get(f"/api/alerts?store={STORE}&cashier=Tina R.&status=&min_severity=4&limit=5", headers=H).json()["items"]
    cid = C.post("/api/cases", headers=H, json={"store": STORE, "cashier": "Tina R.", "title": "Refund fraud",
                                                "alert_ids": [a["id"] for a in al]}).json()["id"]
    v = C.get(f"/api/cases/{cid}/ir", headers=H).json()
    assert v["phase"] == "detection" and len(v["phases"]) == 5 and v["controls_recommended"] and v["timeline"]
    assert any(e["kind"] == "transaction" for e in v["timeline"])
    assert C.patch(f"/api/cases/{cid}/ir", headers=H, json={"check": "detection.bogus"}).status_code == 400
    C.patch(f"/api/cases/{cid}/ir", headers=H, json={"check": "detection.verify_cctv"})
    v = C.patch(f"/api/cases/{cid}/ir", headers=H, json={"phase": "containment", "root_cause": "Refunds without receipts",
                                                        "controls": ["Refund to original tender"]}).json()
    assert v["phase"] == "containment" and v["phases"][0]["done"] == 1 and v["metrics"]["contained"]
    assert v["metrics"]["dwell_hours"] is not None
    rep = C.get(f"/api/cases/{cid}/ir-report", headers=H)
    assert rep.status_code == 200 and "Incident report" in rep.text and "Refunds without receipts" in rep.text
    ev = C.get(f"/api/cases/{cid}", headers=H).json()["events"]
    assert any(e["kind"] == "ir" for e in ev)


# ------------------------------------------------------------------ detection-as-code

def test_every_detection_file_is_valid_and_its_tests_pass():
    items = load_all()
    assert len(items) >= 30
    assert validate(items) == []
    res = run_all(items)
    failed = [(r["id"], t["name"], t["detail"]) for r in res["results"] for t in r["tests"] if not t["passed"]]
    assert not failed, failed
    assert res["with_positive_and_negative"] >= 25


def test_dac_validation_catches_mistakes():
    bad = [{"id": "DG-1", "key": "x", "name": "x", "status": "wip", "version": 1, "scheme": "nope", "source": "", "logic": "",
            "false_positives": "", "triage": "", "config": {"enabled": "yes", "severity": 9}, "_file": "x.toml",
            "tests": [{"name": "t", "expect": 1, "events": ["d0 10:00 teleport 5"]}]}]
    errs = " ".join(validate(bad, implemented={"y"}, schemes={"larceny"}))
    for needle in ("id must look like", "status must be", "enabled", "severity", "unknown scheme", "no rule implementation", "unknown type"):
        assert needle in errs


def test_event_dsl():
    ev = parse_events(["*3/10m d1 09:00 refund 20 cash by=Ana appr=Sam id=r"])
    assert [e["ts"] for e in ev] == ["2026-01-06T09:00:00", "2026-01-06T09:10:00", "2026-01-06T09:20:00"]
    assert ev[1]["id"] == "r-1" and ev[0]["approved_by"] == "Sam" and ev[0]["amount"] == 20
    p = parse_punches(["d0 22:00-06:00 by=Ana edited_by=Sam added=30"])[0]
    assert p["clock_out"] == "2026-01-06T06:00:00" and p["minutes_added"] == 30


def test_detection_tests_and_source_api(H):
    r = C.get("/api/detections/tests", headers=H).json()
    assert r["failed"] == 0 and r["tests"] >= 60
    src = C.get("/api/detections/DG-025/source", headers=H)
    assert src.status_code == 200 and 'key = "buddy_punch"' in src.text
    assert C.get("/api/detections/..%2F..%2Fetc/source", headers=H).status_code in (400, 404)


# ------------------------------------------------------------------ other POS systems

@pytest.mark.parametrize("name,vendor,types", [
    ("square_transactions.csv", "square", {"sale", "refund"}), ("square_cash_drawer.csv", "square", {"no_sale", "paid_out"}),
    ("toast_PaymentDetails.csv", "toast", {"sale", "refund"}), ("toast_CashEntries.csv", "toast", {"no_sale", "paid_out"}),
    ("clover_payments.csv", "clover", {"sale", "refund", "void"}), ("clover_cash_log.csv", "clover", {"no_sale", "paid_out"}),
])
def test_vendor_adapters(name, vendor, types):
    conn = connect(":memory:")
    init_db(conn)
    r = import_file(conn, (ROOT / "sample_data" / "vendors" / name).read_bytes(), name, store="v")
    assert r["vendor"] == vendor and r["rows_added"] > 0 and not r["errors"]
    got = {x["txn_type"] for x in conn.execute("SELECT DISTINCT txn_type FROM transactions")}
    assert got == types
    if "refund" in types:                       # refunds link back to their sale (no false "unmatched refund")
        from app.detection.engine import load_context
        from app.detection.rules import rule_refunds
        from app.config import DEFAULT_RULES
        assert not [a for a in rule_refunds(load_context(conn, ["v"]), DEFAULT_RULES) if a["rule"] == "unmatched_refund"]


def test_splitpos_is_not_mistaken_for_a_vendor():
    hdr = ["Receipt No", "Date", "Time", "Staff", "Terminal", "Type", "Payment Type", "Total"]
    assert detect_vendor(hdr) is None
    assert detect_vendor(["Payment Id", "Order Id", "Paid Date", "Server", "Amount"]) == "toast"


# ------------------------------------------------------------------ SIEM

def test_elastic_bulk_body_is_idempotent_ndjson():
    a = {"id": 7, "fingerprint": "main|x:1", "rule": "no_sale_after_cash", "severity": 4, "cashier": "Ana", "ts": "2026-01-05T10:00:00",
         "title": "t", "amount": 5, "store": "main"}
    body = siem.elastic_bulk_body([a, a], "dg").decode().strip().split("\n")
    assert len(body) == 4 and json.loads(body[0])["index"]["_id"] == json.loads(body[2])["index"]["_id"]
    assert json.loads(body[1])["rule"]["id"] == "DG-002"


# ------------------------------------------------------------------ hardening and packaging

def test_concurrent_requests_use_separate_connections(H):
    """The dashboard fires several requests at once; one shared sqlite3 connection used to fail under that load."""
    from concurrent.futures import ThreadPoolExecutor
    paths = [f"/api/forensics/{p}?store={STORE}&days=0" for p in ("benford", "rounding", "hours", "approvals", "heatmap")] * 4
    with ThreadPoolExecutor(8) as ex:
        codes = list(ex.map(lambda p: C.get(p, headers=H).status_code, paths))
    assert codes == [200] * len(paths)


def test_hunt_can_read_timeclock_but_not_secrets(H):
    ok = C.post("/api/hunt/run", headers=H, json={"sql": "SELECT employee, COUNT(*) n FROM timeclock GROUP BY employee"})
    assert ok.status_code == 200 and ok.json()["rows"]
    lib = C.get("/api/hunt/library", headers=H).json()["library"]
    ghost = next(h for h in lib if h["name"].startswith("Paid hours vs POS"))
    res = C.post("/api/hunt/run", headers=H, json={"sql": ghost["sql"]}).json()
    first = dict(zip(res["columns"], res["rows"][0], strict=True))
    assert first["employee"] == "Kevin D." and first["pos_txns"] == 0
    assert C.post("/api/hunt/run", headers=H, json={"sql": "SELECT * FROM api_keys"}).status_code == 400


def test_auditor_reads_but_cannot_change_incident_response(H):
    cid = C.get(f"/api/cases?store={STORE}", headers=H).json()[0]["id"]
    a = login("aud4", "auditor-pass-1")
    assert C.get(f"/api/cases/{cid}/ir", headers=a).status_code == 200
    assert C.patch(f"/api/cases/{cid}/ir", headers=a, json={"phase": "recovery"}).status_code == 403
    assert C.get(f"/api/payroll/overview?store={STORE}", headers=a).status_code == 200


def test_purple_sweep(H):
    r = C.post("/api/purple/sweep", headers=H, json={"store": STORE, "scenario": "T07", "days": 14})
    assert r.status_code == 200
    steps = r.json()["steps"]
    assert [s["intensity"] for s in steps] == [0.25, 0.5, 1.0, 2.0] and steps[-1]["status"] == "detected"
    assert C.post("/api/purple/sweep", headers=H, json={"store": STORE, "scenario": "T99"}).status_code == 400


def test_translations_are_complete():
    import re
    text = (ROOT / "app" / "static" / "i18n.js").read_text()
    entries = re.findall(r'"([^"]+)":\s*\[([^\]]*)\]', text)
    assert len(entries) > 200
    for en, tr in entries:
        assert len(re.findall(r'"[^"]*"', tr)) == 3, en
    keys = [e[0] for e in entries]
    assert len(keys) == len(set(keys)), "duplicate English keys"


def test_siem_lab_content_parses():
    import xml.dom.minidom
    lab = ROOT / "siem-lab"
    json.loads((lab / "elastic" / "index-template.json").read_text())
    # our own repository files, not untrusted input
    xml.dom.minidom.parse(str(lab / "splunk" / "drawerguard_app" / "default" / "data" / "ui" / "views" / "drawerguard_overview.xml"))  # noqa: S318
    xml.dom.minidom.parse(str(lab / "wazuh" / "drawerguard_rules.xml"))  # noqa: S318
    saved = (lab / "splunk" / "drawerguard_app" / "default" / "savedsearches.conf").read_text()
    assert saved.count("[DrawerGuard") >= 4 and "sourcetype=\"drawerguard:alert\"" in saved


def test_timeclock_columns_with_original_times():
    conn = connect(":memory:")
    init_db(conn)
    csv_text = ("Employee,Clock In,Clock Out,Original Clock Out,Device,Edited By,Edit Reason,Hourly Rate\n"
                "Ana,01/05/2026 07:00,01/05/2026 16:00,01/05/2026 15:00,Clock 1,Sam,Forgot to clock out,$16.50\n")
    r = import_file(conn, csv_text.encode(), "tc.csv", store="x")
    assert r["kind"] == "timeclock" and r["rows_added"] == 1
    p = dict(conn.execute("SELECT * FROM timeclock").fetchone())
    assert p["minutes_added"] == 60 and p["edited_by"] == "Sam" and p["hourly_rate"] == 16.5
